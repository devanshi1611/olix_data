import CF7Styler from './CF7Styler/CF7Styler';
export default [CF7Styler];
