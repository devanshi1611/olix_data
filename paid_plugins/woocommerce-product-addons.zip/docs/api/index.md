## REST API

### Creating and Managing Groups, Add-ons and Options

* [Group endpoints](groups.md)

