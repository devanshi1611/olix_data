<?php
function b3_reset_icons_json(){
     
    $et_icons = file_get_contents(B3_PLUGIN_PATH . "/icons/et-icons.json");
    $icons_array = json_decode($et_icons, true);
    $icons_json_str =  json_encode($icons_array);
    file_put_contents(B3_PLUGIN_PATH . "/icons/all-icons.json", $icons_json_str); //generate json file
    copy( B3_PLUGIN_PATH . '/icons/all-icons.json', get_template_directory() . '/includes/builder/feature/icon-manager/full_icons_list.json');
}
function b3_on_options_saved() {
    global  $shortname;
    $icons_list = [];
    
    if($_POST[$shortname . '_b3icon_line'] == 'on'){
        $icons_list[] = 'b3iconline';
    }

    if($_POST[$shortname . '_b3icon_mat'] == 'on'){
        $icons_list[] = 'mt';
    }
    
    if ( is_plugin_active('divi-holiday-icons/divi-holiday-icons.php')){
        // B3 Custom Holiday
        if ( $_POST[$shortname . '_b3holidayicon_line'] == 'on' ){
            $icons_list[] = 'b3holidayicon';
        }
    }
    b3_generate_all_icons_json($icons_list);
}

function b3_on_plugin_activat() {
    
    global  $shortname;
    $icons_list = [];
    
    if(et_get_option('divi_b3icon_line','on') == 'on'){
        $icons_list[] = 'b3iconline';
    }

    if( et_get_option($shortname . '_b3icon_mat') == 'on'){
        $icons_list[] = 'mt';
    }
    
    if ( is_plugin_active('divi-holiday-icons/divi-holiday-icons.php')){
        // B3 Custom Holiday
        if (  et_get_option($shortname . '_b3holidayicon_line') == 'on' ){
            $icons_list[] = 'b3holidayicon';
        }
    }

    b3_generate_all_icons_json($icons_list);
}

function b3_generate_all_icons_json($icons_list){
    $et_icons = file_get_contents(B3_PLUGIN_PATH . "/icons/et-icons.json");
    $icons_array = json_decode($et_icons, true);

    if(in_array('b3iconline', $icons_list)){
        $b3line_icons = file_get_contents(B3_PLUGIN_PATH . "/icons/b3line-icons.json");
        $b3line_icons_array = json_decode($b3line_icons, true);
        $icons_array = array_merge($icons_array, $b3line_icons_array);
    }

    if(in_array('mt', $icons_list)){
        $mt_icons = file_get_contents(B3_PLUGIN_PATH . "/icons/mt-icons.json");
        $mt_array = json_decode($mt_icons, true);
        $icons_array = array_merge($icons_array, $mt_array);
    }

    if(in_array('b3holidayicon', $icons_list)){
        $b3holiday_icons = file_get_contents(B3_PLUGIN_PATH . "/icons/holiday-icons.json");
        $b3holiday_icons_array = json_decode($b3holiday_icons, true);
        $icons_array = array_merge($icons_array, $b3holiday_icons_array);
    }
    $icons_json_str =  json_encode($icons_array);
    file_put_contents(B3_PLUGIN_PATH . "/icons/all-icons.json", $icons_json_str); //generate json file
    copy( B3_PLUGIN_PATH . '/icons/all-icons.json', get_template_directory() . '/includes/builder/feature/icon-manager/full_icons_list.json');
}

function b3_icons_filter($helpers){
    $filters =$helpers['searchFilterIconItems']['show_only'];

    if(et_get_option('divi_b3icon_line','on') == 'on'){
        $filters['b3lineicon'] = esc_html__( 'B3 Icons', 'et_builder' );
    }

    if(et_get_option('divi_b3icon_mat','on') == 'on'){
        $filters['mt'] = esc_html__( 'MT Icons', 'et_builder' );
    }

    if ( is_plugin_active('divi-holiday-icons/divi-holiday-icons.php')){
        // B3 Custom Holiday
        if ( et_get_option('divi_b3holidayicon_line','on') === 'on' ){
            $filters['b3holidayicon'] = 'B3 Holiday Icons';
        }
    }

    $helpers['searchFilterIconItems'] = array(
        'show_only' => $filters
    );
    return $helpers;
}

function b3_on_upgrade(){
    if ( is_plugin_active('divi-icons-pro/divi-icons-pro.php')){
        b3_on_plugin_activat();
    }
}