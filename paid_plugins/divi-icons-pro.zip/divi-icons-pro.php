<?php
/*
   Plugin Name: Divi Icons Pro
   Plugin URI: https://diviicons.b3multimedia.ie/
   Description: Divi Icons PRO adds 2500+ custom icons to the Divi Builder.
   Version: 1.4
   Author: b3multimedia
   Author URI: https://www.b3multimedia.ie/
   License: GPL2
   Text Domain: b3diviicon
*/
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

if ( 'Divi' == get_template() || 'Extra' == get_template() || class_exists( 'ET_Builder_Plugin' ) || class_exists( 'ET_Builder_Element' )) :

    // API Intergation
    if ( ! class_exists( 'B3Icon_License_Plugin' ) ) {
        require_once( dirname(__FILE__) . '/lib/b3icon-license.php' );
    }

    if (  class_exists( 'B3Icon_License_Plugin' ) ) {
         $b3icon_lib = new B3Icon_License_Plugin( __FILE__, '156811', '1.4', 'plugin', 'https://b3multimedia.ie/', 'Divi Icons PRO' );
    }
    /*Check if free version is installed*/
    function b3iconpro_check_free_plugin(){
        if (is_plugin_active('divi-icons/divi-icons.php')){
            function b3iconpro_admin_notice() { ?>
                <div class="notice notice-error">
                    <p><?php _e( "We found out that your WordPress is still using the Divi Icons free version. Please deactivate/uninstall the  Divi Icons  free version in order to have a better experience on the Pro version!", 'b3diviicon' ); ?></p>
                </div>
                <?php
            }
            add_action( 'admin_notices', 'b3iconpro_admin_notice' );
        }
    }
    add_action('admin_init', 'b3iconpro_check_free_plugin');

    define( 'B3_PLUGIN_URL', plugin_dir_url( __FILE__) );
    define( 'B3_PLUGIN_PATH',plugin_dir_path( __FILE__ ) );
    define( 'B3_PLUGIN_BASENAME',plugin_basename( __FILE__ ) );
    include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
    add_action( 'plugins_loaded', 'b3diviicon_plugin_load', 9999 );
    add_action( 'init', 'b3_icon_load' );
    add_filter('all_icons', 'b3icons_lists');
    add_filter( 'body_class', 'fb_body_class' );
    add_filter( 'admin_body_class', 'bfb_body_class' );
    function fb_body_class( $classes )
    {
        $classes[] = 'b3-icon-pro';
        return $classes;
    }
    function bfb_body_class( $classes )
    {
        $classes .= 'b3-icon-pro';
        if ( is_plugin_active('divi-holiday-icons/divi-holiday-icons.php')){
            $classes .= ' b3-icon-pro-holiday ';
        }
        return $classes;
    }
    function b3diviicon_plugin_load()
    {
        add_action('admin_enqueue_scripts', 'b3diviicon_admin_enqueue', 9999);
        add_action("epanel_render_maintabs", 'b3diviicon_epanel_tab');
        add_action("et_epanel_changing_options", 'b3diviicon_epanel_fields');
        add_action('wp_enqueue_scripts', 'b3diviicon_enqueue_script', 9999);
    }
    function b3diviicon_admin_enqueue() {
            if ( ( isset( $_GET['page'] ) && ( $_GET['page'] == 'ulp' ) ) )  {
                return;
            }
            if ( is_plugin_active('divi-holiday-icons/divi-holiday-icons.php')){
                wp_enqueue_style('b3icon_admin', B3_PLUGIN_URL .'assets/css/b3icon_admin_holiday.css', array(), NULL);
            }else{
                wp_enqueue_style('b3icon_admin', B3_PLUGIN_URL .'assets/css/b3icon_admin.css', array(), NULL);
            }
          
           
            $divi_b3icon_line = et_get_option('divi_b3icon_line','on');
            if ( $divi_b3icon_line == 'on' && $divi_b3icon_line != '' ){
                wp_enqueue_style('b3line_font', B3_PLUGIN_URL .'assets/css/b3line_font.css', array(), NULL);
                wp_enqueue_style('b3_ie7', B3_PLUGIN_URL .'assets/css/b3_ie7.css', array(), NULL);
                wp_enqueue_script( 'b3_ie7-js', B3_PLUGIN_URL .'assets/js/b3-ie7.js', array(), '1.0.0' ,true );
            }
            $divi_b3icon_mat = et_get_option('divi_b3icon_mat','on');
            $divi_b3icon_google_material_cdn = et_get_option('divi_b3icon_google_material_cdn','off');
            if ( $divi_b3icon_mat == 'on' && $divi_b3icon_mat != '' ){
                if ( $divi_b3icon_google_material_cdn == 'on'){
                    wp_enqueue_style('b3_materialicons', 'https://fonts.googleapis.com/icon?family=Material+Icons', array(), NULL);
                }else{
                    wp_enqueue_style('b3_materialicons', B3_PLUGIN_URL .'assets/css/b3_material-icons.css', array(), NULL);
                }
            }

            wp_enqueue_style('b3_frontend_font', B3_PLUGIN_URL .'assets/css/b3_frontend.css', array(), '1.3.0');

            $divi_b3icon_line = et_get_option('divi_b3icon_line','on');
            $divi_b3icon_mat = et_get_option('divi_b3icon_mat','on');
            $divi_b3holidayicon_line = '';
            if ( is_plugin_active('divi-holiday-icons/divi-holiday-icons.php')){
                // B3 Custom Holiday
                $divi_b3holidayicon_line = et_get_option('divi_b3holidayicon_line','on');
            }
            wp_enqueue_script( 'b3icons_admin-js', B3_PLUGIN_URL .'assets/js/b3icons.js', array(), '1.3.0' ,true );
            wp_localize_script( 'b3icons_admin-js', 'b3icons_options', array( 'divi_b3icon_line' => $divi_b3icon_line ,'divi_b3icon_mat' => $divi_b3icon_mat  ,'divi_b3holidayicon' => $divi_b3holidayicon_line));
    }
    function b3diviicon_enqueue_script() {
        
        $divi_b3icon_line = et_get_option('divi_b3icon_line','on');
        if ( $divi_b3icon_line == 'on' && $divi_b3icon_line != '' ){
            wp_enqueue_style('b3line_font', B3_PLUGIN_URL .'assets/css/b3line_font.css', array(), NULL);
            if(strpos($_SERVER['HTTP_USER_AGENT'], 'MSIE') !== false) {
                wp_enqueue_style('b3_ie7', B3_PLUGIN_URL .'assets/css/b3_ie7.css', array(), NULL);
                wp_enqueue_script( 'b3_ie7-js', B3_PLUGIN_URL .'assets/js/b3-ie7.js', array(), '1.0.0' ,true );
            }
        }
        $divi_b3icon_mat = et_get_option('divi_b3icon_mat','on');
        $divi_b3icon_google_material_cdn = et_get_option('divi_b3icon_google_material_cdn','off');

        if ( $divi_b3icon_mat == 'on' && $divi_b3icon_mat != '' ){
             if ( $divi_b3icon_google_material_cdn == 'on'){
                wp_enqueue_style('b3_materialicons', 'https://fonts.googleapis.com/icon?family=Material+Icons', array(), NULL);
             }else{
                wp_enqueue_style('b3_materialicons', B3_PLUGIN_URL .'assets/css/b3_material-icons.css', array(), NULL);
             }
        }

        wp_enqueue_style('b3_frontend_font', B3_PLUGIN_URL .'assets/css/b3_frontend.css', array(), NULL);

        $divi_b3icon_line = et_get_option('divi_b3icon_line','on');
        
        $divi_b3icon_mat = et_get_option('divi_b3icon_mat','on');
        $divi_b3holidayicon_line = '';
        if ( is_plugin_active('divi-holiday-icons/divi-holiday-icons.php')){
            // B3 Custom Holiday
            $divi_b3holidayicon_line = et_get_option('divi_b3holidayicon_line','on');
        }
        wp_enqueue_script( 'b3icons-js', B3_PLUGIN_URL .'assets/js/b3icons.js', array(), '1.3.0' ,true );
        wp_localize_script( 'b3icons-js', 'b3icons_options', array( 'divi_b3icon_line' => $divi_b3icon_line , 'divi_b3icon_mat' => $divi_b3icon_mat ,'divi_b3holidayicon' => $divi_b3holidayicon_line ));

    }
    function b3diviicon_epanel_tab(){
      b3diviicon_epanel_fields();?><li><a href="#wrap-b3icons"><?php _e( 'Divi Icons PRO','b3diviicon'); ?></a></li><?php
    }
    function b3diviicon_epanel_fields(){
      global $epanelMainTabs, $themename, $shortname, $options;
      $options[] = array( "name" => "wrap-b3icons","type" => "contenttab-wrapstart",);
      $options[] = array( "type" => "subnavtab-start",);
       $options[] = array(
        "name" => "b3icons-1",
        "type" => "subnav-tab",
        "desc" => esc_html__("General", $themename)
      );
      $options[] = array("type" => "subnavtab-end",);
      $options[] = array("name" => "b3icons-1","type" => "subcontent-start",);

       if ( is_plugin_active('divi-holiday-icons/divi-holiday-icons.php')){
       $options[] = array(
            'name'  => esc_html__('Holiday Icons', $themename),
            'id'    => $shortname . '_b3holidayicon_line',
            'type'  => 'checkbox2',
            'std'   => 'on',
            'desc'  => esc_html__('360 brand new and pixel perfect custom holiday icons for your Divi website.', $themename),
      );
      }
      $options[] = array(
            'name'  => esc_html__('900+ Google Material Icons', $themename),
            'id'    => $shortname . '_b3icon_mat',
            'type'  => 'checkbox2',
            'std'   => 'on',
            'desc'  => esc_html__('Over 900 icons from Google to use in your Divi website with ease.', $themename),
      );
       $options[] = array(
            'name'  => esc_html__('360 Custom Line Style Icons', $themename),
            'id'    => $shortname . '_b3icon_line',
            'type'  => 'checkbox2',
            'std'   => 'on',
            'desc'  => esc_html__('360 brand new and pixel perfect custom line style icons for your Divi website.', $themename),
      );

      $options[] = array(
           'name'  => esc_html__('Display Large icons in the Divi Builder', $themename),
           'id'    => $shortname . '_b3icon_lg_icons',
           'type'  => 'checkbox2',
           'std'   => 'off',
           'desc'  => esc_html__('Enable this option to display large icons in the Divi Builder', $themename),
         );


      $options[] = array(
        'name' => esc_html__('Load Material Icons from CDN', $themename ),
        'desc' => '',
        "type" => "callback_function",
        "function_name" => 'et_b3icon_blank',
       );

      $options[] = array(
            'name'  => esc_html__(' Google Material Icons Fonts', $themename),
            'id'    => $shortname . '_b3icon_google_material_cdn',
            'type'  => 'checkbox2',
            'std'   => 'off',
            'desc'  => esc_html__('Load Google Material Icons Fonts from CDN on your Divi website.', $themename),
      );

      $options[] = array("name" => "b3icons-1","type" => "subcontent-end",);
      $options[] = array("name" => "wrap-b3icons","type" => "contenttab-wrapend",);
    }
    function et_b3icon_blank(){echo '';}

    function b3_icon_load() {
        if(!function_exists('et_get_option') ) return;

        require B3_PLUGIN_PATH.'/lib/et-icon-list.php';
        add_filter('et_pb_font_icon_symbols', 'b3_et_icons_list', 900 );
       
        // B3 Custom Line
        $divi_b3icon_line = et_get_option('divi_b3icon_line','on');
        if ( $divi_b3icon_line == 'on' && $divi_b3icon_line != '' ){
            add_filter('et_pb_font_icon_symbols', 'b3_line_icons_list',998 );
            require B3_PLUGIN_PATH.'/lib/b3line-icon-list.php';
        }
        // B3 material icons
        $divi_b3icon_mat = et_get_option('divi_b3icon_mat','on');
        if ( $divi_b3icon_mat == 'on' && $divi_b3icon_mat != '' ){
            add_filter('et_pb_font_icon_symbols', 'b3_mt_icons_list',999 );
            require B3_PLUGIN_PATH.'/lib/mt-icon-list.php';
        }

        if ( is_plugin_active('divi-holiday-icons/divi-holiday-icons.php')){
                // B3 Custom Holiday
                $divi_b3holidayicon_line = et_get_option('divi_b3holidayicon_line','on');
                if ( $divi_b3holidayicon_line == 'on' && $divi_b3holidayicon_line != '' ){
                        add_filter('et_pb_font_icon_symbols', 'b3pro_holiday_icons_list_free',998 );
                        require B3_PLUGIN_PATH.'/lib/b3holiday-icon-list-pro.php';
                }
        }

    }

    function b3icons_lists( $font_icon )
    {
        if( b3_check_isjson( $font_icon ) ) :
            $icon = json_decode( $font_icon, true );
            $symbol_data = explode( '|', $icon );
            $icon = $symbol_data[0] . '-' . $symbol_data[2];
        else :
            $icon = $font_icon;
        endif;
        return $icon;
    }
    function b3_check_isjson( $string )
    {
       return  is_array( json_decode( $string, true ) ) && is_string( $string ) && ( json_last_error() == JSON_ERROR_NONE ) ? true : false;
    }
    if ( ! function_exists( 'et_pb_process_font_icon' ) ) :
    function et_pb_process_font_icon( $font_icon, $symbols_function = 'default' )
    {
        if ( 1 !== preg_match( "/^%%/", trim( $font_icon ) ) ) {
            return $font_icon;
        }
        $icon_index   = (int) str_replace( '%', '', $font_icon );
        $icon_symbols = 'default' === $symbols_function ? et_pb_get_font_icon_symbols() : call_user_func( $symbols_function );
        $font_icon    = isset( $icon_symbols[ $icon_index ] ) ? $icon_symbols[ $icon_index ] : '';

        $font_icon = apply_filters( 'all_icons', $font_icon );
        return $font_icon;
    }
    endif;
    if ( ! function_exists( 'et_pb_get_font_icon_list_items' ) ) :
    function et_pb_get_font_icon_list_items() {

        $output = '';
        $symbols = et_pb_get_font_icon_symbols();
        foreach ( $symbols as $symbol ) {
            if (strpos($symbol, 'icon_quotations_alt2') !== false) {
                $symbol_data = explode( '~|', $symbol );
            }else{
                $symbol_data = explode( '|', $symbol );
            }
            // if( is_customize_preview() ) :
            //         if( $symbol_data[0] === 'et') :
            //             $output .= sprintf( '<li data-icon=\'%1$s\'></li>', esc_attr( $symbol_data[2] ) );
            //         endif;
            // else :
                 $icon_filter = '';
                 if( $symbol_data[0] === 'et') {
                    $icon_filter = "b3_et b3_all";
                 }else if( $symbol_data[0] === 'b3lineicon') {
                    $icon_filter = "b3_line b3_all";
                 }else if( $symbol_data[0] === 'fab' ||  $symbol_data[0] === 'fas' ||  $symbol_data[0] === 'far'  ) {
                    $icon_filter = "b3_fa b3_all";
                 }else if( $symbol_data[0] === 'mt') {
                    $icon_filter = "b3_mt b3_all";
                 }else if( $symbol_data[0] === 'b3holidayicon') {
                    $icon_filter = "b3_b3holidayicon b3_all";
                 }else{}

                 if( $symbol_data[0] === 'b3lineicon') {
                   $output .= sprintf( '<li data-icon=\'%1$s\' data-iconname=\'%2$s\' data-iconfamily=\'%3$s\' title=\'%2$s\'  class="b3-custom-icon-%3$s b3customicon %4$s"></li>', $symbol_data[2], $symbol_data[1], $symbol_data[0],$icon_filter );
                 }else{
                    if (  $icon_filter != '' ){
                        $output .= sprintf( '<li data-icon=\'%1$s\' data-iconname=\'%2$s\'  data-iconfamily=\'%3$s\' title=\'%2$s\'  class="b3-custom-icon-%3$s b3customicon %4$s"></li>', $symbol_data[2], $symbol_data[1], $symbol_data[0],$icon_filter );
                     }else{
                        $output .= sprintf( '<li data-icon=\'%1$s\'></li>', esc_attr( $symbol ) );
                     }
                 }
            // endif;
        }
        return $output;
    }
    endif;
    if ( ! function_exists( 'et_pb_get_font_icon_list' ) ) :
    function et_pb_get_font_icon_list() {
        $output = is_customize_preview() ? et_pb_get_font_icon_list_items() : '<%= window.et_builder.font_icon_list_template() %>';
        $output = sprintf( '<ul class="et_font_icon b3_icon_lists" >%1$s</ul>', et_core_esc_previously( $output ) );
     
        return $output;
    }
    endif;
    if ( is_plugin_active( 'divi-booster/divi-booster.php' ) ) {
    function iconpro_register_icons($icons) {
        global $wtfdivi;
        list($name, $option) = $wtfdivi->get_setting_bases(plugin_dir_path( __FILE__ ) . '/divi-booster/fixes/014-add-new-icons/functions.php');
        plugin_dir_path('/divi-booster/fixes/014-add-new-icons/functions.php');
        if (!isset($option['urlmax'])) { $option['urlmax']=0; }
        for($i=0; $i<=$option['urlmax']; $i++) {
            if (!empty($option["url$i"])) {
                $icons[] = "wtfdivi014-url$i";
            }
        }
        return $icons;
    }
    add_filter('et_pb_font_icon_symbols', 'iconpro_register_icons',9999);
    function iconpro_css() {
        global $wtfdivi;
        list($name, $option) = $wtfdivi->get_setting_bases(plugin_dir_path( __FILE__ ).'/divi-booster/fixes/014-add-new-icons/functions.php');
        if (!isset($option['urlmax'])) { $option['urlmax']=0; }
    ?>
    <style>

    <?php


    for($i=0; $i<=$option['urlmax']; $i++) {
        if (!empty($option["url$i"])) { ?>
    [data-icon="wtfdivi014-url<?php echo $i; ?>"]::after { background: url('<?php echo htmlentities(@$option["url$i"]); ?>') no-repeat center center; -webkit-background-size: cover; -moz-background-size: cover;-o-background-size: cover;background-size:cover; content:'a' !important; width:16px !important; height:16px !important; color:rgba(0,0,0,0) !important; }
    <?php
        }
    } ?>
    </style>
    <?php
    }




    add_action('wp_head', 'iconpro_css',9999);
    function iconpro_js() {
        global $wtfdivi;
         ?>
         <script>
        jQuery(function($){
            setTimeout(function(){
            var cur_icon_html = $('.et-pb-icon').text();
            <?php
            list($name, $option) = $wtfdivi->get_setting_bases(plugin_dir_path( __FILE__ ).'/divi-booster/fixes/014-add-new-icons/functions.php');
            if (!isset($option['urlmax'])) { $option['urlmax']=0; }
            for($i=0; $i<=$option['urlmax']; $i++) {
                if (!empty($option["url$i"])) { ?>
                    if ( cur_icon_html == 'wtfdivi014-url<?php echo $i; ?>' ){
                        $('.et-pb-icon').html('<img src="<?php echo htmlentities(@$option["url$i"]); ?>"/>');
                        $('.et_pb_inline_icon').html('<img class="db014_custom_hover_icon" src="<?php echo htmlentities(@$option["url$i"]); ?>"/>');
                    }
            <?php
                } else { ?>
                    if ( cur_icon_html == 'wtfdivi014-url<?php echo $i; ?>' ){
                            $('.et-pb-icon').hide();
                            $('.et_pb_inline_icon').hide();
                    }
            <?php
                }
            }
            ?>
            }, 1500);
            $( document).on('click','.et-fb-font-icon-list li', function(event){
                var cur_icon = $(this).attr('data-icon');
                setTimeout(function(){
                <?php
                list($name, $option) = $wtfdivi->get_setting_bases(plugin_dir_path( __FILE__ ).'/divi-booster/fixes/014-add-new-icons/functions.php');
                if (!isset($option['urlmax'])) { $option['urlmax']=0; }
                for($i=0; $i<=$option['urlmax']; $i++) {
                    if (!empty($option["url$i"])) { ?>
                        if ( cur_icon == 'wtfdivi014-url<?php echo $i; ?>' ){
                            $('.et-pb-icon').html('<img src="<?php echo htmlentities(@$option["url$i"]); ?>"/>');
                            $('.et_pb_inline_icon').html('<img class="db014_custom_hover_icon" src="<?php echo htmlentities(@$option["url$i"]); ?>"/>');
                        }
                <?php
                    } else { ?>
                        if ( cur_icon == 'wtfdivi014-url<?php echo $i; ?>' ){
                                $('.et-pb-icon').hide();
                                $('.et_pb_inline_icon').hide();
                        }
                <?php
                    }
                }
                ?>
                }, 500);
            });
        });
        </script>
    <?php
    }
    add_action('wp_footer', 'iconpro_js',9999);
    }

    add_action('admin_head', 'b3_icons_lg');
    add_action('wp_head', 'b3_icons_lg');
    function b3_icons_lg() {
        if(et_get_option('divi_b3icon_lg_icons','on') === 'on'){
            echo '<style>
            .et-db #et-boc .et-l ul.et-fb-font-icon-list li {
                font-size: 20px !important;
                line-height: 22px !important;
                font-size: 34px !important;
                width: 64px !important;
                height: 64px !important;
                text-align: center !important;
                padding: 16px 0 !important;
                vertical-align: middle;
            }</style>';
        }
    }

endif;
require_once( dirname(__FILE__) . '/helper-functions.php' );

add_filter('et_fb_backend_helpers', 'b3_icons_filter', 100, 1 );
register_activation_hook( __FILE__, 'b3_on_plugin_activat' );
register_deactivation_hook( __FILE__, 'b3_reset_icons_json' );
add_action('et_epanel_changing_options', 'b3_on_options_saved', 100);
add_action('upgrader_process_complete', 'b3_on_upgrade', 100);