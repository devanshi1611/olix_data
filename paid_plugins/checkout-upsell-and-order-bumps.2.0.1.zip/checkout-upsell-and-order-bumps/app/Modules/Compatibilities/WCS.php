<?php
/**
 * UpsellWP
 *
 * @package   checkout-upsell-woocommerce
 * @author    Anantharaj B <anantharaj@flycart.org>
 * @copyright 2024 UpsellWP
 * @license   GPL-3.0-or-later
 * @link      https://upsellwp.com
 */

namespace CUW\App\Modules\Compatibilities;

use CUW\App\Helpers\WC;

defined('ABSPATH') || exit;

class WCS extends Base
{
    /**
     * To run compatibility script.
     */
    public function run()
    {
        add_filter('cuw_offer_price_html', function ($price_html, $product, $discount, $display_in, $product_price, $offer_price) {
            if (method_exists('\WC_Subscriptions_Product', 'is_subscription') && \WC_Subscriptions_Product::is_subscription($product)) {
                if ($display_in == 'offer' && $discount['type'] != 'no_discount' && !WC::isVariableProduct($product)) {
                    $product_copy = clone $product;
                    $product_copy->set_regular_price($product_price);
                    $product_copy->set_sale_price($offer_price);
                    $product_copy->set_price($offer_price);
                    return $product_copy->get_price_html();
                }
            }
            return $price_html;
        }, 100, 6);
    }
}