<?php
/**
 * UpsellWP
 *
 * @package   checkout-upsell-woocommerce
 * @author    Anantharaj B <anantharaj@flycart.org>
 * @copyright 2024 UpsellWP
 * @license   GPL-3.0-or-later
 * @link      https://upsellwp.com
 */

namespace CUW\App\Helpers;

defined('ABSPATH') || exit;

class Plugin
{
    /**
     * Active plugins.
     *
     * @var array
     */
    private static $active_plugins;

    /**
     * Well known properties.
     *
     * @var string|bool
     */
    public $name, $version, $debug, $prefix, $slug, $url, $support_url, $has_pro;

    /**
     * To load properties.
     */
    public function __construct()
    {
        foreach (Config::get('plugin') as $key => $value) {
            if (property_exists($this, $key)) {
                $this->{$key} = $value;
            }
        }

        $this->debug = (bool)Config::get('debug');
        $this->has_pro = self::hasPro();
    }

    /**
     * Returns plugin url.
     *
     * @param string $utm_medium
     * @return string
     */
    public function getUrl($utm_medium = '')
    {
        if (!empty($utm_medium)) {
            return $this->url . '?' . http_build_query([
                    'utm_campaign' => 'upsellwp_plugin',
                    'utm_source' => $this->has_pro ? 'upsellwp_pro' : 'upsellwp_free',
                    'utm_medium' => $utm_medium,
                ]);
        }
        return $this->url;
    }

    /**
     * Returns plugin support url.
     *
     * @return string
     */
    public function getSupportUrl()
    {
        return $this->support_url . '?' . http_build_query([
                'utm_campaign' => 'upsellwp_plugin',
                'utm_source' => $this->has_pro ? 'upsellwp_pro' : 'upsellwp_free',
                'utm_medium' => 'help',
            ]);
    }

    /**
     * Check if this plugin has pro plugin files.
     *
     * @return bool
     */
    public static function hasPro()
    {
        return class_exists('\CUW\App\Pro\Route');
    }

    /**
     * Check dependencies
     *
     * @return bool
     */
    public static function checkDependencies()
    {
        global $wp_version;

        // check php version
        $php_version = Config::get('requires.php', '*');
        if (!Functions::checkVersion(PHP_VERSION, $php_version)) {
            if (is_admin()) {
                $message = sprintf(__('UpsellWP requires PHP version %s', 'checkout-upsell-woocommerce'), $php_version);
                WP::adminNotice(esc_html($message), 'error');
            }
            return false;
        }

        // check wordpress version
        $wordpress_version = Config::get('requires.wordpress', '*');
        if (!Functions::checkVersion($wp_version, $wordpress_version)) {
            if (is_admin()) {
                $message = sprintf(__('UpsellWP requires WordPress version %s', 'checkout-upsell-woocommerce'), $wordpress_version);
                WP::adminNotice(esc_html($message), 'error');
            }
            return false;
        }

        // check required plugins and its version
        $required_plugins = Config::get('requires.plugins', []);
        foreach ($required_plugins as $plugin) {
            if (!isset($plugin['name']) || !isset($plugin['file'])) {
                continue;
            }

            $plugin_name = $plugin['name'];
            if (isset($plugin['url'])) {
                $plugin_name = '<a href="' . esc_url($plugin['url']) . '" target="_blank">' . esc_html($plugin_name) . '</a>';
            }

            // check plugin is active
            if (!self::isActive($plugin['file'])) {
                if (is_admin()) {
                    $message = sprintf(__('UpsellWP requires %s plugin to be installed and active', 'checkout-upsell-woocommerce'), $plugin_name);
                    WP::adminNotice(wp_kses_post($message), 'error');
                }
                return false;
            }

            // check plugin version is satisfied
            $plugin_version = self::getVersion($plugin['file']);
            if (!empty($plugin_version) && !Functions::checkVersion($plugin_version, $plugin['version'])) {
                if (is_admin()) {
                    $message = sprintf(__('UpsellWP requires %s version %s', 'checkout-upsell-woocommerce'), $plugin_name, $plugin['version']);
                    WP::adminNotice(wp_kses_post($message), 'error');
                }
                return false;
            }
        }
        return true;
    }

    /**
     * Get all active plugins
     *
     * @return array
     */
    public static function activePlugins()
    {
        if (!isset(self::$active_plugins)) {
            $active_plugins = apply_filters('active_plugins', get_option('active_plugins', []));
            if (function_exists('is_multisite') && is_multisite()) {
                $active_plugins = array_merge($active_plugins, get_site_option('active_sitewide_plugins', []));
            }
            self::$active_plugins = $active_plugins;
        }
        return self::$active_plugins;
    }

    /**
     * Check if the plugin is active or not
     *
     * @param string $file
     * @return bool
     */
    public static function isActive($file)
    {
        $active_plugins = self::activePlugins();
        return in_array($file, $active_plugins) || array_key_exists($file, $active_plugins);
    }

    /**
     * Get plugin data
     *
     * @param string $file
     * @return array
     */
    public static function getData($file)
    {
        $plugin_file = ABSPATH . 'wp-content/plugins/' . $file;
        if (file_exists($plugin_file) && function_exists('get_plugin_data')) {
            return get_plugin_data($plugin_file);
        }
        return [];
    }

    /**
     * Get plugin version
     *
     * @param string $file
     * @return string|null
     */
    public static function getVersion($file)
    {
        $data = self::getData($file);
        return $data['version'] ?? null;
    }
}