jQuery(function ($) {

    let cuw_data = cuw_template.data;
    let cuw_i18n = cuw_template.i18n;
    let cuw_is_rtl = cuw_template.is_rtl;

    /* Offer */
    window.cuw_offer = {
        // init
        init: function () {
            this.event_listeners();
        },

        // update price when change variant
        update_price: function (select, section) {
            let variant = select.find('option:selected');
            section.find('.cuw-product-price, .cuw-page-product-price').html(variant.data('price_html'));
            section.find('.cuw-qty').prop('max', variant.data('stock_qty'));
            if (variant.data('image')) {
                section.find('.cuw-product-image, .cuw-page-product-image').html(variant.data('image'));
            }
        },

        // update the closest quantity input on click press plus or minus button
        update_quantity: function (button) {
            let wrapper = button.parent();
            let input = wrapper.find('input'),
                val = parseFloat(input.val()) || 0,
                max = parseFloat(input.attr('max')) || '',
                min = parseFloat(input.attr('min')) || 0,
                step = parseFloat(input.attr('step')) || 1;

            if (button.is('.cuw-plus')) {
                if (max && (val >= max)) input.val(max);
                else input.val(val + step);
            } else {
                if (min && (val <= min)) input.val(min);
                else if (val > 0) input.val(val - step);
            }

            val = parseFloat(input.val()); // to get current value
            wrapper.find('.cuw-minus').css('opacity', min === val ? 0.6 : 1);
            wrapper.find('.cuw-plus').css('opacity', max === val ? 0.6 : 1);
            input.trigger('change');
        },

        // to check inputting quantity
        check_quantity: function (input) {
            let product_quantity = parseInt(input.val());
            let max_quantity = parseInt(input.prop('max'));
            if (product_quantity > max_quantity) {
                input.val(max_quantity);
            }
            input.closest('.quantity-input').find('.cuw-plus').css('opacity', product_quantity >= max_quantity ? 0.6 : 1);
            input.closest('.cuw-offer, .cuw-page, .cuw-product, .cuw-product-row').find('.variant-select').trigger('change');
        },

        // to load event listeners
        event_listeners: function () {
            $(document).on("click", ".cuw-offer .quantity-input .cuw-plus, .cuw-offer .quantity-input .cuw-minus", function () {
                cuw_offer.update_quantity($(this));
            });

            $(document).on("click", ".cuw-page .quantity-input .cuw-plus, .cuw-page .quantity-input .cuw-minus", function () {
                cuw_offer.update_quantity($(this));
            });

            $(document).on("change", ".cuw-offer .variant-select", function () {
                cuw_offer.update_price($(this), $(this).closest('.cuw-offer'));
            });

            $(document).on("input", '.cuw-offer .cuw-qty', function () {
                cuw_offer.check_quantity($(this));
            });

            $(document).on("change", ".cuw-page .variant-select", function () {
                cuw_offer.update_price($(this), $(this).closest('.cuw-page'));
            });
        },
    }

    /* Products */
    window.cuw_products = {
        // init
        init: function () {
            this.event_listeners();
            this.load_sections();
        },

        // load all available sections
        load_sections: function () {
            $(".cuw-products").each(function (index, section) {
                cuw_products.load_section($(section));
            });
        },

        // load specific section
        load_section: function (section) {
            section.find('.variant-select').trigger('change');
            cuw_products.update_prices(section);
        },

        // get chosen products
        get_chosen_products: function (section) {
            let products = [];
            section.find('.cuw-product').each(function (index, product) {
                if ($(product).find(".cuw-product-checkbox").prop("checked") || $(product).data('key')) {
                    products.push($(product));
                }
            });
            return products;
        },

        // update modal product prices
        update_product_row: function (section, product_row) {
            let price_column = product_row.find('.cuw-product-price');
            let product_id = product_row.data('product_id'), variant_id;
            if (!product_id) {
                product_id = product_row.data('id');
            }

            let product = section.find('.cuw-product[data-id="' + product_id + '"]').first();
            let variant_select = product_row.find('.variant-select').first();
            if (variant_select && variant_select.length) {
                variant_id = variant_select.val();
                let variant = variant_select.find('option[value="' + variant_id + '"]').first();
                product.data('regular_price', variant.data('regular_price'));
                product.data('price', variant.data('price'));
                if (product_id) {
                    product.closest('.cuw-products').find('.cuw-product[data-id="' + product_id + '"]').data('regular_price', variant.data('regular_price'));
                    product.closest('.cuw-products').find('.cuw-product[data-id="' + product_id + '"]').data('price', variant.data('price'));
                }
                product.find('.cuw-product-variation-id').val(variant_id);
                product_row.find('.cuw-product-variation-id').val(variant_id);
                product_row.find('.cuw-qty').prop('max', variant.data('stock_qty'));
                if (variant.data('image')) {
                    if (section.data('change_image') != 'only_row') {
                        product.find('.cuw-product-image').html(variant.data('image'));
                    }
                    product_row.find('.cuw-product-image').html(variant.data('image'));
                }
                price_column.html(variant.data('price_html'));
                //price_column.html(cuw_helper.get_price_html(variant.data('price'), variant.data('regular_price')));
            } else if (price_column.html() === '') {
                price_column.html(product.find('.cuw-product-price').html());
                //price_column.html(cuw_helper.get_price_html(product.data('price'), product.data('regular_price')));
            }
        },

        // update pricing section
        update_prices: function (section, data = {}) {
            if (section.closest('.cuw-modal').length > 0) {
                section = section.closest('.cuw-modal');
            }
            let regular_price_total = 0, price_total = 0, items = 0, main_price = 0, main_item = 0, addons_price = 0,
                addon_items = 0;
            let main_product_id = parseInt(section.find('[name="main_product_id"]').val());
            this.get_chosen_products(section).forEach(function (product) {
                let quantity = 1;
                if (product.find('.quantity-input .cuw-qty').length > 0) {
                    quantity = parseFloat(product.find('.quantity-input .cuw-qty').first().val());
                } else if (product.data('quantity')) {
                    quantity = parseFloat(product.data('quantity'));
                }
                if (main_product_id === product.data('id')) {
                    main_price = parseFloat(product.data('price')) * quantity;
                    main_item = 1;
                } else {
                    addons_price += parseFloat(product.data('price')) * quantity;
                    addon_items++;
                }
                regular_price_total += parseFloat(product.data('regular_price')) * quantity;
                price_total += parseFloat(product.data('price')) * quantity;
                items++;
            });

            let total_savings = regular_price_total - price_total;
            let at_least_items = parseInt(section.find(".cuw-buy-section").find(".cuw-add-to-cart").data('at_least_items')) || 1;
            if (items >= at_least_items) {
                section.find(".cuw-buy-section .cuw-message").hide();
                if (section.find(".cuw-buy-section .cuw-actions").first().data('inactive') === 'disable') {
                    section.find(".cuw-buy-section .cuw-actions").show();
                    section.find(".cuw-buy-section .cuw-actions").find(":input").prop('disabled', false);
                } else {
                    section.find(".cuw-buy-section .cuw-actions").show();
                }
                section.find(".cuw-buy-section .cuw-prices").show();

                section.find(".cuw-main-item").html(main_item);
                section.find(".cuw-addon-items").html(addon_items);
                section.find(".cuw-total-items").html(items);
                section.find(".cuw-main-price").html(cuw_helper.get_price_html(main_price));
                section.find(".cuw-addons-price").html(cuw_helper.get_price_html(addons_price));

                if (section.data('main_product_price')) {
                    regular_price_total += parseFloat(section.data('main_product_regular_price'));
                    price_total += parseFloat(section.data('main_product_price'));
                }

                section.find(".cuw-total-price").html(cuw_helper.get_price_html(price_total, regular_price_total));
            } else {
                if (section.find(".cuw-buy-section .cuw-actions").first().data('inactive') === 'disable') {
                    section.find(".cuw-buy-section .cuw-actions").find(":input").prop('disabled', true);
                } else {
                    section.find(".cuw-buy-section .cuw-actions").hide();
                }
                section.find(".cuw-buy-section .cuw-prices").hide();
                section.find(".cuw-buy-section .cuw-message").show();
            }
            if (total_savings > 0) {
                section.find('.cuw-total-savings').not('[data-hidden="1"]').show();
                section.find('.cuw-total-savings .cuw-saved-amount').html(cuw_helper.get_price_html(total_savings));
            } else {
                section.find('.cuw-total-savings').not('[data-hidden="1"]').hide();
                section.find('.cuw-total-savings .cuw-saved-amount').html('');
            }
            if (data.cart_subtotal) {
                section.find('.cuw-cart-subtotal').html(data.cart_subtotal);
            }
            this.update_add_to_cart_text(section, items);
        },

        // update inputs
        update_inputs: function (product, show = true) {
            let inputs = product.find(':input').not('input[type="checkbox"]');
            let product_id = product.data('id');
            if (show) {
                inputs.prop("disabled", false);
                product.css('opacity', '1');
                if (product_id) {
                    product.closest('.cuw-products').find('.cuw-product[data-id="' + product_id + '"]').css('opacity', '1');
                }
                product.find('.cuw-plus, .cuw-minus').css('pointer-events', 'all');

                product.find('.cuw-remove-item-from-cart, .cuw-added-text, .cuw-added-icon').hide();
                product.find('.cuw-add-product-to-cart').show();
            } else {
                inputs.prop("disabled", true);
                product.css('opacity', '0.8');
                if (product_id) {
                    product.closest('.cuw-products').find('.cuw-product[data-id="' + product_id + '"]').css('opacity', '0.8');
                }
                product.find('.cuw-plus, .cuw-minus').css('pointer-events', 'none');

                product.find('.cuw-add-product-to-cart').hide();
                product.find('.cuw-remove-item-from-cart, .cuw-added-text, .cuw-added-icon').show();
            }
        },

        // update add to cart text
        update_add_to_cart_text: function (section, count = 1) {
            if (section.find(".cuw-buy-section").find(".cuw-add-to-cart").data('buy_now')) {
                return;
            }
            let text = section.find(".cuw-buy-section").find(".cuw-add-to-cart").data('text');
            if (text && !text.includes('{items_text}') && !text.includes('{items_count}')) {
                text = text;
            } else if (text && count > 1) {
                let items_text = '';
                let items_count = count + ' ' + cuw_i18n.add_to_cart.items;
                if (cuw_i18n.add_to_cart.number_to_text[count]) {
                    items_text = cuw_i18n.add_to_cart.number_to_text[count];
                } else {
                    items_text = cuw_i18n.add_to_cart.all_items;
                }
                text = text.replace('{items_text}', items_text).replace('{items_count}', items_count);
            } else {
                text = cuw_i18n.add_to_cart.text;
            }
            section.find(".cuw-add-to-cart").html(text);
        },

        // update badges
        update_badges: function (product) {
            if (product.find('.cuw-badge').data('hidden') == '1') return;

            let save_text = product.find('.cuw-badge').data('save_text');
            let regular_price = product.data('regular_price');
            let price = product.data('price');

            if (regular_price === '' || price === '' || !save_text) return;

            if (regular_price === price) {
                product.find('.cuw-badge').hide();
            } else {
                let amount = cuw_helper.format_price(regular_price - price);
                let percentage = cuw_helper.format_percentage((regular_price - price) / regular_price * 100);
                let text = save_text.replace('{price}', amount).replace('{percentage}', percentage);
                product.find('.cuw-badge').html(text).show();
            }
        },

        // update carousel actions
        carousel_update_actions: function (section) {
            let slider = section.find(".cuw-carousel-slider");
            if (slider[0].scrollLeft === 0) {
                section.find(".cuw-previous").css('opacity', 0.5);
            } else if (Math.abs(slider[0].scrollLeft) + slider[0].clientWidth == slider[0].scrollWidth) {
                section.find(".cuw-next").css('opacity', 0.5);
            } else {
                section.find(".cuw-previous, .cuw-next").css('opacity', 1);
            }
        },

        // carousel scroll items
        carousel_scroll_items: function (section, action) {
            let slider = section.find(".cuw-carousel-slider");
            let item_gap = parseInt(slider.data('gap')) || 18;
            let item_width = parseInt(slider.find(':first-child').width());
            if (action.hasClass('cuw-next')) {
                slider.animate({
                    scrollLeft: (cuw_is_rtl ? '-=' : '+=') + (item_width + item_gap),
                    behaviour: 'smooth'
                }, 10);
            } else if (action.hasClass('cuw-previous')) {
                slider.animate({
                    scrollLeft: (cuw_is_rtl ? '+=' : '-=') + (item_width + item_gap),
                    behaviour: 'smooth'
                }, 10);
            }
        },

        // to load event listeners
        event_listeners: function () {
            $(document).on("click", ".cuw-products .cuw-product-image", function () {
                let checkbox = $(this).closest(".cuw-product").find(".cuw-product-checkbox").first();
                checkbox.prop("checked", !checkbox.prop("checked")).trigger("change");
            });

            $(document).on('click', '.cuw-carousel .cuw-scroll-action', function () {
                cuw_products.carousel_scroll_items($(this).closest(".cuw-carousel"), $(this));
            });

            $('.cuw-carousel .cuw-carousel-slider').on('scroll', function () {
                cuw_products.carousel_update_actions($(this).closest(".cuw-carousel"));
            });

            $(document).on("change", ".cuw-products .cuw-product-checkbox", function () {
                cuw_products.update_inputs($(this).closest(".cuw-product"), $(this).is(":checked"));
                cuw_products.update_prices($(this).closest(".cuw-products"));
            });

            $(document).on("click", ".cuw-products .quantity-input .cuw-plus, .cuw-products .quantity-input .cuw-minus", function () {
                cuw_offer.update_quantity($(this));
            });

            $(document).on("change", '.cuw-products .quantity-input .cuw-qty', function () {
                cuw_products.update_prices($(this).closest(".cuw-products"));
            });

            $(document).on("input", '.cuw-products .quantity-input .cuw-qty', function () {
                cuw_offer.check_quantity($(this));
            });

            $(document).on("change", ".cuw-products .variant-select", function () {
                cuw_products.update_product_row($(this).closest(".cuw-products"), $(this).closest(".cuw-product-row"));
                cuw_products.update_prices($(this).closest(".cuw-products"));
                cuw_products.update_badges($(this).closest(".cuw-product-row"));
            });

            $(document).on("cuw_products_load_section", function (event, section) {
                cuw_products.load_section(section);
            });

            $(document).on("click", '.cuw-cart-addon-products .cuw-toggle-addons', function () {
                $(this).closest(".cuw-cart-addon-products").find(".cuw-products").slideToggle();
                $(this).closest(".cuw-cart-addon-products").find(".cuw-addon-arrow-up").toggle();
                $(this).closest(".cuw-cart-addon-products").find(".cuw-addon-arrow-down").toggle();
            });
        },
    }

    /* Helper */
    window.cuw_helper = {
        // format price
        format_price: function (price, tag = '') {
            price = parseFloat(price).toFixed(cuw_data.woocommerce.price.decimals);
            price = price.replace(".", cuw_data.woocommerce.price.decimal_separator);
            let split = price.split(cuw_data.woocommerce.price.decimal_separator);
            split[0] = split[0].replace(/\B(?=(\d{3})+(?!\d))/g, cuw_data.woocommerce.price.thousand_separator);
            price = split.join(cuw_data.woocommerce.price.decimal_separator);
            price = cuw_data.woocommerce.price.format.replace('%1$s', cuw_data.woocommerce.price.symbol).replace('%2$s', price);
            return tag ? '<' + tag + '>' + price + '</' + tag + '>' : price;
        },

        // get price html
        get_price_html: function (price, regular_price = null) {
            if (regular_price && regular_price > price) {
                return this.format_price(regular_price, 'del') + ' ' + this.format_price(price, 'ins');
            }
            return this.format_price(price, 'ins');
        },

        // get discount text
        get_discount_text: function (discount_type, discount_value) {
            let discount_text = '';
            if (discount_type === 'percentage' && discount_value !== '') {
                discount_text = cuw_helper.format_percentage(discount_value);
            } else if (discount_type === 'fixed_price' && discount_value !== '') {
                discount_text = cuw_helper.format_price(discount_value);
            } else if (discount_type === 'free') {
                discount_text = cuw_i18n.free;
            }
            return discount_text;
        },

        // to format discount percentage
        format_percentage: function (price, round = true) {
            if (price === '') return price;

            if (round) {
                price = Math.round(price * 100) / 100;
                price = price.toFixed(2);
                price = price.replace(/\.?0+$/, '');
            }
            return price += '%';
        },
    }

    /* Spinner */
    window.cuw_spinner = {
        // show spinner
        show: function (section) {
            if (typeof section === 'string') {
                section = $(section).first();
            }
            if (section.block) {
                $(section).block({message: null, overlayCSS: {background: '#fff', opacity: 0.6}});
            }
        },

        // hide spinner
        hide: function (section) {
            if (typeof section === 'string') {
                section = $(section).first();
            }
            if (section.unblock) {
                $(section).unblock();
            }
        }
    }

    /* Model */
    window.cuw_modal = {
        // show modal
        show: function (modal, temp = false) {
            if (typeof modal === 'string') {
                modal = $(modal).first();
            }
            modal.show();
            modal.find('.cuw-modal-close').click(function () {
                temp ? modal.remove() : modal.hide()
            });
            $(window).click(function (event) {
                if ($(event.target).hasClass('cuw-modal')) {
                    temp ? modal.remove() : modal.hide()
                }
            });
            $(document).keydown(function (event) {
                if (event.keyCode === 27) {
                    temp ? modal.remove() : modal.hide()
                }
            });
        },

        // hide modal
        hide: function (modal) {
            if (typeof modal === 'string') {
                modal = $(modal).first();
            }
            modal.hide();
        }
    }

    /* Init */
    $(document).ready(function () {
        cuw_offer.init();
        cuw_products.init();
    });

});