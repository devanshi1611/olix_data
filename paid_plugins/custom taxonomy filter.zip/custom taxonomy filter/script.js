jQuery(document).ready(function($){
    // Helper functions for overlay
    function addOverlay($container, message) {
        if (!$container.css('position') || $container.css('position') === 'static') {
            $container.css('position', 'relative');
        }
        if ($container.find('.loading-overlay').length === 0) {
            $container.append('<div class="loading-overlay"></div>');
        }
    }
    function removeOverlay($container) {
        $container.find('.loading-overlay').fadeOut(200, function(){
            $(this).remove();
        });
    }
    
    // Filter click handler
    $('.project-category-filter').on('click', '.project-category', function(e){
        e.preventDefault();
        var category = $(this).data('category');
        $('.project-category').removeClass('active');
        $(this).addClass('active');
        
        var newUrl = window.location.protocol + "//" + window.location.host + window.location.pathname;
        if(category !== ''){
            newUrl += '?project_category=' + category;
        }
        window.history.pushState({path: newUrl}, '', newUrl);
        
        var $projectsList = $('#projects-list');
        addOverlay($projectsList);
        
        $.ajax({
            url: projects_ajax_obj.ajax_url,
            type: 'POST',
            dataType: 'json',
            data: {
                action: 'fetch_projects_filter',
                nonce: projects_ajax_obj.nonce,
                category: category,
                page: 1
            },
            success: function(response){
                if(response.success){
                    $projectsList.html(response.data);
                } else {
                    $projectsList.html('<p>' + response.data + '</p>');
                }
                removeOverlay($projectsList);
            },
            error: function(){
                $projectsList.html('<p>Error fetching projects.</p>');
                removeOverlay($projectsList);
            }
        });
    });
    
    // Load More button handler
    $('#projects-list').on('click', '#load-more-projects', function(e){
        e.preventDefault();
        var button = $(this);
        var page = button.data('page');
        var max_pages = button.data('max-pages');
        var category = button.data('category');
        var $grid = $('.projects-grid');
        
        addOverlay($grid);
        // Show loader image inside the button and hide the button text.
        button.find('.loader').show();
        // button.find('.button-text').hide();
        
        $.ajax({
            url: projects_ajax_obj.ajax_url,
            type: 'POST',
            dataType: 'json',
            data: {
                action: 'fetch_projects_filter',
                nonce: projects_ajax_obj.nonce,
                category: category,
                page: page
            },
            success: function(response){
                if(response.success){
                    // Append new project items to the existing grid.
                    $grid.append(response.data);
                    page++;
                    button.data('page', page);
                    if(page > max_pages){
                        button.hide();
                    } else {
                        // Hide loader and show the button text again.
                        button.find('.loader').hide();
                        // button.find('.button-text').show();
                    }
                } else {
                    button.html('No more projects').hide();
                }
                removeOverlay($grid);
            },
            error: function(){
                button.html('Error');
                removeOverlay($grid);
            }
        });
    });
});
