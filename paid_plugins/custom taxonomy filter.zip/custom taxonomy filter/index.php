<?php
function hello_elementor_child_enqueue_assets() {
    wp_enqueue_style('hello-elementor-parent-style', get_template_directory_uri() . '/style.css');
    wp_enqueue_style('hello-elementor-child-style', get_stylesheet_directory_uri() . '/style.css', array('hello-elementor-parent-style'), wp_get_theme()->get('Version'));
    wp_enqueue_script('projects-filter-ajax', get_stylesheet_directory_uri() . '/script.js', array('jquery'), wp_get_theme()->get('Version'), true);
}
add_action('wp_enqueue_scripts', 'hello_elementor_child_enqueue_assets');

// function create_projects_cpt() {
//     $args = array(
//         'labels' => array(
//             'name'          => 'Projects',
//             'singular_name' => 'Project',
//             'menu_name'     => 'Projects',
//             'add_new'       => 'Add New',
//             'add_new_item'  => 'Add New Project',
//             'edit_item'     => 'Edit Project',
//             'new_item'      => 'New Project',
//             'view_item'     => 'View Project',
//             'view_items'    => 'View Projects',
//             'search_items'  => 'Search Projects',
//         ),
//         'public'        => true,
//         'has_archive'   => true,
//         'show_in_menu'  => true,
//         'supports'      => array('title', 'editor', 'thumbnail', 'excerpt', 'comments'),
//         'rewrite'       => array('slug' => 'projects'),
//     );
//     register_post_type('projects', $args);
// }
// add_action('init', 'create_projects_cpt');

// CUSTOM POST TYPE CREATED WITH CPT UI

function create_project_taxonomy() {
    $args = array(
        'labels' => array(
            'name'              => 'Project Categories',
            'singular_name'     => 'Project Category',
            'search_items'      => 'Search Project Categories',
            'all_items'         => 'All Project Categories',
            'edit_item'         => 'Edit Project Category',
            'update_item'       => 'Update Project Category',
            'add_new_item'      => 'Add New Project Category',
            'new_item_name'     => 'New Project Category Name',
            'menu_name'         => 'Project Categories',
        ),
        'public'        => true,
        'hierarchical'  => false,  // True for categories (hierarchical), false for tags (flat)
        'show_ui'       => true,
        'show_admin_column' => true,
        'query_var'     => true,
        'rewrite'       => array('slug' => 'project_category'),
        'show_in_rest'  => true,               // <== Enable REST API support
        'rest_base'     => 'project_category', // <== (Optional) set the REST base
    );

    register_taxonomy('project_category', array('projects'), $args);
}
add_action('init', 'create_project_taxonomy');

// -----------------------------------------------------------------------------------------------------------------------------------------------------------------------

/// Enqueue our custom JavaScript for AJAX filtering.
function enqueue_projects_filter_ajax_scripts() {
    // wp_enqueue_script( 'projects-filter-ajax', get_template_directory_uri() . '/js/projects-filter-ajax.js', array('jquery'), '1.0', true );
    wp_localize_script( 'projects-filter-ajax', 'projects_ajax_obj', array(
        'ajax_url' => admin_url( 'admin-ajax.php' ),
        'nonce'    => wp_create_nonce( 'projects_filter_nonce' ),
    ) );
}
add_action( 'wp_enqueue_scripts', 'enqueue_projects_filter_ajax_scripts' );


// Shortcode to output filter links and the projects list container.
function fetch_projects_with_filter_ajax_shortcode( $atts ) {
    ob_start();

    // Get the current taxonomy filter from the URL query parameter.
    $current_term = isset( $_GET['project_category'] ) ? sanitize_text_field( $_GET['project_category'] ) : '';

    // Fetch all project categories.
    $terms = get_terms( array(
        'taxonomy'   => 'project_category',
        'hide_empty' => false,
    ) );

    echo '<div class="project-category-filter" style="margin-bottom:20px;">';
        // “All” link – active if no filter is set.
        echo '<a href="#" data-category="" class="project-category ' . ( $current_term == '' ? 'active' : '' ) . '" style="margin-right:10px;">All</a>';
        if ( ! empty( $terms ) && ! is_wp_error( $terms ) ) {
            foreach ( $terms as $term ) {
                echo '<a href="#" data-category="' . esc_attr( $term->slug ) . '" class="project-category ' . ( $current_term == $term->slug ? 'active' : '' ) . '" style="margin-right:10px;">' . esc_html( $term->name ) . '</a>';
            }
        }
    echo '</div>';

    echo '<div id="projects-list">';
        // Set up query arguments: start on page 1 with 9 posts per page.
        $paged = 1;
        $args = array(
            'post_type'      => 'projects',
            'posts_per_page' => 9,
            'paged'          => $paged,
            'order'          => 'ASC',      // Change from DESC to ASC to reverse the order.
            'orderby'        => 'date' 
        );
        if ( ! empty( $current_term ) ) {
            $args['tax_query'] = array(
                array(
                    'taxonomy' => 'project_category',
                    'field'    => 'slug',
                    'terms'    => $current_term,
                ),
            );
        }
        $projects_query = new WP_Query( $args );
        // Replace 6379 with your actual Elementor loop template ID.
        $loop_template_id = 6379;

        if ( $projects_query->have_posts() ) {
            // Wrap the items in a grid container.
            echo '<div class="projects-grid">';
            while ( $projects_query->have_posts() ) {
                $projects_query->the_post();
                echo '<div class="project-item">';
                    echo \Elementor\Plugin::$instance->frontend->get_builder_content_for_display( $loop_template_id );
                echo '</div>';
            }
            echo '</div>';

            // If there are more than 9 posts, output the "Load More" button.
            if ( $projects_query->max_num_pages > 1 ) {
                echo '<div id="load-more-container" style="text-align: center; margin-top: 20px;">';
                    echo '<button id="load-more-projects" data-page="2" data-max-pages="' . $projects_query->max_num_pages . '" data-category="' . esc_attr( $current_term ) . '">
                            <span class="button-text">Load More</span>
                            <span class="loader" style="display:none;"><img src="https://truwin.com/wp-content/uploads/2025/03/white_loader.gif" alt="Loading..." style="vertical-align:middle; margin-left: 5px; height:30px;"></span>   
                        </button>';
                echo '</div>';
            }
        } else {
            echo '<p>No projects found.</p>';
        }
        wp_reset_postdata();
    echo '</div>';

    return ob_get_clean();
}
add_shortcode( 'fetch_projects_filter_ajax', 'fetch_projects_with_filter_ajax_shortcode' );


function ajax_fetch_projects_filter() {
    check_ajax_referer( 'projects_filter_nonce', 'nonce' );
    
    $category = isset( $_POST['category'] ) ? sanitize_text_field( $_POST['category'] ) : '';
    $page     = isset( $_POST['page'] ) ? intval( $_POST['page'] ) : 1;
    
    $args = array(
        'post_type'      => 'projects',
        'posts_per_page' => 9,
        'paged'          => $page,
        'order'          => 'ASC',      // Change from DESC to ASC to reverse the order.
        'orderby'        => 'date' 
    );
    if ( ! empty( $category ) ) {
        $args['tax_query'] = array(
            array(
                'taxonomy' => 'project_category',
                'field'    => 'slug',
                'terms'    => $category,
            ),
        );
    }
    
    $projects_query = new WP_Query( $args );
    
    // Replace 6379 with your actual Elementor loop template ID.
    $loop_template_id = 6379;
    
    if ( $projects_query->have_posts() ) {
        ob_start();
        if ( $page == 1 ) {
            // For page 1 (new filter), wrap items in a grid container.
            echo '<div class="projects-grid" style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px;">';
            while ( $projects_query->have_posts() ) {
                $projects_query->the_post();
                echo '<div class="project-item">';
                    echo \Elementor\Plugin::$instance->frontend->get_builder_content_for_display( $loop_template_id );
                echo '</div>';
            }
            echo '</div>';
            // Append the "Load More" button if there are more pages.
            if ( $projects_query->max_num_pages > 1 ) {
                echo '<div id="load-more-container" style="text-align: center; margin-top: 20px;">';
                    echo '<button id="load-more-projects" data-page="2" data-max-pages="' . $projects_query->max_num_pages . '" data-category="' . esc_attr( $category ) . '">
                            <span class="button-text">Load More</span>
                            <span class="loader" style="display:none;"><img src="https://truwin.com/wp-content/uploads/2025/03/white_loader.gif" alt="Loading..." style="vertical-align:middle; margin-left: 5px; height:30px;"></span>
                        </button>';
                echo '</div>';
            }
        } else {
            // For subsequent pages, return only the project-item elements.
            while ( $projects_query->have_posts() ) {
                $projects_query->the_post();
                echo '<div class="project-item">';
                    echo \Elementor\Plugin::$instance->frontend->get_builder_content_for_display( $loop_template_id );
                echo '</div>';
            }
        }
        $html = ob_get_clean();
        wp_send_json_success( $html );
    } else {
        wp_send_json_error( 'No projects found.' );
    }
    
    wp_die();
}
add_action( 'wp_ajax_fetch_projects_filter', 'ajax_fetch_projects_filter' );
add_action( 'wp_ajax_nopriv_fetch_projects_filter', 'ajax_fetch_projects_filter' );

