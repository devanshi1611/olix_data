<?php
/**
 * @package Doubly
 * @author Unlimited Elements
 * @copyright (C) 2022 Unlimited Elements, All Rights Reserved. 
 * @license GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 **/

if(!defined("DOUBLY_INC")) die("restricted access");

class HtmlOutputBaseDOUBLY{
	
	const BR = "\n";
	const BR2 = "\n\n";
	const TAB = "	";
	const TAB2 = "		";
	const TAB3 = "			";
	const TAB4 = "				";
	const TAB5 = "					";
	const TAB6 = "						";
}