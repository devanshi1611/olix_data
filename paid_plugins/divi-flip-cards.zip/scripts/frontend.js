jQuery(window).load(function($){
	if(jQuery('body').hasClass('et-fb')){
	} else{
		jQuery('body').addClass('b3m-et-fb');
		setTimeout(function() {		
			jQuery('.b3m_flip_blurb_inner').each(function(){
				var $firstBox = jQuery(this).find('.et_pb_blurb_content.et_pb_blurb_content_front').outerHeight();
				var $secondBox = jQuery(this).find('.et_pb_blurb_content_back').outerHeight();
				var $container = jQuery(this).find('.et_pb_blurb_content.et_pb_blurb_content_front').outerWidth();
				if (jQuery(this).hasClass('cross_direction') ){
					if($firstBox >$secondBox && $firstBox > $container){
						//jQuery(this).find('.et_pb_blurb_content_back').css({height: $firstBox});
						jQuery(this).find('.b3m_flip_blurb_flipper').css({height: $firstBox});
						jQuery(this).find('.b3m_flip_blurb_inner').css({height: $firstBox});
						if (jQuery(this).hasClass('cross_direction') ){
							jQuery(this).find('.b3m_flip_blurb_flipper').css({width: $firstBox});
							jQuery(this).css({width: $firstBox});
						}
					}
					else if ($container > $secondBox && $container > $firstBox){
						//jQuery(this).find('.et_pb_blurb_content_back').css({height: $container});
						jQuery(this).find('.b3m_flip_blurb_flipper').css({height: $container});
						jQuery(this).find('.b3m_flip_blurb_inner').css({height: $container});
						if (jQuery(this).hasClass('cross_direction') ){
							jQuery(this).find('.b3m_flip_blurb_flipper').css({width: $container});
							jQuery(this).css({width: $container});
						}
					}
					else {
						//jQuery(this).find('.et_pb_blurb_content_front').css({height: $secondBox});
						jQuery(this).find('.b3m_flip_blurb_flipper').css({height: $secondBox});
						jQuery(this).find('.b3m_flip_blurb_inner').css({height: $secondBox});
						if (jQuery(this).hasClass('cross_direction') ){
							jQuery(this).find('.b3m_flip_blurb_flipper').css({width: $secondBox});
							jQuery(this).css({width: $secondBox});
						}
					}
				}else{
					if($firstBox > $secondBox){
						//jQuery(this).find('.et_pb_blurb_content_back').css({height: $firstBox});
						jQuery(this).find('.b3m_flip_blurb_flipper').css({height: $firstBox});
						jQuery(this).find('.b3m_flip_blurb_inner').css({height: $firstBox});
						if (jQuery(this).hasClass('cross_direction') ){
							jQuery(this).find('.b3m_flip_blurb_flipper').css({width: $firstBox});
						}
					}
					else {
						//jQuery(this).find('.et_pb_blurb_content_front').css({height: $secondBox});
						jQuery(this).find('.b3m_flip_blurb_flipper').css({height: $secondBox});
						jQuery(this).find('.b3m_flip_blurb_inner').css({height: $secondBox});
						if (jQuery(this).hasClass('cross_direction') ){
							jQuery(this).find('.b3m_flip_blurb_flipper').css({width: $secondBox});
						}
					}
				}
			});

			if (!!window.MSInputMethodContext && !!document.documentMode){
				if(	jQuery('.b3m_flip_blurb_inner').has('.b3m_flipcard_3d_cube')) {
					jQuery(".b3m_flip_blurb_inner").removeClass("b3m_flipcard_3d_cube").addClass("b3m_flipcard_2d_animation_cardflip");;
				}
				if(	jQuery('.b3m_flip_blurb_inner').has('.b3m_flipcard_3d_cube_flip')) {
					jQuery(".b3m_flip_blurb_inner").removeClass("b3m_flipcard_3d_cube_flip").addClass("b3m_flipcard_2d_animation_cardflip");;
				}
				if(	jQuery('.b3m_flip_blurb_inner').has('.b3m_flipcard_3d_cube_coveropen')) {
					jQuery(".b3m_flip_blurb_inner").removeClass("b3m_flipcard_3d_cube_coveropen").addClass("b3m_flipcard_2d_animation_cardflip");;
				}
				
				if(	jQuery('.b3m_flipcard_2d_animation_cardflip').has('.direction_trtbl')) {
					jQuery(".b3m_flipcard_2d_animation_cardflip").removeClass("direction_trtbl").addClass("direction_rtl");;
				}
				if(	jQuery('.b3m_flipcard_2d_animation_cardflip').has('.direction_tltbr')) {
					jQuery(".b3m_flipcard_2d_animation_cardflip").removeClass("direction_tltbr").addClass("direction_rtl");;
				}
				if(	jQuery('.b3m_flipcard_2d_animation_cardflip').has('.direction_brttl')) {
					jQuery(".b3m_flipcard_2d_animation_cardflip").removeClass("direction_brttl").addClass("direction_rtl");;
				}
				if(	jQuery('.b3m_flipcard_2d_animation_cardflip').has('.direction_blttr')) {
					jQuery(".b3m_flipcard_2d_animation_cardflip").removeClass("direction_blttr").addClass("direction_rtl");;
				}
			}
		}, 800);
	}
});


