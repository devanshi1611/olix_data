import DiviFlipCards from './DiviFlipCards/DiviFlipCards';

export default [DiviFlipCards];
