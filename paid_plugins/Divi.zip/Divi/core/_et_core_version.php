<?php
/**
 * Define the current ET Core version4.17.0
 *
 * (Note: this value updates automatically as part of our Grunt release task4.17.0)
 *
 * @package \ET\Core
 */

// Note, this will be updated automatically during grunt release task
$ET_CORE_VERSION = '4.17.0';
