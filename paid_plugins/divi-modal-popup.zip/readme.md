# Divi Modal Popup

Divi Modal Popup plugin allows you to create popups & lightboxes for videos, images, text, & more with multiple trigger types.

##  Installation

For instructions on how to install the plugin, please visit https://diviextended.com/documentation/.

## Support

Please visit https://diviextended.com/support/ for support.