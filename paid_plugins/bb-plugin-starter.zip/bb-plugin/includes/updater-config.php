<?php

if ( class_exists( 'FLUpdater' ) ) {
	FLUpdater::add_product(array(
		'name'    => 'Beaver Builder Plugin (Starter Version)',
		'version' => '2.8.4.1',
		'slug'    => 'bb-plugin',
		'type'    => 'plugin',
	));
}
