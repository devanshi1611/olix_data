<?php

// Defines
define( 'FL_BUILDER_ADDONS_PLUGINS_DIR', FL_BUILDER_DIR . 'extensions/fl-builder-addons-installer/' );
define( 'FL_BUILDER_ADDONS_PLUGINS_URL', FLBuilder::plugin_url() . 'extensions/fl-builder-addons-installer/' );

// Classes
require_once FL_BUILDER_ADDONS_PLUGINS_DIR . 'classes/class-fl-builder-addons-installer.php';
