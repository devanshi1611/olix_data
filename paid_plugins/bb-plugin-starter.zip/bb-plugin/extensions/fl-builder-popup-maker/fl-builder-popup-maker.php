<?php

// Defines
define( 'FL_BUILDER_POPUP_MAKER_DIR', FL_BUILDER_DIR . 'extensions/fl-builder-popup-maker/' );
define( 'FL_BUILDER_POPUP_MAKER_URL', FLBuilder::plugin_url() . 'extensions/fl-builder-popup-maker/' );

// Classes
require_once FL_BUILDER_POPUP_MAKER_DIR . 'classes/class-fl-builder-popup-maker.php';
