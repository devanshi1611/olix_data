<?php
/**
 * Pagination load more content
 */

?>
<div class="jet-filters-pagination__link">/% $value %/</div>