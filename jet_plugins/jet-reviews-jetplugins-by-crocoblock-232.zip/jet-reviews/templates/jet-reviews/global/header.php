<?php
/**
 * Review Header
 */
?><div class="jet-review__header">
	<div class="jet-review__header-top"><?php
		include $this->__get_global_template( 'title' );
		include $this->__get_global_template( 'total-average' );
	?></div><?php

	include $this->__get_global_template( 'form' );
?></div>
