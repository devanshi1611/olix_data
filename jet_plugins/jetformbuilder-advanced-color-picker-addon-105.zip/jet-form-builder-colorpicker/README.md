# JetFormBuilder Advanced Color Picker
Premium Addon for JetFormBuilder & JetEngine Forms

# ChangeLog

## 1.0.5
* FIX: Compatibility with the Form Page Break
* Tweak: Update jfb-addon-core to `1.1.11`

## 1.0.4
* FIX: Required color-picker with advanced validation issue
* Tweak: updated icon, description & preview of the block

## 1.0.3
* ADD: Compatibility with JetFormBuilder 3.0.0

## 1.0.2
* Tweak: Removed unnecessary hook

## 1.0.1
* Tweak: add license manager
