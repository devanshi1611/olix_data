<template>
	<div>
		<JetFormEditorRow :label="label( 'use_advanced' )">
			<input type="checkbox" v-model="response.use_advanced"/>
		</JetFormEditorRow>
		<template v-if="response.use_advanced">
			<JetFormEditorRow :label="label( 'preferredFormat' )">
				<select v-model="response.preferredFormat">
					<option
						v-for="({ label, value }) in option( 'preferredFormat' )"
						:value="value"
					>
						{{ label }}
					</option>
				</select>
			</JetFormEditorRow>
			<JetFormEditorRow :label="label( 'showAlpha' )">
				<input type="checkbox" v-model="response.showAlpha"/>
			</JetFormEditorRow>
		</template>
	</div>
</template>

<script>
import { JetFormEditorRow } from "jfb-editor";
import {
	label,
	option,
} from "../jet-form-builder/editor/source";

export default {
	name: 'color_picker_field',
	components: {
		JetFormEditorRow,
	},
	props: [ 'value' ],
	data() {
		return {
			response: {},
		}
	},
	created() {
		this.response = JSON.parse( JSON.stringify( this.value || {} ) );
	},
	watch: {
		response( newResponse ) {
			this.$emit( 'input', newResponse );
		},
	},
	methods: {
		label,
		option,
	},
};
</script>
