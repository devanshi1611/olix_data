const {
	      InputData,
      } = JetFormBuilderAbstract;

const {
	      applyFilters,
      } = window.JetPlugins.hooks;

function ColorPickerData() {
	InputData.call( this );

	this.isSupported = function ( node ) {
		return node.classList.contains( 'jet-fb-color-picker-advanced' );
	};

	this.addListeners = function () {
		const [ node ] = this.nodes;

		node.addEventListener( 'blur', event => {
			this.value.current = event.target.value;
		} );

		jQuery( node ).on( 'change', ( e, tinycolor ) => {
			this.value.current = tinycolor?.toString() ?? '';
		} );
	};

	this.setNode = function ( node ) {
		InputData.prototype.setNode.call( this, node );

		let settings = {};

		try {
			settings = JSON.parse( node.dataset.fbSettings );
		}
		catch ( error ) {
			// silence
		}

		jQuery( node ).spectrum( applyFilters( 'jet.fb.colorpicker.options', {
			type: 'component',
			togglePaletteOnly: true,
			...settings,
		} ) );
	};
}

ColorPickerData.prototype = Object.create( InputData.prototype );

export default ColorPickerData;