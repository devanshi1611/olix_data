import ColorPickerData from './input';

const {
	      BaseSignal,
      } = JetFormBuilderAbstract;

function ColorPickerSignal() {
	BaseSignal.call( this );

	this.isSupported = function ( node, input ) {
		return input instanceof ColorPickerData;
	};

	this.runSignal = function () {
		const [ node ] = this.input.nodes;

		jQuery( node ).spectrum( 'set', this.input.value.current );
	};
}

ColorPickerSignal.prototype = Object.create( BaseSignal.prototype );

export default ColorPickerSignal;