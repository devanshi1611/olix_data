import ColorPickerData from './input';
import ColorPickerSignal from './signal';

const {
	      addFilter,
      } = JetPlugins.hooks;

addFilter(
	'jet.fb.inputs',
	'jet-form-builder/color-picker',
	function ( inputs ) {
		inputs = [ ColorPickerData, ...inputs ];

		return inputs;
	},
);

addFilter(
	'jet.fb.signals',
	'jet-form-builder/hierarchical-select',
	function ( signals ) {
		signals = [ ColorPickerSignal, ...signals ];

		return signals;
	},
);