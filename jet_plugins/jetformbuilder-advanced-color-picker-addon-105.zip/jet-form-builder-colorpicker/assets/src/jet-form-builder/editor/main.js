import {
	label,
	option,
} from './source';

const {
	      addFilter,
      } = wp.hooks;
const {
	      ToggleControl,
	      SelectControl,
      } = wp.components;
const {
	      __,
      } = wp.i18n;
const {
	      useBlockAttributes,
      } = JetFBHooks;

const parentBlockName = 'jet-forms/color-picker-field';
const blockNameHook   = parentBlockName.replace( '/', '-' );

addFilter( 'blocks.registerBlockType', 'jet-form-builder', ( props, name ) => {
	if ( name !== parentBlockName ) {
		return props;
	}

	props.icon = <svg width="64" height="64" viewBox="0 0 64 64" fill="none"
	                  xmlns="http://www.w3.org/2000/svg">
		<path fill-rule="evenodd" clip-rule="evenodd"
		      d="M13 55C10.7909 55 9 53.2091 9 51V13C9 10.7909 10.7909 9 13 9H21C23.2091 9 25 10.7909 25 13V27.5267L36.6984 15.8283C38.2605 14.2662 40.7931 14.2662 42.3552 15.8283L48.0121 21.4852C49.5742 23.0473 49.5742 25.5799 48.0121 27.142L36.1541 39L51 39C53.2091 39 55 40.7908 55 43V51C55 53.2091 53.2091 55 51 55H13ZM25 39.5854V30.3551L28.8639 26.4912L37.3492 34.9765L28.8701 43.4556L25 39.5854ZM25 42.4139V47.3257L27.4559 44.8698L25 42.4139ZM25 51V50.1541L34.1541 41H38V53H24.4649C24.8052 52.4116 25 51.7286 25 51ZM13 11H21C22.1046 11 23 11.8954 23 13V24H11V13C11 11.8954 11.8954 11 13 11ZM11 26V39H23V26H11ZM23 41H11V51C11 52.1045 11.8954 53 13 53L21.023 52.9999C22.117 52.9875 23 52.0969 23 51V41ZM51 41C52.1046 41 53 41.8954 53 43V51C53 52.1045 52.1046 53 51 53H40V41H51ZM46.5979 22.8994L40.941 17.2425C40.16 16.4615 38.8936 16.4615 38.1126 17.2425L30.2781 25.077L38.7634 33.5623L46.5979 25.7278C47.3789 24.9468 47.3789 23.6804 46.5979 22.8994Z"
		      fill="currentColor"/>
	</svg>;

	props.description = __(
		`Allow Advanced Color Picker compliments any form type and lets 
users pick custom colors in the form.`,
		'jet-form-builder',
	);

	props.attributes.preferredFormat = {
		type: 'string',
		default: '',
	};
	props.attributes.showAlpha       = {
		type: 'boolean',
		default: true,
	};
	props.attributes.use_advanced    = {
		type: 'boolean',
		default: true,
	};

	return props;
} );

addFilter(
	`jet.fb.render.settings.${ blockNameHook }`,
	'jet-form-builder',
	( prev ) => {
		const [ attributes, setAttributes ] = useBlockAttributes();

		return <>
			<ToggleControl
				label={ label( 'use_advanced' ) }
				checked={ attributes.use_advanced }
				onChange={ use_advanced => setAttributes( { use_advanced } ) }
			/>
			{ attributes.use_advanced && <>
				<SelectControl
					label={ label( 'preferredFormat' ) }
					labelposition="top"
					value={ attributes.preferredFormat }
					onChange={ preferredFormat => setAttributes( {
						preferredFormat,
					} ) }
					options={ option( 'preferredFormat' ) }
				/>
				<ToggleControl
					label={ label( 'showAlpha' ) }
					checked={ attributes.showAlpha }
					onChange={ showAlpha => setAttributes( { showAlpha } ) }
					help={ 'hex' === attributes.preferredFormat
					       ? __(
							`If you apply transparency, the value will always 
be in RGB format`,
							'jet-form-builder-colorpicker',
						)
					       : '' }
				/>
			</> }
		</>;
	},
);

/**
 * @deprecated
 */
addFilter(
	'jet.fb.register.fields.controls',
	'jet-form-builder',
	controls => {
		controls.custom_settings       = controls.custom_settings || {};
		controls.custom_settings.attrs = controls.custom_settings.attrs || [];
		controls.custom_settings.attrs.push(
			{
				'attrName': 'use_advanced',
				'label': label( 'use_advanced' ),
				'type': 'toggle',
				condition: {
					blockName: [ parentBlockName ],
				},
			},
			{
				'attrName': 'preferredFormat',
				'label': label( 'preferredFormat' ),
				'type': 'select',
				'options': option( 'preferredFormat' ),
				condition: {
					attr: 'use_advanced',
					blockName: [ parentBlockName ],
				},
			},
			{
				'attrName': 'showAlpha',
				'label': label( 'showAlpha' ),
				'type': 'toggle',
				condition: {
					attr: 'use_advanced',
					blockName: [ parentBlockName ],
				},
			},
		);

		return controls;
	},
);

