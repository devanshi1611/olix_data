<?php


namespace Jet_FB_ColorPicker;

class ColorPicker {

	public static function prepare_settings( $args, ...$filter_args ) {
		return apply_filters(
			'jet-form-builder-colorpicker/field-settings',
			self::_prepare_settings(
				$args,
				array(
					'use_advanced',
					'preferredFormat',
					'showAlpha',
					'default' => 'color',
				)
			),
			...$filter_args
		);
	}

	public static function _prepare_settings( $source, $rules ) {
		$prepared = array();

		foreach ( $rules as $arg_name => $setting_name ) {
			if ( is_int( $arg_name ) ) {
				if ( ! isset( $source[ $setting_name ] ) ) {
					continue;
				}
				$prepared[ $setting_name ] = $source[ $setting_name ];
				continue;
			}
			if ( ! isset( $source[ $arg_name ] ) ) {
				continue;
			}
			$prepared[ $setting_name ] = $source[ $arg_name ];
		}

		return $prepared;
	}

	public static function enqueue() {
		do_action( 'jet-form-builder/color-picker/before-enqueue' );

		wp_enqueue_script(
			Plugin::instance()->slug . '-colorpicker-lib',
			Plugin::instance()->plugin_url( 'assets/lib/spectrum.min.js' ),
			array( 'wp-hooks' ),
			'2.0.8',
			true
		);
		wp_enqueue_style(
			Plugin::instance()->slug . '-colorpicker-lib',
			Plugin::instance()->plugin_url( 'assets/lib/spectrum.min.css' ),
			array(),
			'2.0.8'
		);

		// jfb 3.0.0
		if ( class_exists( '\Jet_Form_Builder\Blocks\Validation' ) && jet_fb_live()->form_id ) {
			wp_enqueue_script(
				Plugin::instance()->slug . '-jfb',
				Plugin::instance()->plugin_url( 'assets/dist/jfb.frontend.js' ),
				array( 'jet-form-builder-frontend-forms' ),
				Plugin::instance()->get_version(),
				true
			);
		}

		// need to be enqueued only for jet-engine form
		if ( ( function_exists( 'jet_fb_live' ) &&
				! jet_fb_live()->form_id
			) ||
			! function_exists( 'jet_fb_live' )
		) {
			wp_enqueue_script(
				Plugin::instance()->slug,
				Plugin::instance()->plugin_url( 'assets/js/colorpicker.js' ),
				array(),
				Plugin::instance()->get_version(),
				true
			);
		}

		do_action( 'jet-form-builder/color-picker/after-enqueue' );
	}

}
