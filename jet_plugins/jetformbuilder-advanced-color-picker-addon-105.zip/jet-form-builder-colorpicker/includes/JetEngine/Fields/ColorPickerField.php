<?php


namespace Jet_FB_ColorPicker\JetEngine\Fields;

use JetColorPickerCore\JetEngine\SingleField;

class ColorPickerField extends SingleField {

	/**
	 * @return string
	 */
	public function get_name() {
		return 'color_picker_field';
	}

	/**
	 * @return string
	 */
	public function get_title() {
		return __( 'Color Picker Field', 'jet-form-builder-colorpicker' );
	}

	public function render_instance() {
		return new ColorPickerFieldRender( $this );
	}

	public function get_template() {
		return $this->render_instance()->set_up()->complete_render();
	}

}
