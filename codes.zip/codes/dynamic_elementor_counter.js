//CODE FOR 2 DIFFERENT CAOUNTERS TO UPDATED THE VALUES WITH DIFFERENT INTERVAL VALUES, PER DAY. 
(function () {
    const counters = [
      {
        id: "counter-timer-breaks",
        baseValue: 720,
        incrementPerDay: 1,
        startDate: "2025-01-01T00:00:00-08:00", // PST
        formatValue: (val) => val.toLocaleString(),
      },
      {
        id: "counter-timer-repairs",
        baseValue: 7_100_000, // 7.1 million
        incrementPerDay: 7_100_000, // 7.1 million per day
        startDate: "2025-01-01T00:00:00-08:00", // PST
        formatValue: (val) => (val / 1_000_000_000).toFixed(4), // show in billions
      }
    ];

    function getCaliforniaDateNow() {
      const now = new Date();
      const utc = now.getTime() + now.getTimezoneOffset() * 60000;
      // California timezone offset - PDT (-7) or PST (-8) depending on date
      const californiaOffset = -420; // PDT (UTC-7)
      const caliTime = new Date(utc + californiaOffset * 60000);
      return caliTime;
    }

    function getCurrentValue(counter) {
      const now = getCaliforniaDateNow();
      const startDate = new Date(counter.startDate);
      const daysPassed = Math.floor((now - startDate) / (1000 * 60 * 60 * 24));
      return counter.baseValue + daysPassed * counter.incrementPerDay;
    }

    function createDigitElement(digit) {
      const wrapper = document.createElement("span");
      wrapper.className = "digit-wrapper";

      const scroll = document.createElement("span");
      scroll.className = "digit-scroll";

      for (let i = 0; i <= 9; i++) {
        const span = document.createElement("span");
        span.className = "digit";
        span.textContent = i;
        scroll.appendChild(span);
      }

      scroll.style.transform = `translateY(-${parseInt(digit)}em)`;
      wrapper.appendChild(scroll);
      return wrapper;
    }

    function renderDisplay(container, formattedStr) {
      container.innerHTML = "";

      for (const char of formattedStr) {
        if (/\d/.test(char)) {
          container.appendChild(createDigitElement(char));
        } else {
          const span = document.createElement("span");
          span.textContent = char;
          span.className = char === "," ? "comma" : "";
          container.appendChild(span);
        }
      }
    }

    function updateDigits(container, formattedStr) {
      const wrappers = container.querySelectorAll(".digit-wrapper");
      let digitIndex = 0;

      for (const char of formattedStr) {
        if (/\d/.test(char)) {
          const digit = parseInt(char);
          const scroll = wrappers[digitIndex]?.querySelector(".digit-scroll");
          if (scroll) {
            scroll.style.transform = `translateY(-${digit}em)`;
          }
          digitIndex++;
        }
      }
    }

    counters.forEach((counter) => {
      const el = document.querySelector(`#${counter.id} .elementor-counter-number`);
      if (!el) return;

      const update = () => {
        const value = getCurrentValue(counter);
        const formatted = counter.formatValue(value);

        const currentWrapperCount = el.querySelectorAll(".digit-wrapper").length;
        const newDigitCount = (formatted.match(/\d/g) || []).length;

        if (currentWrapperCount !== newDigitCount) {
          renderDisplay(el, formatted);
        } else {
          updateDigits(el, formatted);
        }
      };

      renderDisplay(el, counter.formatValue(getCurrentValue(counter)));
      setInterval(update, 1000); // Animate every second
    });
  })();
