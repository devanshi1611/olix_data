<!-- scroll till the matched woocommerce product name, category (child, parent) -->
<?php 
function custom_search()
{
?>
    <input type="text" id="live-search" placeholder="Search products, categories..." />
    <ul id="suggestions-list" style="display:none;"></ul>
    
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
jQuery(document).ready(function($) {
    function fetchPageContent() {
        let contentData = [];
        let seenSubCategories = new Set();
        let seenParentCategories = new Set();
        
        $('.sub-category-section').each(function() {
            const subCategoryName = $(this).find('.sub-category-title').text().trim();
            const parentCategory = $(this).find('.product').first().data('parent-category');
            
            $(this).find('.product').each(function() {
                const productName = $(this).find('.woocommerce-loop-product__title').text().trim();
                
                contentData.push({ name: productName, type: 'product', element: this });
                
                if (!seenSubCategories.has(subCategoryName)) {
                    contentData.push({ name: subCategoryName, type: 'subcategory', element: this });
                    seenSubCategories.add(subCategoryName);
                }
                
                if (!seenParentCategories.has(parentCategory)) {
                    contentData.push({ name: parentCategory, type: 'category', element: this });
                    seenParentCategories.add(parentCategory);
                }
            });
        });
        return contentData;
    }

    const data = fetchPageContent();
    let currentIndex = 0;
    const itemsPerPage = 5;

    function showSuggestions(startIndex, endIndex) {
        const suggestionsList = $('#suggestions-list');
        suggestionsList.empty();

        const nameSuggestions = data.filter(item => item.type !== 'description' && item.name.toLowerCase().startsWith($('#live-search').val().toLowerCase())).slice(startIndex, endIndex);

        nameSuggestions.forEach(item => {
            suggestionsList.append(`<li class="suggestion-item" data-type="${item.type}">${item.name}</li>`);
        });

        if (nameSuggestions.length > 0) {
            if (data.length > endIndex) {
                suggestionsList.append('<li id="view-more" class="view-more">View More</li>');
            }
            suggestionsList.show();
        } else {
            suggestionsList.hide();
        }
    }

    $('#live-search').on('input', function() {
        currentIndex = 0;
        showSuggestions(currentIndex, currentIndex + itemsPerPage);
    });

    $(document).on('click', '#view-more', function() {
        const totalItems = data.filter(item => item.type !== 'description' && item.name.toLowerCase().startsWith($('#live-search').val().toLowerCase())).length;
        if (currentIndex + itemsPerPage < totalItems && currentIndex + itemsPerPage < 10) {
            currentIndex += itemsPerPage;
            showSuggestions(currentIndex, currentIndex + itemsPerPage);
        }
    });

    $(document).on('click', '.suggestion-item', function() {
        const name = $(this).text();
        const suggestion = data.find(item => item.name === name);
        if (suggestion) {
            const offset = 100; // Adjust this value to match the height of your fixed header
            $('html, body').animate({
                scrollTop: $(suggestion.element).offset().top - offset
            }, 1000);
        }
        $('#suggestions-list').hide();
    });

    $(document).click(function(event) {
        if (!$(event.target).closest('#live-search, #suggestions-list').length) {
            $('#suggestions-list').hide();
        }
    });
});
</script>



<?php
}

add_shortcode("custom_search", "custom_search");