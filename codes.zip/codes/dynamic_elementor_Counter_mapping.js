 // HOMEPAGE DYNAMIC COUNTER DATA: daily-counter-data.json
  (function () {
    const mappedData = {
      "1/1": {
        "breaks": 700,
        "repairs": 7.1,
        "unit": "Million"
      },
      "1/2": {
        "breaks": 1400,
        "repairs": 14.2,
        "unit": "Million"
      },
      "1/3": {
        "breaks": 2200,
        "repairs": 21.3,
        "unit": "Million"
      },
      "1/4": {
        "breaks": 2900,
        "repairs": 28.4,
        "unit": "Million"
      },
      "1/5": {
        "breaks": 3600,
        "repairs": 35.5,
        "unit": "Million"
      },
      "1/6": {
        "breaks": 4300,
        "repairs": 42.6,
        "unit": "Million"
      },
      "1/7": {
        "breaks": 5000,
        "repairs": 49.7,
        "unit": "Million"
      },
      "1/8": {
        "breaks": 5800,
        "repairs": 56.8,
        "unit": "Million"
      },
      "1/9": {
        "breaks": 6500,
        "repairs": 63.9,
        "unit": "Million"
      },
      "1/10": {
        "breaks": 7200,
        "repairs": 71.0,
        "unit": "Million"
      },
      "1/11": {
        "breaks": 7900,
        "repairs": 78.1,
        "unit": "Million"
      },
      "1/12": {
        "breaks": 8600,
        "repairs": 85.2,
        "unit": "Million"
      },
      "1/13": {
        "breaks": 9400,
        "repairs": 92.3,
        "unit": "Million"
      },
      "1/14": {
        "breaks": 10100,
        "repairs": 99.4,
        "unit": "Million"
      },
      "1/15": {
        "breaks": 10800,
        "repairs": 106.5,
        "unit": "Million"
      },
      "1/16": {
        "breaks": 11500,
        "repairs": 113.6,
        "unit": "Million"
      },
      "1/17": {
        "breaks": 12200,
        "repairs": 120.7,
        "unit": "Million"
      },
      "1/18": {
        "breaks": 13000,
        "repairs": 127.8,
        "unit": "Million"
      },
      "1/19": {
        "breaks": 13700,
        "repairs": 134.9,
        "unit": "Million"
      },
      "1/20": {
        "breaks": 14400,
        "repairs": 142.0,
        "unit": "Million"
      },
      "1/21": {
        "breaks": 15100,
        "repairs": 149.1,
        "unit": "Million"
      },
      "1/22": {
        "breaks": 15800,
        "repairs": 156.2,
        "unit": "Million"
      },
      "1/23": {
        "breaks": 16600,
        "repairs": 163.3,
        "unit": "Million"
      },
      "1/24": {
        "breaks": 17300,
        "repairs": 170.4,
        "unit": "Million"
      },
      "1/25": {
        "breaks": 18000,
        "repairs": 177.5,
        "unit": "Million"
      },
      "1/26": {
        "breaks": 18700,
        "repairs": 184.6,
        "unit": "Million"
      },
      "1/27": {
        "breaks": 19400,
        "repairs": 191.7,
        "unit": "Million"
      },
      "1/28": {
        "breaks": 20200,
        "repairs": 198.8,
        "unit": "Million"
      },
      "1/29": {
        "breaks": 20900,
        "repairs": 205.9,
        "unit": "Million"
      },
      "1/30": {
        "breaks": 21600,
        "repairs": 213.0,
        "unit": "Million"
      },
      "1/31": {
        "breaks": 22300,
        "repairs": 220.1,
        "unit": "Million"
      },
      "2/1": {
        "breaks": 23000,
        "repairs": 227.2,
        "unit": "Million"
      },
      "2/2": {
        "breaks": 23800,
        "repairs": 234.3,
        "unit": "Million"
      },
      "2/3": {
        "breaks": 24500,
        "repairs": 241.4,
        "unit": "Million"
      },
      "2/4": {
        "breaks": 25200,
        "repairs": 248.5,
        "unit": "Million"
      },
      "2/5": {
        "breaks": 25900,
        "repairs": 255.6,
        "unit": "Million"
      },
      "2/6": {
        "breaks": 26600,
        "repairs": 262.7,
        "unit": "Million"
      },
      "2/7": {
        "breaks": 27400,
        "repairs": 269.8,
        "unit": "Million"
      },
      "2/8": {
        "breaks": 28100,
        "repairs": 276.9,
        "unit": "Million"
      },
      "2/9": {
        "breaks": 28800,
        "repairs": 284.0,
        "unit": "Million"
      },
      "2/10": {
        "breaks": 29500,
        "repairs": 291.1,
        "unit": "Million"
      },
      "2/11": {
        "breaks": 30200,
        "repairs": 298.2,
        "unit": "Million"
      },
      "2/12": {
        "breaks": 31000,
        "repairs": 305.3,
        "unit": "Million"
      },
      "2/13": {
        "breaks": 31700,
        "repairs": 312.4,
        "unit": "Million"
      },
      "2/14": {
        "breaks": 32400,
        "repairs": 319.5,
        "unit": "Million"
      },
      "2/15": {
        "breaks": 33100,
        "repairs": 326.6,
        "unit": "Million"
      },
      "2/16": {
        "breaks": 33800,
        "repairs": 333.7,
        "unit": "Million"
      },
      "2/17": {
        "breaks": 34600,
        "repairs": 340.8,
        "unit": "Million"
      },
      "2/18": {
        "breaks": 35300,
        "repairs": 347.9,
        "unit": "Million"
      },
      "2/19": {
        "breaks": 36000,
        "repairs": 355.0,
        "unit": "Million"
      },
      "2/20": {
        "breaks": 36700,
        "repairs": 362.1,
        "unit": "Million"
      },
      "2/21": {
        "breaks": 37400,
        "repairs": 369.2,
        "unit": "Million"
      },
      "2/22": {
        "breaks": 38200,
        "repairs": 376.3,
        "unit": "Million"
      },
      "2/23": {
        "breaks": 38900,
        "repairs": 383.4,
        "unit": "Million"
      },
      "2/24": {
        "breaks": 39600,
        "repairs": 390.5,
        "unit": "Million"
      },
      "2/25": {
        "breaks": 40300,
        "repairs": 397.6,
        "unit": "Million"
      },
      "2/26": {
        "breaks": 41000,
        "repairs": 404.7,
        "unit": "Million"
      },
      "2/27": {
        "breaks": 41800,
        "repairs": 411.8,
        "unit": "Million"
      },
      "2/28": {
        "breaks": 42500,
        "repairs": 418.9,
        "unit": "Million"
      },
      "3/1": {
        "breaks": 43200,
        "repairs": 426.0,
        "unit": "Million"
      },
      "3/2": {
        "breaks": 43900,
        "repairs": 433.1,
        "unit": "Million"
      },
      "3/3": {
        "breaks": 44600,
        "repairs": 440.2,
        "unit": "Million"
      },
      "3/4": {
        "breaks": 45400,
        "repairs": 447.3,
        "unit": "Million"
      },
      "3/5": {
        "breaks": 46100,
        "repairs": 454.4,
        "unit": "Million"
      },
      "3/6": {
        "breaks": 46800,
        "repairs": 461.5,
        "unit": "Million"
      },
      "3/7": {
        "breaks": 47500,
        "repairs": 468.6,
        "unit": "Million"
      },
      "3/8": {
        "breaks": 48200,
        "repairs": 475.7,
        "unit": "Million"
      },
      "3/9": {
        "breaks": 49000,
        "repairs": 482.8,
        "unit": "Million"
      },
      "3/10": {
        "breaks": 49700,
        "repairs": 489.9,
        "unit": "Million"
      },
      "3/11": {
        "breaks": 50400,
        "repairs": 497.0,
        "unit": "Million"
      },
      "3/12": {
        "breaks": 51100,
        "repairs": 504.1,
        "unit": "Million"
      },
      "3/13": {
        "breaks": 51800,
        "repairs": 511.2,
        "unit": "Million"
      },
      "3/14": {
        "breaks": 52600,
        "repairs": 518.3,
        "unit": "Million"
      },
      "3/15": {
        "breaks": 53300,
        "repairs": 525.4,
        "unit": "Million"
      },
      "3/16": {
        "breaks": 54000,
        "repairs": 532.5,
        "unit": "Million"
      },
      "3/17": {
        "breaks": 54700,
        "repairs": 539.6,
        "unit": "Million"
      },
      "3/18": {
        "breaks": 55400,
        "repairs": 546.7,
        "unit": "Million"
      },
      "3/19": {
        "breaks": 56200,
        "repairs": 553.8,
        "unit": "Million"
      },
      "3/20": {
        "breaks": 56900,
        "repairs": 560.9,
        "unit": "Million"
      },
      "3/21": {
        "breaks": 57600,
        "repairs": 568.0,
        "unit": "Million"
      },
      "3/22": {
        "breaks": 58300,
        "repairs": 575.1,
        "unit": "Million"
      },
      "3/23": {
        "breaks": 59000,
        "repairs": 582.2,
        "unit": "Million"
      },
      "3/24": {
        "breaks": 59800,
        "repairs": 589.3,
        "unit": "Million"
      },
      "3/25": {
        "breaks": 60500,
        "repairs": 596.4,
        "unit": "Million"
      },
      "3/26": {
        "breaks": 61200,
        "repairs": 603.5,
        "unit": "Million"
      },
      "3/27": {
        "breaks": 61900,
        "repairs": 610.6,
        "unit": "Million"
      },
      "3/28": {
        "breaks": 62600,
        "repairs": 617.7,
        "unit": "Million"
      },
      "3/29": {
        "breaks": 63400,
        "repairs": 624.8,
        "unit": "Million"
      },
      "3/30": {
        "breaks": 64100,
        "repairs": 631.9,
        "unit": "Million"
      },
      "3/31": {
        "breaks": 64800,
        "repairs": 639.0,
        "unit": "Million"
      },
      "4/1": {
        "breaks": 65500,
        "repairs": 646.1,
        "unit": "Million"
      },
      "4/2": {
        "breaks": 66200,
        "repairs": 653.2,
        "unit": "Million"
      },
      "4/3": {
        "breaks": 67000,
        "repairs": 660.3,
        "unit": "Million"
      },
      "4/4": {
        "breaks": 67700,
        "repairs": 667.4,
        "unit": "Million"
      },
      "4/5": {
        "breaks": 68400,
        "repairs": 674.5,
        "unit": "Million"
      },
      "4/6": {
        "breaks": 69100,
        "repairs": 681.6,
        "unit": "Million"
      },
      "4/7": {
        "breaks": 69800,
        "repairs": 688.7,
        "unit": "Million"
      },
      "4/8": {
        "breaks": 70600,
        "repairs": 695.8,
        "unit": "Million"
      },
      "4/9": {
        "breaks": 71300,
        "repairs": 702.9,
        "unit": "Million"
      },
      "4/10": {
        "breaks": 72000,
        "repairs": 710.0,
        "unit": "Million"
      },
      "4/11": {
        "breaks": 72700,
        "repairs": 717.1,
        "unit": "Million"
      },
      "4/12": {
        "breaks": 73400,
        "repairs": 724.2,
        "unit": "Million"
      },
      "4/13": {
        "breaks": 74200,
        "repairs": 731.3,
        "unit": "Million"
      },
      "4/14": {
        "breaks": 74900,
        "repairs": 738.4,
        "unit": "Million"
      },
      "4/15": {
        "breaks": 75600,
        "repairs": 745.5,
        "unit": "Million"
      },
      "4/16": {
        "breaks": 76300,
        "repairs": 752.6,
        "unit": "Million"
      },
      "4/17": {
        "breaks": 77000,
        "repairs": 759.7,
        "unit": "Million"
      },
      "4/18": {
        "breaks": 77800,
        "repairs": 766.8,
        "unit": "Million"
      },
      "4/19": {
        "breaks": 78500,
        "repairs": 773.9,
        "unit": "Million"
      },
      "4/20": {
        "breaks": 79200,
        "repairs": 781.0,
        "unit": "Million"
      },
      "4/21": {
        "breaks": 79900,
        "repairs": 788.1,
        "unit": "Million"
      },
      "4/22": {
        "breaks": 80600,
        "repairs": 795.2,
        "unit": "Million"
      },
      "4/23": {
        "breaks": 81400,
        "repairs": 802.3,
        "unit": "Million"
      },
      "4/24": {
        "breaks": 82100,
        "repairs": 809.4,
        "unit": "Million"
      },
      "4/25": {
        "breaks": 82800,
        "repairs": 816.5,
        "unit": "Million"
      },
      "4/26": {
        "breaks": 83500,
        "repairs": 823.6,
        "unit": "Million"
      },
      "4/27": {
        "breaks": 84200,
        "repairs": 830.7,
        "unit": "Million"
      },
      "4/28": {
        "breaks": 85000,
        "repairs": 837.8,
        "unit": "Million"
      },
      "4/29": {
        "breaks": 85700,
        "repairs": 844.9,
        "unit": "Million"
      },
      "4/30": {
        "breaks": 86400,
        "repairs": 852.0,
        "unit": "Million"
      },
      "5/1": {
        "breaks": 87100,
        "repairs": 859.1,
        "unit": "Million"
      },
      "5/2": {
        "breaks": 87800,
        "repairs": 866.2,
        "unit": "Million"
      },
      "5/3": {
        "breaks": 88600,
        "repairs": 873.3,
        "unit": "Million"
      },
      "5/4": {
        "breaks": 89300,
        "repairs": 880.4,
        "unit": "Million"
      },
      "5/5": {
        "breaks": 90000,
        "repairs": 887.5,
        "unit": "Million"
      },
      "5/6": {
        "breaks": 90700,
        "repairs": 894.6,
        "unit": "Million"
      },
      "5/7": {
        "breaks": 91400,
        "repairs": 901.7,
        "unit": "Million"
      },
      "5/8": {
        "breaks": 92200,
        "repairs": 908.8,
        "unit": "Million"
      },
      "5/9": {
        "breaks": 92900,
        "repairs": 915.9,
        "unit": "Million"
      },
      "5/10": {
        "breaks": 93600,
        "repairs": 923.0,
        "unit": "Million"
      },
      "5/11": {
        "breaks": 94300,
        "repairs": 930.1,
        "unit": "Million"
      },
      "5/12": {
        "breaks": 95000,
        "repairs": 937.2,
        "unit": "Million"
      },
      "5/13": {
        "breaks": 95800,
        "repairs": 944.3,
        "unit": "Million"
      },
      "5/14": {
        "breaks": 96500,
        "repairs": 951.4,
        "unit": "Million"
      },
      "5/15": {
        "breaks": 97200,
        "repairs": 958.5,
        "unit": "Million"
      },
      "5/16": {
        "breaks": 97900,
        "repairs": 965.6,
        "unit": "Million"
      },
      "5/17": {
        "breaks": 98600,
        "repairs": 972.7,
        "unit": "Million"
      },
      "5/18": {
        "breaks": 99400,
        "repairs": 979.8,
        "unit": "Million"
      },
      "5/19": {
        "breaks": 100000,
        "repairs": 986.9,
        "unit": "Million"
      },
      "5/20": {
        "breaks": 101000,
        "repairs": 994.0,
        "unit": "Million"
      },
      "5/21": {
        "breaks": 102000,
        "repairs": 1.0011,
        "unit": "Billion"
      },
      "5/22": {
        "breaks": 102000,
        "repairs": 1.0082,
        "unit": "Billion"
      },
      "5/23": {
        "breaks": 103000,
        "repairs": 1.0153,
        "unit": "Billion"
      },
      "5/24": {
        "breaks": 104000,
        "repairs": 1.0224,
        "unit": "Billion"
      },
      "5/25": {
        "breaks": 104000,
        "repairs": 1.0295,
        "unit": "Billion"
      },
      "5/26": {
        "breaks": 105000,
        "repairs": 1.0366,
        "unit": "Billion"
      },
      "5/27": {
        "breaks": 106000,
        "repairs": 1.0437,
        "unit": "Billion"
      },
      "5/28": {
        "breaks": 107000,
        "repairs": 1.0508,
        "unit": "Billion"
      },
      "5/29": {
        "breaks": 107000,
        "repairs": 1.0579,
        "unit": "Billion"
      },
      "5/30": {
        "breaks": 108000,
        "repairs": 1.065,
        "unit": "Billion"
      },
      "5/31": {
        "breaks": 109000,
        "repairs": 1.0721,
        "unit": "Billion"
      },
      "6/1": {
        "breaks": 109000,
        "repairs": 1.0792,
        "unit": "Billion"
      },
      "6/2": {
        "breaks": 110000,
        "repairs": 1.0863,
        "unit": "Billion"
      },
      "6/3": {
        "breaks": 111000,
        "repairs": 1.0934,
        "unit": "Billion"
      },
      "6/4": {
        "breaks": 112000,
        "repairs": 1.1005,
        "unit": "Billion"
      },
      "6/5": {
        "breaks": 112000,
        "repairs": 1.1076,
        "unit": "Billion"
      },
      "6/6": {
        "breaks": 113000,
        "repairs": 1.1147,
        "unit": "Billion"
      },
      "6/7": {
        "breaks": 114000,
        "repairs": 1.1218,
        "unit": "Billion"
      },
      "6/8": {
        "breaks": 114000,
        "repairs": 1.1289,
        "unit": "Billion"
      },
      "6/9": {
        "breaks": 115000,
        "repairs": 1.136,
        "unit": "Billion"
      },
      "6/10": {
        "breaks": 116000,
        "repairs": 1.1431,
        "unit": "Billion"
      },
      "6/11": {
        "breaks": 117000,
        "repairs": 1.1502,
        "unit": "Billion"
      },
      "6/12": {
        "breaks": 117000,
        "repairs": 1.1573,
        "unit": "Billion"
      },
      "6/13": {
        "breaks": 118000,
        "repairs": 1.1644,
        "unit": "Billion"
      },
      "6/14": {
        "breaks": 119000,
        "repairs": 1.1715,
        "unit": "Billion"
      },
      "6/15": {
        "breaks": 120000,
        "repairs": 1.1786,
        "unit": "Billion"
      },
      "6/16": {
        "breaks": 120000,
        "repairs": 1.1857,
        "unit": "Billion"
      },
      "6/17": {
        "breaks": 121000,
        "repairs": 1.1928,
        "unit": "Billion"
      },
      "6/18": {
        "breaks": 122000,
        "repairs": 1.1999,
        "unit": "Billion"
      },
      "6/19": {
        "breaks": 122000,
        "repairs": 1.207,
        "unit": "Billion"
      },
      "6/20": {
        "breaks": 123000,
        "repairs": 1.2141,
        "unit": "Billion"
      },
      "6/21": {
        "breaks": 124000,
        "repairs": 1.2212,
        "unit": "Billion"
      },
      "6/22": {
        "breaks": 125000,
        "repairs": 1.2283,
        "unit": "Billion"
      },
      "6/23": {
        "breaks": 125000,
        "repairs": 1.2354,
        "unit": "Billion"
      },
      "6/24": {
        "breaks": 126000,
        "repairs": 1.2425,
        "unit": "Billion"
      },
      "6/25": {
        "breaks": 127000,
        "repairs": 1.2496,
        "unit": "Billion"
      },
      "6/26": {
        "breaks": 127000,
        "repairs": 1.2567,
        "unit": "Billion"
      },
      "6/27": {
        "breaks": 128000,
        "repairs": 1.2638,
        "unit": "Billion"
      },
      "6/28": {
        "breaks": 129000,
        "repairs": 1.2709,
        "unit": "Billion"
      },
      "6/29": {
        "breaks": 130000,
        "repairs": 1.278,
        "unit": "Billion"
      },
      "6/30": {
        "breaks": 130000,
        "repairs": 1.2851,
        "unit": "Billion"
      },
      "7/1": {
        "breaks": 131000,
        "repairs": 1.2922,
        "unit": "Billion"
      },
      "7/2": {
        "breaks": 132000,
        "repairs": 1.2993,
        "unit": "Billion"
      },
      "7/3": {
        "breaks": 132000,
        "repairs": 1.3064,
        "unit": "Billion"
      },
      "7/4": {
        "breaks": 133000,
        "repairs": 1.3135,
        "unit": "Billion"
      },
      "7/5": {
        "breaks": 134000,
        "repairs": 1.3206,
        "unit": "Billion"
      },
      "7/6": {
        "breaks": 135000,
        "repairs": 1.3277,
        "unit": "Billion"
      },
      "7/7": {
        "breaks": 135000,
        "repairs": 1.3348,
        "unit": "Billion"
      },
      "7/8": {
        "breaks": 136000,
        "repairs": 1.3419,
        "unit": "Billion"
      },
      "7/9": {
        "breaks": 137000,
        "repairs": 1.349,
        "unit": "Billion"
      },
      "7/10": {
        "breaks": 138000,
        "repairs": 1.3561,
        "unit": "Billion"
      },
      "7/11": {
        "breaks": 138000,
        "repairs": 1.3632,
        "unit": "Billion"
      },
      "7/12": {
        "breaks": 139000,
        "repairs": 1.3703,
        "unit": "Billion"
      },
      "7/13": {
        "breaks": 140000,
        "repairs": 1.3774,
        "unit": "Billion"
      },
      "7/14": {
        "breaks": 140000,
        "repairs": 1.3845,
        "unit": "Billion"
      },
      "7/15": {
        "breaks": 141000,
        "repairs": 1.3916,
        "unit": "Billion"
      },
      "7/16": {
        "breaks": 142000,
        "repairs": 1.3987,
        "unit": "Billion"
      },
      "7/17": {
        "breaks": 143000,
        "repairs": 1.4058,
        "unit": "Billion"
      },
      "7/18": {
        "breaks": 143000,
        "repairs": 1.4129,
        "unit": "Billion"
      },
      "7/19": {
        "breaks": 144000,
        "repairs": 1.42,
        "unit": "Billion"
      },
      "7/20": {
        "breaks": 145000,
        "repairs": 1.4271,
        "unit": "Billion"
      },
      "7/21": {
        "breaks": 145000,
        "repairs": 1.4342,
        "unit": "Billion"
      },
      "7/22": {
        "breaks": 146000,
        "repairs": 1.4413,
        "unit": "Billion"
      },
      "7/23": {
        "breaks": 147000,
        "repairs": 1.4484,
        "unit": "Billion"
      },
      "7/24": {
        "breaks": 148000,
        "repairs": 1.4555,
        "unit": "Billion"
      },
      "7/25": {
        "breaks": 148000,
        "repairs": 1.4626,
        "unit": "Billion"
      },
      "7/26": {
        "breaks": 149000,
        "repairs": 1.4697,
        "unit": "Billion"
      },
      "7/27": {
        "breaks": 150000,
        "repairs": 1.4768,
        "unit": "Billion"
      },
      "7/28": {
        "breaks": 150000,
        "repairs": 1.4839,
        "unit": "Billion"
      },
      "7/29": {
        "breaks": 151000,
        "repairs": 1.491,
        "unit": "Billion"
      },
      "7/30": {
        "breaks": 152000,
        "repairs": 1.4981,
        "unit": "Billion"
      },
      "7/31": {
        "breaks": 153000,
        "repairs": 1.5052,
        "unit": "Billion"
      },
      "8/1": {
        "breaks": 153000,
        "repairs": 1.5123,
        "unit": "Billion"
      },
      "8/2": {
        "breaks": 154000,
        "repairs": 1.5194,
        "unit": "Billion"
      },
      "8/3": {
        "breaks": 155000,
        "repairs": 1.5265,
        "unit": "Billion"
      },
      "8/4": {
        "breaks": 156000,
        "repairs": 1.5336,
        "unit": "Billion"
      },
      "8/5": {
        "breaks": 156000,
        "repairs": 1.5407,
        "unit": "Billion"
      },
      "8/6": {
        "breaks": 157000,
        "repairs": 1.5478,
        "unit": "Billion"
      },
      "8/7": {
        "breaks": 158000,
        "repairs": 1.5549,
        "unit": "Billion"
      },
      "8/8": {
        "breaks": 158000,
        "repairs": 1.562,
        "unit": "Billion"
      },
      "8/9": {
        "breaks": 159000,
        "repairs": 1.5691,
        "unit": "Billion"
      },
      "8/10": {
        "breaks": 160000,
        "repairs": 1.5762,
        "unit": "Billion"
      },
      "8/11": {
        "breaks": 161000,
        "repairs": 1.5833,
        "unit": "Billion"
      },
      "8/12": {
        "breaks": 161000,
        "repairs": 1.5904,
        "unit": "Billion"
      },
      "8/13": {
        "breaks": 162000,
        "repairs": 1.5975,
        "unit": "Billion"
      },
      "8/14": {
        "breaks": 163000,
        "repairs": 1.6046,
        "unit": "Billion"
      },
      "8/15": {
        "breaks": 163000,
        "repairs": 1.6117,
        "unit": "Billion"
      },
      "8/16": {
        "breaks": 164000,
        "repairs": 1.6188,
        "unit": "Billion"
      },
      "8/17": {
        "breaks": 165000,
        "repairs": 1.6259,
        "unit": "Billion"
      },
      "8/18": {
        "breaks": 166000,
        "repairs": 1.633,
        "unit": "Billion"
      },
      "8/19": {
        "breaks": 166000,
        "repairs": 1.6401,
        "unit": "Billion"
      },
      "8/20": {
        "breaks": 167000,
        "repairs": 1.6472,
        "unit": "Billion"
      },
      "8/21": {
        "breaks": 168000,
        "repairs": 1.6543,
        "unit": "Billion"
      },
      "8/22": {
        "breaks": 168000,
        "repairs": 1.6614,
        "unit": "Billion"
      },
      "8/23": {
        "breaks": 169000,
        "repairs": 1.6685,
        "unit": "Billion"
      },
      "8/24": {
        "breaks": 170000,
        "repairs": 1.6756,
        "unit": "Billion"
      },
      "8/25": {
        "breaks": 171000,
        "repairs": 1.6827,
        "unit": "Billion"
      },
      "8/26": {
        "breaks": 171000,
        "repairs": 1.6898,
        "unit": "Billion"
      },
      "8/27": {
        "breaks": 172000,
        "repairs": 1.6969,
        "unit": "Billion"
      },
      "8/28": {
        "breaks": 173000,
        "repairs": 1.704,
        "unit": "Billion"
      },
      "8/29": {
        "breaks": 174000,
        "repairs": 1.7111,
        "unit": "Billion"
      },
      "8/30": {
        "breaks": 174000,
        "repairs": 1.7182,
        "unit": "Billion"
      },
      "8/31": {
        "breaks": 175000,
        "repairs": 1.7253,
        "unit": "Billion"
      },
      "9/1": {
        "breaks": 176000,
        "repairs": 1.7324,
        "unit": "Billion"
      },
      "9/2": {
        "breaks": 176000,
        "repairs": 1.7395,
        "unit": "Billion"
      },
      "9/3": {
        "breaks": 177000,
        "repairs": 1.7466,
        "unit": "Billion"
      },
      "9/4": {
        "breaks": 178000,
        "repairs": 1.7537,
        "unit": "Billion"
      },
      "9/5": {
        "breaks": 179000,
        "repairs": 1.7608,
        "unit": "Billion"
      },
      "9/6": {
        "breaks": 179000,
        "repairs": 1.7679,
        "unit": "Billion"
      },
      "9/7": {
        "breaks": 180000,
        "repairs": 1.775,
        "unit": "Billion"
      },
      "9/8": {
        "breaks": 181000,
        "repairs": 1.7821,
        "unit": "Billion"
      },
      "9/9": {
        "breaks": 181000,
        "repairs": 1.7892,
        "unit": "Billion"
      },
      "9/10": {
        "breaks": 182000,
        "repairs": 1.7963,
        "unit": "Billion"
      },
      "9/11": {
        "breaks": 183000,
        "repairs": 1.8034,
        "unit": "Billion"
      },
      "9/12": {
        "breaks": 184000,
        "repairs": 1.8105,
        "unit": "Billion"
      },
      "9/13": {
        "breaks": 184000,
        "repairs": 1.8176,
        "unit": "Billion"
      },
      "9/14": {
        "breaks": 185000,
        "repairs": 1.8247,
        "unit": "Billion"
      },
      "9/15": {
        "breaks": 186000,
        "repairs": 1.8318,
        "unit": "Billion"
      },
      "9/16": {
        "breaks": 186000,
        "repairs": 1.8389,
        "unit": "Billion"
      },
      "9/17": {
        "breaks": 187000,
        "repairs": 1.846,
        "unit": "Billion"
      },
      "9/18": {
        "breaks": 188000,
        "repairs": 1.8531,
        "unit": "Billion"
      },
      "9/19": {
        "breaks": 189000,
        "repairs": 1.8602,
        "unit": "Billion"
      },
      "9/20": {
        "breaks": 189000,
        "repairs": 1.8673,
        "unit": "Billion"
      },
      "9/21": {
        "breaks": 190000,
        "repairs": 1.8744,
        "unit": "Billion"
      },
      "9/22": {
        "breaks": 191000,
        "repairs": 1.8815,
        "unit": "Billion"
      },
      "9/23": {
        "breaks": 192000,
        "repairs": 1.8886,
        "unit": "Billion"
      },
      "9/24": {
        "breaks": 192000,
        "repairs": 1.8957,
        "unit": "Billion"
      },
      "9/25": {
        "breaks": 193000,
        "repairs": 1.9028,
        "unit": "Billion"
      },
      "9/26": {
        "breaks": 194000,
        "repairs": 1.9099,
        "unit": "Billion"
      },
      "9/27": {
        "breaks": 194000,
        "repairs": 1.917,
        "unit": "Billion"
      },
      "9/28": {
        "breaks": 195000,
        "repairs": 1.9241,
        "unit": "Billion"
      },
      "9/29": {
        "breaks": 196000,
        "repairs": 1.9312,
        "unit": "Billion"
      },
      "9/30": {
        "breaks": 197000,
        "repairs": 1.9383,
        "unit": "Billion"
      },
      "10/1": {
        "breaks": 197000,
        "repairs": 1.9454,
        "unit": "Billion"
      },
      "10/2": {
        "breaks": 198000,
        "repairs": 1.9525,
        "unit": "Billion"
      },
      "10/3": {
        "breaks": 199000,
        "repairs": 1.9596,
        "unit": "Billion"
      },
      "10/4": {
        "breaks": 199000,
        "repairs": 1.9667,
        "unit": "Billion"
      },
      "10/5": {
        "breaks": 200000,
        "repairs": 1.9738,
        "unit": "Billion"
      },
      "10/6": {
        "breaks": 201000,
        "repairs": 1.9809,
        "unit": "Billion"
      },
      "10/7": {
        "breaks": 202000,
        "repairs": 1.988,
        "unit": "Billion"
      },
      "10/8": {
        "breaks": 202000,
        "repairs": 1.9951,
        "unit": "Billion"
      },
      "10/9": {
        "breaks": 203000,
        "repairs": 2.0022,
        "unit": "Billion"
      },
      "10/10": {
        "breaks": 204000,
        "repairs": 2.0093,
        "unit": "Billion"
      },
      "10/11": {
        "breaks": 204000,
        "repairs": 2.0164,
        "unit": "Billion"
      },
      "10/12": {
        "breaks": 205000,
        "repairs": 2.0235,
        "unit": "Billion"
      },
      "10/13": {
        "breaks": 206000,
        "repairs": 2.0306,
        "unit": "Billion"
      },
      "10/14": {
        "breaks": 207000,
        "repairs": 2.0377,
        "unit": "Billion"
      },
      "10/15": {
        "breaks": 207000,
        "repairs": 2.0448,
        "unit": "Billion"
      },
      "10/16": {
        "breaks": 208000,
        "repairs": 2.0519,
        "unit": "Billion"
      },
      "10/17": {
        "breaks": 209000,
        "repairs": 2.059,
        "unit": "Billion"
      },
      "10/18": {
        "breaks": 210000,
        "repairs": 2.0661,
        "unit": "Billion"
      },
      "10/19": {
        "breaks": 210000,
        "repairs": 2.0732,
        "unit": "Billion"
      },
      "10/20": {
        "breaks": 211000,
        "repairs": 2.0803,
        "unit": "Billion"
      },
      "10/21": {
        "breaks": 212000,
        "repairs": 2.0874,
        "unit": "Billion"
      },
      "10/22": {
        "breaks": 212000,
        "repairs": 2.0945,
        "unit": "Billion"
      },
      "10/23": {
        "breaks": 213000,
        "repairs": 2.1016,
        "unit": "Billion"
      },
      "10/24": {
        "breaks": 214000,
        "repairs": 2.1087,
        "unit": "Billion"
      },
      "10/25": {
        "breaks": 215000,
        "repairs": 2.1158,
        "unit": "Billion"
      },
      "10/26": {
        "breaks": 215000,
        "repairs": 2.1229,
        "unit": "Billion"
      },
      "10/27": {
        "breaks": 216000,
        "repairs": 2.13,
        "unit": "Billion"
      },
      "10/28": {
        "breaks": 217000,
        "repairs": 2.1371,
        "unit": "Billion"
      },
      "10/29": {
        "breaks": 217000,
        "repairs": 2.1442,
        "unit": "Billion"
      },
      "10/30": {
        "breaks": 218000,
        "repairs": 2.1513,
        "unit": "Billion"
      },
      "10/31": {
        "breaks": 219000,
        "repairs": 2.1584,
        "unit": "Billion"
      },
      "11/1": {
        "breaks": 220000,
        "repairs": 2.1655,
        "unit": "Billion"
      },
      "11/2": {
        "breaks": 220000,
        "repairs": 2.1726,
        "unit": "Billion"
      },
      "11/3": {
        "breaks": 221000,
        "repairs": 2.1797,
        "unit": "Billion"
      },
      "11/4": {
        "breaks": 222000,
        "repairs": 2.1868,
        "unit": "Billion"
      },
      "11/5": {
        "breaks": 222000,
        "repairs": 2.1939,
        "unit": "Billion"
      },
      "11/6": {
        "breaks": 223000,
        "repairs": 2.201,
        "unit": "Billion"
      },
      "11/7": {
        "breaks": 224000,
        "repairs": 2.2081,
        "unit": "Billion"
      },
      "11/8": {
        "breaks": 225000,
        "repairs": 2.2152,
        "unit": "Billion"
      },
      "11/9": {
        "breaks": 225000,
        "repairs": 2.2223,
        "unit": "Billion"
      },
      "11/10": {
        "breaks": 226000,
        "repairs": 2.2294,
        "unit": "Billion"
      },
      "11/11": {
        "breaks": 227000,
        "repairs": 2.2365,
        "unit": "Billion"
      },
      "11/12": {
        "breaks": 228000,
        "repairs": 2.2436,
        "unit": "Billion"
      },
      "11/13": {
        "breaks": 228000,
        "repairs": 2.2507,
        "unit": "Billion"
      },
      "11/14": {
        "breaks": 229000,
        "repairs": 2.2578,
        "unit": "Billion"
      },
      "11/15": {
        "breaks": 230000,
        "repairs": 2.2649,
        "unit": "Billion"
      },
      "11/16": {
        "breaks": 230000,
        "repairs": 2.272,
        "unit": "Billion"
      },
      "11/17": {
        "breaks": 231000,
        "repairs": 2.2791,
        "unit": "Billion"
      },
      "11/18": {
        "breaks": 232000,
        "repairs": 2.2862,
        "unit": "Billion"
      },
      "11/19": {
        "breaks": 233000,
        "repairs": 2.2933,
        "unit": "Billion"
      },
      "11/20": {
        "breaks": 233000,
        "repairs": 2.3004,
        "unit": "Billion"
      },
      "11/21": {
        "breaks": 234000,
        "repairs": 2.3075,
        "unit": "Billion"
      },
      "11/22": {
        "breaks": 235000,
        "repairs": 2.3146,
        "unit": "Billion"
      },
      "11/23": {
        "breaks": 235000,
        "repairs": 2.3217,
        "unit": "Billion"
      },
      "11/24": {
        "breaks": 236000,
        "repairs": 2.3288,
        "unit": "Billion"
      },
      "11/25": {
        "breaks": 237000,
        "repairs": 2.3359,
        "unit": "Billion"
      },
      "11/26": {
        "breaks": 238000,
        "repairs": 2.343,
        "unit": "Billion"
      },
      "11/27": {
        "breaks": 238000,
        "repairs": 2.3501,
        "unit": "Billion"
      },
      "11/28": {
        "breaks": 239000,
        "repairs": 2.3572,
        "unit": "Billion"
      },
      "11/29": {
        "breaks": 240000,
        "repairs": 2.3643,
        "unit": "Billion"
      },
      "11/30": {
        "breaks": 240000,
        "repairs": 2.3714,
        "unit": "Billion"
      },
      "12/1": {
        "breaks": 241000,
        "repairs": 2.3785,
        "unit": "Billion"
      },
      "12/2": {
        "breaks": 242000,
        "repairs": 2.3856,
        "unit": "Billion"
      },
      "12/3": {
        "breaks": 243000,
        "repairs": 2.3927,
        "unit": "Billion"
      },
      "12/4": {
        "breaks": 243000,
        "repairs": 2.3998,
        "unit": "Billion"
      },
      "12/5": {
        "breaks": 244000,
        "repairs": 2.4069,
        "unit": "Billion"
      },
      "12/6": {
        "breaks": 245000,
        "repairs": 2.414,
        "unit": "Billion"
      },
      "12/7": {
        "breaks": 246000,
        "repairs": 2.4211,
        "unit": "Billion"
      },
      "12/8": {
        "breaks": 246000,
        "repairs": 2.4282,
        "unit": "Billion"
      },
      "12/9": {
        "breaks": 247000,
        "repairs": 2.4353,
        "unit": "Billion"
      },
      "12/10": {
        "breaks": 248000,
        "repairs": 2.4424,
        "unit": "Billion"
      },
      "12/11": {
        "breaks": 248000,
        "repairs": 2.4495,
        "unit": "Billion"
      },
      "12/12": {
        "breaks": 249000,
        "repairs": 2.4566,
        "unit": "Billion"
      },
      "12/13": {
        "breaks": 250000,
        "repairs": 2.4637,
        "unit": "Billion"
      },
      "12/14": {
        "breaks": 251000,
        "repairs": 2.4708,
        "unit": "Billion"
      },
      "12/15": {
        "breaks": 251000,
        "repairs": 2.4779,
        "unit": "Billion"
      },
      "12/16": {
        "breaks": 252000,
        "repairs": 2.485,
        "unit": "Billion"
      },
      "12/17": {
        "breaks": 253000,
        "repairs": 2.4921,
        "unit": "Billion"
      },
      "12/18": {
        "breaks": 253000,
        "repairs": 2.4992,
        "unit": "Billion"
      },
      "12/19": {
        "breaks": 254000,
        "repairs": 2.5063,
        "unit": "Billion"
      },
      "12/20": {
        "breaks": 255000,
        "repairs": 2.5134,
        "unit": "Billion"
      },
      "12/21": {
        "breaks": 256000,
        "repairs": 2.5205,
        "unit": "Billion"
      },
      "12/22": {
        "breaks": 256000,
        "repairs": 2.5276,
        "unit": "Billion"
      },
      "12/23": {
        "breaks": 257000,
        "repairs": 2.5347,
        "unit": "Billion"
      },
      "12/24": {
        "breaks": 258000,
        "repairs": 2.5418,
        "unit": "Billion"
      },
      "12/25": {
        "breaks": 258000,
        "repairs": 2.5489,
        "unit": "Billion"
      },
      "12/26": {
        "breaks": 259000,
        "repairs": 2.556,
        "unit": "Billion"
      },
      "12/27": {
        "breaks": 260000,
        "repairs": 2.5631,
        "unit": "Billion"
      },
      "12/28": {
        "breaks": 261000,
        "repairs": 2.5702,
        "unit": "Billion"
      },
      "12/29": {
        "breaks": 261000,
        "repairs": 2.5773,
        "unit": "Billion"
      },
      "12/30": {
        "breaks": 262000,
        "repairs": 2.5844,
        "unit": "Billion"
      },
      "12/31": {
        "breaks": 263000,
        "repairs": 2.5915,
        "unit": "Billion"
      }
    };

    function getCaliforniaDateKey() {
      const formatter = new Intl.DateTimeFormat("en-US", {
        timeZone: "America/Los_Angeles",
        month: "numeric",
        day: "numeric"
      });
      return formatter.format(new Date()); // returns "6/4"
    }

    function waitForElement(selector, callback) {
      const el = document.querySelector(selector);
      if (el) return callback(el);

      const observer = new MutationObserver(() => {
        const el = document.querySelector(selector);
        if (el) {
          observer.disconnect();
          callback(el);
        }
      });
      observer.observe(document.body, { childList: true, subtree: true });
    }

    function renderValue(el, value, unit, isRepair = false) {
      if (!el) return;
      if (isRepair) {
        el.innerText = `$${value.toFixed(1)} ${unit}/day`;
      } else {
        el.innerText = `${value.toLocaleString()} breaks/day`;
      }
    }

    window.addEventListener("load", () => {

      const todayKey = getCaliforniaDateKey();
      const todayData = mappedData[todayKey] || mappedData[Object.keys(mappedData).pop()];

      waitForElement("#counter-timer-breaks .elementor-counter-number", (el) => {
        renderValue(el, todayData.breaks, null, false);
      });

      waitForElement("#counter-timer-repairs .elementor-counter-number", (el) => {
        renderValue(el, todayData.repairs, todayData.unit, true);
      });

    });

  })();