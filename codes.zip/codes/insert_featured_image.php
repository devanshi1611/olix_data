<?php

require_once(ABSPATH . 'wp-admin/includes/image.php');
require_once(ABSPATH . 'wp-includes/pluggable.php');


if (isset($_FILES['event_featured_image']) && !empty($_FILES['event_featured_image']['name'])) {
    // Handle the file upload
    $file = $_FILES['event_featured_image'];
    echo "<pre>";
    print_r($file);
    echo "</pre>"; // Debug: Output the uploaded file array

    $upload_overrides = array('test_form' => false); // Bypass form validation
    echo "Upload overrides: <pre>";
    print_r($upload_overrides);
    echo "</pre>"; // Debug: Output the upload overrides

    // Handle the upload
    $uploaded_file = wp_handle_upload($file, $upload_overrides);
    echo "Uploaded file data: <pre>";
    print_r($uploaded_file);
    echo "</pre>"; // Debug: Output the uploaded file result

    if (isset($uploaded_file['file'])) {
        // File was uploaded successfully, insert into media library
        echo "File path: " . $uploaded_file['file'] . "<br>"; // Debug: Output the file path
        $file_type = wp_check_filetype($uploaded_file['file']);
        echo "File type: <pre>";
        print_r($file_type);
        echo "</pre>"; // Debug: Output file type

        $attachment = array(
            'guid' => $uploaded_file['url'],
            'post_mime_type' => $file_type['type'],
            'post_title' => sanitize_file_name($file['name']),
            'post_content' => '',
            'post_status' => 'inherit'
        );
        echo "Attachment data: <pre>";
        print_r($attachment);
        echo "</pre>"; // Debug: Output attachment array

        // Insert the attachment
        $attachment_id = wp_insert_attachment($attachment, $uploaded_file['file'], $event_id);
        echo "Attachment ID: " . $attachment_id . "<br>"; // Debug: Output attachment ID

        if (is_wp_error($attachment_id)) {
            echo "❌ Error inserting attachment: " . $attachment_id->get_error_message() . "<br>";
            return;
        }

        // Check if the file exists
        if (!file_exists($uploaded_file['file'])) {
            echo "❌ Error: Uploaded file does not exist at path " . $uploaded_file['file'] . "<br>";
            return;
        }

        // ✅ Step 1: Generate Metadata
        require_once(ABSPATH . 'wp-admin/includes/image.php'); // Ensure function availability
        $attachment_metadata = wp_generate_attachment_metadata($attachment_id, $uploaded_file['file']);
        
        echo "Generated Metadata: <pre>";
        print_r($attachment_metadata);
        echo "</pre>";

        if (empty($attachment_metadata)) {
            echo "❌ Error generating attachment metadata.<br>";
            return;
        }

        // ✅ Step 2: Update Metadata
        $update_metadata = wp_update_attachment_metadata($attachment_id, $attachment_metadata);
        if (!$update_metadata) {
            echo "❌ Error updating metadata. Checking post meta:<br>";
            $existing_meta = get_post_meta($attachment_id, '_wp_attachment_metadata', true);
            echo "<pre>";
            print_r($existing_meta);
            echo "</pre>";
        }
        

        // ✅ Step 3: Set Post Thumbnail
        $set_thumbnail = set_post_thumbnail($event_id, $attachment_id);
        echo "Set Post Thumbnail Result: ";
        var_dump($set_thumbnail);
        echo "<br>";

        if (!$set_thumbnail) {
            echo "❌ Error setting post thumbnail.<br>";
            return;
        }

        echo "✅ File uploaded and set as thumbnail!";
    } else {
        echo "❌ File upload failed.";
    }
}
die("stop");