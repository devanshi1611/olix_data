<?php

?>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        var multiselect = document.getElementById('custom-multiselect');
        var selectedOptionsContainer = document.getElementById('selected-options-container');
        var checkboxes = document.querySelectorAll('form input[type="checkbox"]');

        // Initialize an empty array to store selected values
        var selectedValues = [];

        // Function to add the latest selected value to selectedValues
        function addSelectedValue(selectedValue) {
            console.log("addSelectedValue",addSelectedValue);
            // Add the value to selectedValues array if it's not already present
            if (!selectedValues.includes(selectedValue)) {
                selectedValues.push(selectedValue);
            }
            // Update the checkboxes to reflect the selected values
            updateCheckboxes();
        }

        // Function to update the checkboxes based on the selected values
        function updateCheckboxes() {
            // Iterate through each checkbox
            checkboxes.forEach(function(checkbox) {
                // Check the checkbox if its value is in selectedValues
                if (selectedValues.includes(checkbox.value)) {
                    checkbox.checked = true;
                }
            });
        }

        // Function to sort the options in the multiselect dropdown
        function sortDropdownOptions() {
            var options = Array.from(multiselect.options);
            options.sort(function(a, b) {
                return a.text.localeCompare(b.text);
            });
            multiselect.innerHTML = ''; // Clear the current options
            options.forEach(function(option) {
                multiselect.appendChild(option); // Append sorted options
            });
        }

        multiselect.addEventListener('change', function() {
            var selectedValue = multiselect.value;
            var selectedText = multiselect.options[multiselect.selectedIndex].text;
            console.log("selected option -> " + selectedValue);

            // Add the selected value to the selectedValues array and update checkboxes
            addSelectedValue(selectedValue);

            if (selectedValue !== "" && !Array.from(selectedOptionsContainer.children).some(option => option.dataset.value === selectedValue)) {
                var optionElement = document.createElement('div');
                optionElement.classList.add('selected-option');
                optionElement.dataset.value = selectedValue;
                optionElement.textContent = selectedText;

                var removeOption = document.createElement('span');
                removeOption.classList.add('remove-option');
                removeOption.textContent = 'x';
                removeOption.addEventListener('click', function() {
                    optionElement.remove();
                    console.log("removeOption -> " + selectedValue);

                    // Re-add the option back to the select dropdown when removed from selected options
                    var newOption = document.createElement('option');
                    newOption.value = selectedValue;
                    newOption.textContent = selectedText;
                    multiselect.appendChild(newOption);

                    // Sort the dropdown options
                    sortDropdownOptions();

                    // Remove the value from selectedValues array
                    selectedValues = selectedValues.filter(function(v) {
                        return v !== selectedValue;
                    });

                    // Uncheck the corresponding checkbox
                    checkboxes.forEach(function(checkbox) {
                        if (checkbox.value === selectedValue) {
                            checkbox.checked = false;
                        }
                    });
                });

                optionElement.appendChild(removeOption);
                selectedOptionsContainer.appendChild(optionElement);

                // Remove selected option from the dropdown
                multiselect.querySelector(`option[value="${selectedValue}"]`).remove();

                multiselect.value = ''; // Reset select to placeholder
            }
        });
    });
</script>
<div id="multiselect-container">
    <label>Counties of operation</label>
    <div id="selected-options-container"></div>
    <select id="custom-multiselect">
        <option value="Albania">Albania</option>
        <option value="Bahrain">Bahrain</option>
        <option value="Cabo Verde">Cabo Verde</option>
        <option value="Denmark">Denmark</option>
        <option value="France">France</option>
        <option value="Gabon">Gabon</option>
        <option value="Hungary">Hungary</option>
    </select>
</div>

<div class="elementor-field-type-checkbox elementor-field-group elementor-column elementor-field-group-countries_of_operation_multi_select elementor-col-100">
    <label for="form-field-countries_of_operation_multi_select" class="elementor-field-label">
        Countries of operation </label>
    <div class="elementor-field-subgroup  elementor-subgroup-inline"><span class="elementor-field-option"><input type="checkbox" value="Albania" id="form-field-countries_of_operation_multi_select-0" name="form_fields[countries_of_operation_multi_select][]"> <label for="form-field-countries_of_operation_multi_select-0">Albania</label></span><span class="elementor-field-option"><input type="checkbox" value="Bahrain" id="form-field-countries_of_operation_multi_select-1" name="form_fields[countries_of_operation_multi_select][]"> <label for="form-field-countries_of_operation_multi_select-1">Bahrain</label></span><span class="elementor-field-option"><input type="checkbox" value="Cabo Verde" id="form-field-countries_of_operation_multi_select-2" name="form_fields[countries_of_operation_multi_select][]"> <label for="form-field-countries_of_operation_multi_select-2">Cabo Verde</label></span><span class="elementor-field-option"><input type="checkbox" value="Denmark" id="form-field-countries_of_operation_multi_select-3" name="form_fields[countries_of_operation_multi_select][]"> <label for="form-field-countries_of_operation_multi_select-3">Denmark</label></span><span class="elementor-field-option"><input type="checkbox" value="France" id="form-field-countries_of_operation_multi_select-4" name="form_fields[countries_of_operation_multi_select][]"> <label for="form-field-countries_of_operation_multi_select-4">France</label></span><span class="elementor-field-option"><input type="checkbox" value="Gabon" id="form-field-countries_of_operation_multi_select-5" name="form_fields[countries_of_operation_multi_select][]"> <label for="form-field-countries_of_operation_multi_select-5">Gabon</label></span><span class="elementor-field-option"><input type="checkbox" value="Hungary" id="form-field-countries_of_operation_multi_select-6" name="form_fields[countries_of_operation_multi_select][]"> <label for="form-field-countries_of_operation_multi_select-6">Hungary</label></span></div>
</div>

<style>
    #multiselect-container #selected-options-container {
        display: flex;
        flex-wrap: wrap;
        margin-bottom: 0px;
    }

    #multiselect-container {
        width: 100%;
        display: flex;
        flex-direction: column;
        padding: 0 5px;
        margin-bottom: 20px;
    }

    #multiselect-container .selected-option {
        background-color: #2b7939;
        color: #fff;
        padding: 10px 20px;
        margin-right: 5px;
        margin-bottom: 5px;
        border-radius: 50px;
        display: inline-flex;
        align-items: center;
        font-size: 16px;
        line-height: normal;
        font-family: "Poppins", Sans-serif;
        font-weight: 400;
    }

    #multiselect-container .selected-option .remove-option {
        cursor: pointer;
        margin-left: 5px;
        font-weight: bold;
        font-family: "Poppins", Sans-serif;
    }

    #multiselect-container #custom-multiselect {
        background-color: transparent;
        border-radius: 5px 5px 5px 5px;
        width: 100%;
        max-width: 100%;
        border: 1px solid #69727d;
        background-color: transparent;
        color: #1f2124;
        vertical-align: middle;
        flex-grow: 1;
        padding: 7px 20px 7px 14px;
    }

    #multiselect-container #custom-multiselect option {
        font-family: "Poppins", Sans-serif;
        font-weight: 400;
    }

    #multiselect-container label {
        font-family: "Poppins", Sans-serif;
        font-size: 16px;
        font-weight: 400;
        line-height: 27.2px;
        padding-bottom: 5px;
        color: black;
    }
</style>