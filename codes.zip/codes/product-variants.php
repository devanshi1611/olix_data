<?php

// this is the shortcode to display all the variants of all variable products

// Function to fetch and display a specific variant of a product dynamically
add_shortcode('display_variant', 'display_variant_shortcode');
function display_variant_shortcode($atts) {
    $atts = shortcode_atts(
        array(
            'product_name' => 'cosmetics', // Default product name
            'attribute'    => 'type',      // Default attribute
            'value'        => 't1'         // Default attribute value
        ),
        $atts,
        'display_variant'
    );

    ob_start();

    // Replace with dynamic product fetching logic if needed
    $product_id = 62; // You can replace this with dynamic logic if needed
    $product = wc_get_product($product_id);

    if ($product && $product->is_type('variable')) {
        $variations = $product->get_available_variations();
        foreach ($variations as $variation) {
            $variation_obj = new WC_Product_Variation($variation['variation_id']);
            $attributes = $variation_obj->get_attributes();

            // if (isset($attributes['attribute_' . $atts['attribute']]) && $attributes['attribute_' . $atts['attribute']] == $atts['value']) {
                // Product name
                echo '<div class="product_title">';
                echo '<h1 class="woocommerce-loop-product__title">' . $product->get_name() . '</h1>';
                echo '</div>';

                // Product image and description
                echo '<div class="product-image-description-row">';
                echo '<div class="product-image">' . $variation_obj->get_image() . '</div>';
                echo '<div class="product-description"><div class="product-details"><ul>';
                $description = $variation_obj->get_description();
                foreach (explode("\n", $description) as $line) {
                    echo "<li>" . trim($line) . "</li>";
                }
                echo '</ul></div></div>';
                echo '</div>';

                // Buy button
                echo '<div class="product-price">';
                echo '<a href="' . esc_url($variation_obj->add_to_cart_url()) . '" class="button">Buy On Amazon - ' . $variation_obj->get_price_html() . '</a>';
                echo '</div>';

                // Static content
                $items = [
                    ['text' => 'Wirecutter', 'link' => 'https://example.com/link1'],
                    ['text' => 'Popular Mechanics', 'link' => 'https://example.com/link2'],
                    ['text' => 'BH&G', 'link' => 'https://example.com/link3'],
                    ['text' => 'Project Farm', 'link' => 'https://example.com/link4'],
                    ['text' => 'Gear Lab', 'link' => 'https://example.com/link5'],
                    ['text' => 'NY Magazine', 'link' => 'https://example.com/link6']
                ];

                echo '<div class="text"><p>Why did we choose this? Rated as a “best of” top pick by:</p></div>';
                echo '<div class="container"><div class="row">';
                foreach ($items as $item) {
                    echo '<div class="col-lg-4 col-md-4 col-4">';
                    echo '    <div class="grid-box">';
                    echo '        <a href="' . htmlspecialchars($item['link']) . '" target="_blank">';
                    echo '            <p>' . htmlspecialchars($item['text']) . '</p>';
                    echo '            <img src="' . get_stylesheet_directory_uri() . '/images/square.png" alt="Icon">';
                    echo '        </a>';
                    echo '    </div>';
                    echo '</div>';
                }
                echo '</div></div>';

                break; // Display only the first matching variation
            // }
        }
    }

    return ob_get_clean();
}
add_shortcode('display_variant', 'display_variant_shortcode');
