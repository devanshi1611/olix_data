<?php
require_once(ABSPATH . 'wp-admin/includes/image.php');
require_once(ABSPATH . 'wp-includes/pluggable.php');
add_theme_support('post-thumbnails');

function test_frontend_event_submission_form()
{
    if (is_user_logged_in()) {
        ob_start();
        ?>
        <div class="acf-form-container">
            <?php if (isset($_GET['event_status'])): ?>
                <div id="response-message" class="<?php echo esc_attr($_GET['event_status']); ?>">
                    <?php if ($_GET['event_status'] == 'success')
                        echo 'Event successfully submitted. Thank you!'; ?>
                    <?php if ($_GET['event_status'] == 'error')
                        echo 'An error occurred. Please try again.'; ?>
                </div>
            <?php else: ?>
                <form id="event-submission-form" enctype="multipart/form-data" method="post" action="">

                    <!-- Add this hidden field to prevent accidental resubmission -->
                    <input type="hidden" name="submitted" value="1" />
                    <?php wp_nonce_field('event_submission_nonce', 'event_submission_nonce_field'); ?>


                    <!-- Title -->
                    <p>
                        <label for="title">Name of Event <span style="color:red;">*</span></label>
                        <input type="text" id="title" name="title"
                            placeholder="Louis Vuitton x Murakami London Pop-up" required />
                    </p>

                    <!-- Subtitle (display on home page) -->
                    <p>
                        <label for="subtitle">Subtitle <span style="color:red;">*</span></label>
                        <input type="text" id="subtitle" name="subtitle" maxlength="120" placeholder="Louis Vuitton x Murakami Pop-up Store and Cafe in London" required />
                    </p>

                    <!-- Featured Image -->
                    <p>
                        <label for="event_featured_image">Featured Image <span style="color:red;">*</span></label><br>
                        <input type="file" id="event_featured_image" name="event_featured_image" accept="image/*" />
                        <span id="image_upload_error" style="color: red; font-weight: bold;"></span>
                        <img id="featured_image_preview" src="" alt="Featured Image Preview"
                            style="display:none; max-width: 100%; height: 400px; margin-top: 10px; padding-left:50px;" />

                    </p>

                    <!-- Event Type -->
                    <p>
                        <label for="event_type">Event Type <span style="color:red;">*</span></label><br>
                        <input type="radio" id="event_type_normal" name="event_type" value="normal" checked /> Normal
                        <input type="radio" id="event_type_season" name="event_type" value="season" /> Season
                        <input type="radio" id="event_type_season_year" name="event_type" value="season_year" /> Season +
                        Year
                        <input type="radio" id="event_type_year" name="event_type" value="year" /> Year
                    </p>

                    <!-- Normal (conditional, only if Event Type is 'Normal')-->
                    <div id="startEndDate">
                        <!-- Select Start Date -->

                        <p>
                            <label for="select_start_date">Select Start Date Type <span style="color:red;">*</span></label><br>
                            <input type="radio" id="select_start_date_date" name="select_start_date" value="date" checked /> Date
                            <input type="radio" id="select_start_date_now" name="select_start_date" value="now" /> Now
                        </p>

                        <!-- Start Date (conditional, only if Date is selected) -->
                        <div id="start_date_fields" style="display:block;">
                            <p>
                                <label for="start_date">Start Date <span style="color:red;">*</span></label>
                                <input type="date" id="start_date" name="start_date" required />
                            </p>
                        </div>

                        <!-- Select End Date -->
                        <p>
                            <label for="select_end_date">Select End Date Type <span style="color:red;">*</span></label><br>
                            <input type="radio" id="select_end_date_date" name="select_end_date" value="date" checked /> Date
                            <input type="radio" id="select_end_date_confirmed" name="select_end_date" value="confirmed" /> Confirmed
                        </p>

                        <!-- End Date (conditional, only if Date is selected) -->
                        <div id="end_date_fields" style="display:block;">
                            <p>
                                <label for="end_date">End Date <span style="color:red;">*</span></label>
                                <input type="date" id="end_date" name="end_date" required />
                            </p>
                        </div>
                    </div>

                    <!-- Season (conditional, only if Event Type is 'Season') -->
                    <div id="season_fields" style="display:none;">
                        <p>
                            <label for="season">Season <span style="color:red;">*</span></label>
                            <select id="season" name="season">
                                <option value="spring">Spring</option>
                                <option value="summer">Summer</option>
                                <option value="fall">Fall</option>
                                <option value="winter">Winter</option>
                            </select>
                        </p>
                    </div>

                    <!-- Season + Year (conditional, only if Event Type is 'Season + Year')-->
                    <div id="season_year_fields">
                        <p>
                            <label for="season_year">Season Year <span style="color:red;">*</span></label>
                            <select name="season_year" id="season_year">
                                <option value="2025">2025</option>
                                <option value="2026">2026</option>
                                <option value="2027">2027</option>
                            </select>
                        </p>
                    </div>

                    <!-- Year (conditional, only if Event Type is 'Year')-->
                    <div id="year_fields">
                        <p>
                            <label for="year">Year <span style="color:red;">*</span></label>
                            <select name="year" id="year">
                                <option value="2025">2025</option>
                                <option value="2026">2026</option>
                                <option value="2027">2027</option>
                            </select>
                        </p>
                    </div>

                    <!-- When -->
                    <p>
                        <label for="when">Event Year <span style="color:red;">*</span></label>
                        <input type="text" id="when" name="when" placeholder="2025" required />
                    </p>

                    <!-- Full Address -->
                    <p>
                        <label for="full_address">Full Address <span style="color:red;">*</span></label>
                        <input type="text" id="full_address" name="full_address" placeholder="39 - 43 Brewer Street, London W1F 9UW, England" required />
                    </p>



                    <!-- Google API Location -->

                    <!-- Input field for location search -->
                    <p>
                        <label for="location">Location <span style="color:red;">*</span></label>
                        <input type="text" id="inputField" placeholder="Search a location...">

                        <!-- Enhanced select element for selected locations -->
                        <select id="locationSelect" name="locationSelect[]">
                            <!-- Google API sugession-->
                        </select>
                    </p>

                    <!-- Event Link (Button LINK) -->
                    <p>
                        <label for="event_link">Event Link <span style="color:red;">*</span></label>
                        <input type="url" id="event_link" name="event_link" placeholder="https://www.yourevent.com/readmore"
                            required />
                    </p>

                    <p>
                        <label for="event_button_text">Event Button Text <span style="color:red;">*</span></label>
                        <select id="event_button_text" name="event_button_text" required>
                            <option value="FIND OUT MORE">FIND OUT MORE</option>
                            <option value="GET TICKETS">GET TICKETS</option>                          
                            <option value="VISIT NOW">VISIT NOW</option>
                        </select>
                    </p>

                    <?php
                    $crossover_terms = get_terms(array(
                        'taxonomy' => 'types-of-crossover',
                        'orderby' => 'name',
                        'order' => 'ASC',
                        'hide_empty' => false,
                    ));

                    // Get terms for 'type-of-event' taxonomy
                    $event_terms = get_terms(array(
                        'taxonomy' => 'type-of-event',
                        'orderby' => 'name',
                        'order' => 'ASC',
                        'hide_empty' => false,
                    ));

                    // Check if terms exist for 'types-of-crossover' taxonomy
                    if (!is_wp_error($crossover_terms) && !empty($crossover_terms)) {
                        ?>
                        <div id="multiselect-container">
                            <label>Event Crossovers <span style="color:red;">*</span></label>
                            <div id="selected-options-container"></div>
                            <select id="custom-multiselect" name="event_crossover_terms[]" multiple>
                                <?php foreach ($crossover_terms as $term) { ?>
                                    <option value="<?php echo esc_attr($term->term_id); ?>"
                                        data-slug="<?php echo esc_attr($term->slug); ?>">
                                        <?php echo esc_html($term->name); ?>
                                    </option>
                                <?php } ?>
                            </select>
                            <input type="hidden" name="selected-crossovers" type="hidden">
                            <div class="selected-crossovers"></div>
                        </div>
                    <?php } ?>

                    <?php
                    // Check if terms exist for the 'type-of-event' taxonomy
                    if (!is_wp_error($event_terms) && !empty($event_terms)) {
                        ?>
                        <label for="type-of-event">Type of Event <span style="color:red;">*</span></label>
                        <select name="type-of-event" id="type-of-event" class="form-control" required>
                            <option value="">Select</option>
                            <?php foreach ($event_terms as $term) { ?>
                                <option value="<?php echo esc_attr($term->term_id); ?>"><?php echo esc_html($term->name); ?></option>
                            <?php } ?>
                        </select>
                    <?php } ?>

                    <?php wp_nonce_field('_wpnonce'); ?>

                    <br>
                    <div id="validation_message"></div>

                    <br>
                    <!-- Submit Button -->
                    <p class="submit">
                        <input type="submit" id="custom_submit_event_button" name="custom_submit_event" value="Submit Event" />
                    </p>
                </form>
            <?php endif; ?>
        </div>


        <!-- Loader and overlay -->
        <div id="event-submission-overlay" style="display: none;">
            <div id="loader">Hang tight! We’re submitting your event.</div>
        </div>


        <script>

            document.addEventListener("DOMContentLoaded", function () {
                const form = document.querySelector('form'); // Replace with your actual form selector
                const submitButton = document.querySelector('input[name="custom_submit_event"]');
                const validationMessage = document.getElementById("validation_message");

                function validateForm() {
                    validationMessage.innerHTML = ""; // Clear previous messages
                    let isValid = true;
                    let messages = new Set(); // Use a Set to prevent duplicate messages
                    let missingFields = [];

                    // Get current year
                    const currentYear = new Date().getFullYear();

                    // Required fields
                    const requiredFields = [
                        "title",
                        "subtitle",
                        "event_featured_image",
                        "when",
                        "full_address",
                        "event_link",
                        "event_button_text",
                        "type-of-event",
                        "start_date",
                        "end_date",
                        "season",
                        "season_year",
                        "year"
                    ];

                    let emptyFieldExists = false;

                    requiredFields.forEach(fieldId => {
                        const field = document.getElementById(fieldId);
                        
                        // Only validate if the field has the "required" attribute dynamically set
                        if (field && field.hasAttribute("required") && !field.value.trim()) {
                            emptyFieldExists = true;
                            isValid = false;
                            missingFields.push(fieldId);
                        }
                    });

                    const selectedOptionsContainer = document.getElementById("selected-options-container");
                    if (selectedOptionsContainer && selectedOptionsContainer.children.length === 0) {
                        emptyFieldExists = true;
                        isValid = false;
                        missingFields.push("selected-options-container");
                    }

                    if (emptyFieldExists) {
                        messages.add("Please fill in the required fields.");
                    }                  

                    // Additional validations
                    const eventLink = document.getElementById("event_link");
                    if (eventLink && eventLink.value.trim() && !/^https:\/\/.+/i.test(eventLink.value.trim())) {
                        messages.add("Event link must start with 'https://'.");
                        isValid = false;
                        missingFields.push("event_link (invalid format)");
                    }

                    const whenField = document.getElementById("when");
                    if (whenField && whenField.value.trim()) {
                        const eventYear = parseInt(whenField.value.trim(), 10);
                        if (isNaN(eventYear) || eventYear < currentYear) {
                            messages.add(`Event year must be ${currentYear} or later.`);
                            isValid = false;
                            missingFields.push("when (invalid year)");
                        }
                    }

                    if (missingFields.length > 0) {
                        console.warn("Missing or invalid fields:", missingFields);
                    }

                    // Display validation errors if any
                    if (!isValid) {
                        validationMessage.innerHTML = `<span style="color: red;">${[...messages].map(msg => `${msg}<br>`).join('')}</span>`;
                    }

                    return isValid; // Return validation status
                }

                // Attach validation to the submit button click
                submitButton.addEventListener("click", function (event) {
                    if (!validateForm()) {
                        event.preventDefault(); // Prevent form submission if validation fails
                    }
                });

                 // Reset validation message on any input change
                const allFields = document.querySelectorAll("input, textarea, select");
                allFields.forEach(field => {
                    field.addEventListener("input", function () {
                        validationMessage.innerHTML = ""; // Clear validation message
                    });
                });
            });


            document.getElementById('event_featured_image').addEventListener('change', function (event) {
                var file = event.target.files[0];
                var preview = document.getElementById('featured_image_preview');
                var errorMessage = document.getElementById('image_upload_error');  // Element to display the error message

                // Clear any previous error messages
                if (errorMessage) {
                    errorMessage.textContent = '';
                }

                console.log("Selected file:", file);

                if (file) {
                    // Check file format (JPG, JPEG, PNG, WebP)
                    var validFormats = ['image/jpeg', 'image/png', 'image/webp'];
                    console.log("File type:", file.type);

                    if (!validFormats.includes(file.type)) {
                        console.log("Invalid file format detected.");
                        if (errorMessage) {
                            errorMessage.textContent = 'Invalid file format. Please upload a JPG, JPEG, PNG, or WebP image.';
                        }
                        preview.style.display = 'none'; // Hide the preview
                        return;
                    }

                    // Check file size (2GB)
                    var maxSize = 2 * 1024 * 1024;
                    console.log("File size:", file.size, "bytes");

                    if (file.size > maxSize) {
                        console.log("File is too large.");
                        if (errorMessage) {
                            errorMessage.textContent = 'File size is too large. The maximum allowed size is 2GB.';
                        }
                        preview.style.display = 'none'; // Hide the preview
                        return;
                    }

                    // If file is valid, display preview
                    console.log("File is valid, displaying preview...");
                    var reader = new FileReader();
                    reader.onload = function (e) {
                        console.log("File successfully read.");
                        preview.src = e.target.result;
                        preview.style.display = 'block'; // Show the preview
                    };

                    reader.readAsDataURL(file);
                } else {
                    console.log("No file selected.");
                    preview.src = '';
                    preview.style.display = 'none'; // Hide the preview if no file is selected
                }
            });

            // Function to handle conditional display of date fields
            // document.getElementById('event_featured_image').addEventListener('change', function (event) {
            //     var file = event.target.files[0];
            //     var preview = document.getElementById('featured_image_preview');

            //     if (file) {
            //         var reader = new FileReader();

            //         reader.onload = function (e) {
            //             preview.src = e.target.result;
            //             preview.style.display = 'block'; // Show the preview
            //         };

            //         reader.readAsDataURL(file);
            //     } else {
            //         preview.src = '';
            //         preview.style.display = 'none'; // Hide the preview if no file is selected
            //     }
            // });

            document.addEventListener('DOMContentLoaded', function () {

                var event_type_choice = document.getElementsByName('event_type');
                var eventTypeRadios = document.getElementsByName('event_type');

                var normal_block = document.getElementById("startEndDate");
                var startDateChoice = document.getElementsByName('select_start_date');
                var startDateFields = document.getElementById('start_date_fields');
                var start_date = document.getElementById("start_date");
                var endDateChoice = document.getElementsByName('select_end_date');
                var endDateFields = document.getElementById('end_date_fields');
                var end_date = document.getElementById("end_date");

                var season_block = document.getElementById('season_fields');
                var season = document.getElementById('season');

                var season_year_block = document.getElementById("season_year_fields");
                var season_year = document.getElementById('season_year');

                var year__block = document.getElementById("year_fields");
                var year = document.getElementById('year');


                // Initialize Google Places Autocomplete
                function initializeAutocomplete() {
                    autocomplete = new google.maps.places.Autocomplete(inputField, {
                        types: ['geocode'], // Restrict to geographic results
                    });

                    // Event listener for place selection
                    autocomplete.addListener('place_changed', () => {
                        const place = autocomplete.getPlace();
                        if (place && place.formatted_address) {
                            addLocation(place.formatted_address);
                            inputField.value = ''; // Clear input after selection
                            console.log("hereeee");
                            jQuery('.select2-container').show();
                            setTimeout(hideClearAndArrowButtons, 100);
                            // const clearButton = document.getElementsByClassName("select2-selection__clear");
                            // console.log(clearButton);
                            // if (clearButton.length > 0) {
                            //     clearButton[0].style.display = 'none';
                            // }
                        }
                    });
                }

                // Function to hide clear button and arrow button after selection
                function hideClearAndArrowButtons() {
                    // Hide the "clear" button (cross button)
                    const clearButton = document.getElementsByClassName("select2-selection__clear");
                    if (clearButton.length > 0) {
                        clearButton[0].style.display = 'none';
                    }
                }

                // Function to add or replace the selected location
                function addLocation(location) {
                    // If a location is already selected, remove the previous selection
                    if (selectedLocation !== null) {
                        locationSelect.innerHTML = '';  // Clear the select options
                    }

                    // Set the new location as selected
                    selectedLocation = location;

                    // Create a new <option> element for the new location
                    const option = document.createElement("option");
                    option.value = location;
                    option.textContent = location;
                    option.selected = true; // Mark the option as selected

                    // Append the new option to the select element
                    locationSelect.appendChild(option);

                    // Show the select element when a location is added
                    if (locationSelect.style.display === 'none') {
                        locationSelect.style.display = 'block';
                    }

                    // Disable the input field after a location is selected
                    inputField.disabled = true; 
                    inputField.style.display = 'none';

                    // Add a "Remove" link to clear the selection
                    const removeLink = document.createElement("a");
                    removeLink.textContent = "Remove";
                    removeLink.href = "#";
                    removeLink.style.color = "red";
                    removeLink.style.marginLeft = "10px";

                    // When the "Remove" link is clicked, reset the location
                    removeLink.addEventListener('click', function (event) {
                        event.preventDefault();
                        removeLocation();
                    });

                    // Append the "Remove" link next to the select field
                    locationSelect.parentElement.appendChild(removeLink);
                }

                // Function to remove the selected location and reset the input
                function removeLocation() {
                    selectedLocation = null;  // Reset selected location
                    locationSelect.innerHTML = '';  // Clear the select options
                    locationSelect.style.display = 'none';  // Hide the select element
                    inputField.value = '';  // Clear the input field
                    inputField.disabled = false; 
                    inputField.style.display = 'block';
                    locationSelect.parentElement.querySelector('a').remove();  // Remove the "Remove" link
                }

                // Initialize Select2 on the select field
                jQuery('#locationSelect').select2({
                    placeholder: "Select a location...",
                    allowClear: true,
                    disabled: true, // Disabled initially
                    language: {
                        noResults: function () {
                            return "No location selected"; // Custom message when empty
                        }
                    }
                });

                // Handle input field change event to enable Select2
                jQuery('#inputField').on('change', function () {
                    // Enable the Select2 dropdown
                    jQuery('#locationSelect').prop('disabled', false);
                    // Manually trigger Select2's change event to update
                    jQuery('#locationSelect').trigger('change');
                });




                // Google API Location
                const inputField = document.getElementById("inputField");
                const locationSelect = document.getElementById("locationSelect");
                let selectedLocation = null;  // To hold the current selected location

                // Hide the "arrow" button
                const arrowButton = document.getElementsByClassName("select2-selection__arrow");
                if (arrowButton.length > 0) {
                    arrowButton[0].style.display = 'none';
                }

                // Initialize autocomplete on page load
                initializeAutocomplete();


                // 30 jan ------------------------------------------------------------------------
                // Initialize Google Places Autocomplete
                // function initializeAutocomplete() {
                //     autocomplete = new google.maps.places.Autocomplete(inputField, {
                //         types: ['geocode'], // Restrict to geographic results
                //     });

                //     // Event listener for place selection
                //     autocomplete.addListener('place_changed', () => {
                //         const place = autocomplete.getPlace();
                //         if (place && place.formatted_address) {
                //             addLocation(place.formatted_address);
                //             inputField.value = ''; // Clear input after selection
                //         }
                //     });
                // }

                // let selectedLocation = null;
                // // Add or replace location in the select element
                // function addLocation(location) {
                //     // If a location is already selected, remove it first
                //     if (selectedLocation !== null) {
                //         locationSelect.removeChild(locationSelect.options[0]);
                //     }

                //     // Set the new location as selected
                //     selectedLocation = location;

                //     // Create a new <option> element for the new location
                //     const option = document.createElement("option");
                //     option.value = location;
                //     option.textContent = location;
                //     option.selected = true; // Mark the option as selected

                //     // Append the new option to the select element
                //     locationSelect.appendChild(option);

                //     // Show the select element if it's the first location added
                //     if (locationSelect.style.display === 'none') {
                //         locationSelect.style.display = 'block';
                //     }
                // }

                // // Remove location from the specific select element
                // function removeLocation(location, optionElement) {
                //     selectedLocations.delete(location);
                //     optionElement.remove();

                //     // Hide the select element if no items remain
                //     if (selectedLocations.size === 0) {
                //         locationSelect.style.display = 'none';
                //     }
                // }

                // // Function to add the latest selected value to selectedValues
                // // function addSelectedValue(selectedValue) {
                // //     console.log("addSelectedValue", addSelectedValue);
                // //     // Add the value to selectedValues array if it's not already present
                // //     if (!selectedValues.includes(selectedValue)) {
                // //         selectedValues.push(selectedValue);
                // //     }
                // // }


                // // Function to sort the options in the multiselect dropdown
                // // function sortDropdownOptions() {
                // //     var options = Array.from(multiselect.options);
                // //     options.sort(function (a, b) {
                // //         return a.text.localeCompare(b.text);
                // //     });
                // //     multiselect.innerHTML = ''; // Clear the current options
                // //     options.forEach(function (option) {
                // //         multiselect.appendChild(option); // Append sorted options
                // //     });
                // // }



                // // Initialize Select

                // jQuery('#locationSelect').select2({
                //     placeholder: "Select locations...",
                //     allowClear: true,
                //     disabled: true,
                //     language: {
                //         noResults: function () {
                //             return "No selected location"; // Custom message when empty
                //         }
                //     }
                // });

                // // Change event on inputField
                // jQuery('#inputField').on('change', function () {
                //     // Enable the Select2 dropdown
                //     jQuery('#locationSelect').prop('disabled', false);

                //     // Manually trigger Select2's change event to update
                //     jQuery('#locationSelect').trigger('change');

                //     // Log selected values
                //     console.log(jQuery('#locationSelect').val());
                // });

                // // Handle unselect event
                // jQuery('#locationSelect').on('select2:unselect', function (e) {
                //     const unselectedValue = e.params.data.id; // Get the value of the unselected option
                //     jQuery(this).find(`option[value="${unselectedValue}"]`).remove(); // Remove the option from the DOM
                //     jQuery(this).trigger('change'); // Trigger change to update Select2
                // });

                // //Google API Location
                // new google.maps.places.Autocomplete();
                // new google.maps.places.Autocomplete(document.getElementById("autocomplete"));

                // // Drop Down Location Google API
                // const inputField = document.getElementById("inputField");
                // const locationSelect = document.getElementById("locationSelect");
                // const selectedLocations = new Set(); // To avoid duplicate locations
                // let autocomplete;

                // // Initialize autocomplete on page load
                // initializeAutocomplete();

                // ------------------------------------------------------------------------------------------

                event_type_choice.forEach(function (radio) {
                    radio.addEventListener('change', toggleFields);
                });

                startDateChoice.forEach(function (radio) {
                    radio.addEventListener('change', toggleDateFields);
                });
                endDateChoice.forEach(function (radio) {
                    radio.addEventListener('change', toggleDateFields);
                });

                toggleFields();
                toggleDateFields();

                var multiselect = document.getElementById('custom-multiselect');
                var selectedOptionsContainer = document.getElementById('selected-options-container');
                var selectedCrossovers = document.querySelector('.selected-crossovers'); // Get the div for selected values
                var hiddenInput = document.querySelector('input[name="selected-crossovers"]'); // Hidden input field
                var selectedValues = [];

                multiselect.addEventListener('change', function () {
                    var selectedValue = multiselect.value; // Get selected value
                    var selectedText = multiselect.options[multiselect.selectedIndex].text; // Get selected text
                    console.log("selected option -> " + selectedValue);

                    if (selectedValue !== "" && !Array.from(selectedOptionsContainer.children).some(option => option.dataset.value === selectedValue)) {
                        var optionElement = document.createElement('div');
                        optionElement.classList.add('selected-option');
                        optionElement.dataset.value = selectedValue;
                        optionElement.textContent = selectedText;

                        var removeOption = document.createElement('span');
                        removeOption.classList.add('remove-option');
                        removeOption.textContent = 'x';
                        removeOption.addEventListener('click', function () {
                            optionElement.remove();
                            console.log("removeOption -> " + selectedValue);
                            var newOption = document.createElement('option');
                            newOption.value = selectedValue;
                            newOption.textContent = selectedText;
                            multiselect.appendChild(newOption);
                            selectedValues = selectedValues.filter(function (v) {
                                return v !== selectedValue;
                            });
                            updateSelectedValues();
                        });

                        optionElement.appendChild(removeOption);
                        selectedOptionsContainer.appendChild(optionElement);
                        multiselect.querySelector(`option[value="${selectedValue}"]`).remove();
                        selectedValues.push(selectedValue);
                        updateSelectedValues();
                    }
                    multiselect.value = '';
                });

                function updateSelectedValues() {
                    selectedCrossovers.innerHTML = '';
                    selectedValues.forEach(function (value) {
                        var pTag = document.createElement('p');
                        pTag.textContent = value;
                        selectedCrossovers.appendChild(pTag);
                    });
                    hiddenInput.value = selectedValues.join(',');
                }

                function toggleFields() {
                    console.log("toggleFields fucntion");
                    var selectedValue = document.querySelector('input[name="event_type"]:checked').value;

                    normal_block.style.display = "none";
                    season_block.style.display = "none";
                    season_year_block.style.display = "none";
                    year__block.style.display = "none";

                    // Remove 'required' attribute from all fields initially
                    start_date.removeAttribute("required");
                    end_date.removeAttribute("required");
                    season.removeAttribute("required");
                    season_year.removeAttribute("required");
                    year.removeAttribute("required");

                    if (selectedValue === "normal") {
                        normal_block.style.display = "block";
                        start_date.setAttribute("required", "");
                        end_date.setAttribute("required", "");
                    } else if (selectedValue === "season") {
                        season_block.style.display = "block";
                        season.setAttribute("required", "");
                    } else if (selectedValue === "season_year") {
                        season_block.style.display = "block";
                        season_year_block.style.display = "block";
                        season.setAttribute("required", "");
                        season_year.setAttribute("required", "");
                    } else if (selectedValue === "year") {
                        year__block.style.display = "block";
                        year.setAttribute("required", "");
                    }
                }

                function toggleDateFields() {
                    if (document.querySelector('input[name="select_start_date"]:checked').value === 'date') {
                        startDateFields.style.display = 'block';
                        start_date.setAttribute('required', '');
                    } else {
                        startDateFields.style.display = 'none';
                        start_date.removeAttribute('required');
                    }

                    if (document.querySelector('input[name="select_end_date"]:checked').value === 'date') {
                        endDateFields.style.display = 'block';
                        end_date.setAttribute('required', '');
                        season_block.style.display = 'none';
                        season.removeAttribute('required');
                    } else {
                        endDateFields.style.display = 'none';
                        end_date.removeAttribute('required');
                    }
                }

            });

            document.addEventListener('DOMContentLoaded', function () {
                // Function to log selected values of all relevant fields
                function logSelectedValues() {
                    const eventType = document.querySelector('input[name="event_type"]:checked') ? document.querySelector('input[name="event_type"]:checked').value : '';
                    const startDateType = document.querySelector('input[name="select_start_date"]:checked') ? document.querySelector('input[name="select_start_date"]:checked').value : '';
                    const endDateType = document.querySelector('input[name="select_end_date"]:checked') ? document.querySelector('input[name="select_end_date"]:checked').value : '';
                    const startDate = document.querySelector('input[name="start_date"]') ? document.querySelector('input[name="start_date"]').value : '';
                    const endDate = document.querySelector('input[name="end_date"]') ? document.querySelector('input[name="end_date"]').value : '';
                    const season = document.querySelector('select[name="season"]') ? document.querySelector('select[name="season"]').value : '';
                    const seasonYear = document.querySelector('select[name="season_year"]') ? document.querySelector('select[name="season_year"]').value : '';
                    const year = document.querySelector('select[name="year"]') ? document.querySelector('select[name="year"]').value : '';

                    console.log("Selected Event Type:", eventType);
                    console.log("Selected Start Date Type:", startDateType);
                    console.log("Selected End Date Type:", endDateType);
                    console.log("Selected Start Date:", startDate);
                    console.log("Selected End Date:", endDate);
                    console.log("Selected Season:", season);
                    console.log("Selected Season Year:", seasonYear);
                    console.log("Selected Year:", year);
                    console.log("-------------------------------------------------");
                }

                function resetFields() {
                    const eventType = document.querySelector('input[name="event_type"]:checked') ? document.querySelector('input[name="event_type"]:checked').value : '';

                    // Reset all fields
                    if (eventType === 'normal') {
                        // Reset start date and end date types to 'date' when event type is 'normal'
                        document.querySelector('input[name="select_start_date"][value="date"]').checked = true;
                        document.querySelector('input[name="select_end_date"][value="date"]').checked = true;

                        // Clear season, season year, and year fields for 'normal' event type
                        document.querySelector('select[name="season"]').value = '';  // Clear season
                        document.querySelector('select[name="season_year"]').value = '';  // Clear season year
                        document.querySelector('select[name="year"]').value = '';  // Clear year
                    } else if (eventType === 'season') {
                        // Reset start date and end date types (empty these fields)
                        document.querySelector('input[name="select_start_date"][value="date"]').checked = false;
                        document.querySelector('input[name="select_start_date"][value="now"]').checked = false;
                        document.querySelector('input[name="select_end_date"][value="date"]').checked = false;
                        document.querySelector('input[name="select_end_date"][value="confirmed"]').checked = false;

                        // Clear season year and year fields for 'season' event type
                        document.querySelector('select[name="season_year"]').value = '';  // Clear season year
                        document.querySelector('select[name="year"]').value = '';  // Clear year
                    } else if (eventType === 'season_year') {
                        // Reset start date and end date types (empty these fields)
                        document.querySelector('input[name="select_start_date"][value="date"]').checked = false;
                        document.querySelector('input[name="select_start_date"][value="now"]').checked = false;
                        document.querySelector('input[name="select_end_date"][value="date"]').checked = false;
                        document.querySelector('input[name="select_end_date"][value="confirmed"]').checked = false;

                        // Clear season and year fields for 'season_year' event type
                        document.querySelector('select[name="season"]').value = '';  // Clear season
                        document.querySelector('select[name="year"]').value = '';  // Clear year
                    } else if (eventType === 'year') {
                        // Reset start date and end date types (empty these fields)
                        document.querySelector('input[name="select_start_date"][value="date"]').checked = false;
                        document.querySelector('input[name="select_start_date"][value="now"]').checked = false;
                        document.querySelector('input[name="select_end_date"][value="date"]').checked = false;
                        document.querySelector('input[name="select_end_date"][value="confirmed"]').checked = false;

                        // Clear season and season year fields for 'year' event type
                        document.querySelector('select[name="season"]').value = '';  // Clear season
                        document.querySelector('select[name="season_year"]').value = '';  // Clear season year
                    }
                }

                // Add event listeners to the form fields to trigger logging and reset
                document.querySelectorAll('input[name="event_type"]').forEach(radio => {
                    radio.addEventListener('change', function () {
                        resetFields();
                        logSelectedValues();
                    });
                });

                document.querySelectorAll('input[name="select_start_date"]').forEach(radio => {
                    radio.addEventListener('change', logSelectedValues);
                });

                document.querySelectorAll('input[name="select_end_date"]').forEach(radio => {
                    radio.addEventListener('change', logSelectedValues);
                });

                document.querySelectorAll('input[name="start_date"]').forEach(input => {
                    input.addEventListener('change', logSelectedValues);
                });

                document.querySelectorAll('input[name="end_date"]').forEach(input => {
                    input.addEventListener('change', logSelectedValues);
                });

                document.querySelectorAll('select[name="season"]').forEach(select => {
                    select.addEventListener('change', logSelectedValues);
                });

                document.querySelectorAll('select[name="season_year"]').forEach(select => {
                    select.addEventListener('change', logSelectedValues);
                });

                document.querySelectorAll('select[name="year"]').forEach(select => {
                    select.addEventListener('change', logSelectedValues);
                });

                // Initial reset on page load
                resetFields();
                logSelectedValues();
            });

            document.addEventListener('DOMContentLoaded', function () {
                const form = document.querySelector('#event-submission-form');  
                const overlay = document.querySelector('#event-submission-overlay');

                form.addEventListener('submit', function (e) {
                    overlay.style.display = 'flex';  
                    const submitButton = form.querySelector('button[type="submit"]');
                    submitButton.disabled = true;
                });
            });

        </script>
        <?php
        return ob_get_clean();
    } else {
        return '<p>Event successfully submitted.<br>Admin will review and publish it.<br>Thank you!</p>';
    }
}

add_shortcode('test_event_submission_form', 'test_frontend_event_submission_form');

function handle_event_submission()
{
    // echo ' _GET =============== <pre>'; print_r($_GET); echo '</pre>';
    // echo ' _POST =============== <pre>'; print_r($_POST); echo '</pre>';


    if (isset($_POST['submitted']) && $_POST['submitted'] == '1') {
        if (!isset($_POST['event_submission_nonce_field']) || !wp_verify_nonce($_POST['event_submission_nonce_field'], 'event_submission_nonce')) {
            wp_redirect(add_query_arg('event_status', 'error', remove_query_arg(['message'], $_SERVER['HTTP_REFERER'])));
            exit;
        }

        $title = isset($_POST['title']) ? sanitize_text_field($_POST['title']) : '';
        $subtitle = isset($_POST['subtitle']) ? sanitize_text_field($_POST['subtitle']) : '';
        $when = isset($_POST['when']) ? sanitize_textarea_field($_POST['when']) : '';
        $full_address = isset($_POST['full_address']) ? sanitize_text_field($_POST['full_address']) : '';
        $event_button_text = isset($_POST['event_button_text']) ? sanitize_text_field($_POST['event_button_text']) : '';

        if (isset($_POST['locationSelect']) && !empty($_POST['locationSelect'])) {
            // Sanitize and store the selected locations in an array
            $locations = array_map('sanitize_text_field', $_POST['locationSelect']);
        } else {
            // Default to empty array if no locations selected
            $locations = [];
        }

        // $event_location = isset($_POST['event_location']) ? sanitize_text_field($_POST['event_location']) : '';
        $event_link = isset($_POST['event_link']) ? esc_url_raw($_POST['event_link']) : '';
        $event_type = isset($_POST['event_type']) ? sanitize_text_field($_POST['event_type']) : '';
        $selected_locations = isset($_POST['selected_locations']) ? array_map('sanitize_text_field', $_POST['selected_locations']) : [];
        // $custom_multiselect = isset($_POST['custom_multiselect']) ? array_map('sanitize_text_field', $_POST['custom_multiselect']) : [];

        // Event Type Handling
        $start_date = '';
        $end_date = '';
        $season = '';
        $season_year = '';
        $year = '';
        $start_date_type = isset($_POST['select_start_date']) ? sanitize_text_field($_POST['select_start_date']) : '';
        $end_date_type = isset($_POST['select_end_date']) ? sanitize_text_field($_POST['select_end_date']) : '';

        if ($event_type === 'normal') {
            if ($start_date_type === 'date') {
                $start_date = isset($_POST['start_date']) ? sanitize_text_field($_POST['start_date']) : '';
            } elseif ($start_date_type == 'now') {
                $start_date = 'now';
            }

            if ($end_date_type === 'date') {
                $end_date = isset($_POST['end_date']) ? sanitize_text_field($_POST['end_date']) : '';
            } elseif ($end_date_type == 'confirmed') {
                $end_date = 'confirmed';
            }
        } elseif ($event_type === 'season') {
            $season = isset($_POST['season']) ? sanitize_text_field($_POST['season']) : '';
        } elseif ($event_type === 'season_year') {
            $season = isset($_POST['season']) ? sanitize_text_field($_POST['season']) : '';
            $season_year = isset($_POST['season_year']) ? sanitize_text_field($_POST['season_year']) : '';
        } elseif ($event_type === 'year') {
            $year = isset($_POST['year']) ? sanitize_text_field($_POST['year']) : '';
        }

        // Create a new event post
        $event_data = [
            'post_title' => $title,
            'post_content' => '',
            'post_status' => 'pending',
            'post_type' => 'event',
        ];

        $event_id = wp_insert_post($event_data);
        // echo ' event_id =============== <pre>'; print_r($event_id); echo '</pre>';

        if ($event_id) {

            if (isset($_FILES['event_featured_image']) && !empty($_FILES['event_featured_image']['name'])) {
                // Handle the file upload
                $file = $_FILES['event_featured_image'];

                $upload_overrides = array('test_form' => false); 

                // Handle the upload
                $uploaded_file = wp_handle_upload($file, $upload_overrides);

                if (isset($uploaded_file['file'])) {
                    $file_type = wp_check_filetype($uploaded_file['file']);

                    $attachment = array(
                        'guid' => $uploaded_file['url'],
                        'post_mime_type' => $file_type['type'],
                        'post_title' => sanitize_file_name($file['name']),
                        'post_content' => '',
                        'post_status' => 'inherit'
                    );

                    // Insert the attachment
                    $attachment_id = wp_insert_attachment($attachment, $uploaded_file['file'], $event_id);

                    if (is_wp_error($attachment_id)) {
                        // echo "Error inserting attachment: " . $attachment_id->get_error_message() . "<br>";
                        return;
                    }
            
                    // Check if the file exists
                    if (!file_exists($uploaded_file['file'])) {
                        // echo "Error: Uploaded file does not exist at path " . $uploaded_file['file'] . "<br>";
                        return;
                    }
            
                    // Step 1: Generate Metadata
                    require_once(ABSPATH . 'wp-admin/includes/image.php'); // Ensure function availability
                    $attachment_metadata = wp_generate_attachment_metadata($attachment_id, $uploaded_file['file']);
            
                    if (empty($attachment_metadata)) {
                        // echo "Error generating attachment metadata.<br>";
                        return;
                    }
            
                    // Step 2: Update Metadata
                    $update_metadata = wp_update_attachment_metadata($attachment_id, $attachment_metadata);
                    if (!$update_metadata) {
                        $existing_meta = get_post_meta($attachment_id, '_wp_attachment_metadata', true);
                    }
                               
                    // Step 3: Set Post Thumbnail
                    $set_thumbnail = set_post_thumbnail($event_id, $attachment_id);
            
                    if (!$set_thumbnail) {
                        echo "Error setting post thumbnail.<br>";
                        return;
                    }            
                    // echo "File uploaded and set as thumbnail!";
                } else {
                    // echo "File upload failed.";
                }
            }

            update_post_meta($event_id, 'subtitle', $subtitle);
            // update_post_meta($event_id, 'event_location', $event_location);
            update_post_meta($event_id, 'event_link', $event_link);
            update_post_meta($event_id, 'event_type', $event_type);
            update_post_meta($event_id, 'when', $when);
            update_post_meta($event_id, 'full_address', $full_address);
            update_post_meta($event_id, 'locations', $locations);
            update_post_meta($event_id, 'selected_locations', $selected_locations);
            // update_post_meta($event_id, 'custom_multiselect', $custom_multiselect);

            // Store metadata based on event type

            update_post_meta($event_id, 'select_start_date', $start_date_type);
            update_post_meta($event_id, 'select_end_date', $end_date_type);
            update_post_meta($event_id, 'start_date', $start_date);
            update_post_meta($event_id, 'end_date', $end_date);
            update_post_meta($event_id, 'season', $season);
            update_post_meta($event_id, 'season_year', $season_year);
            update_post_meta($event_id, 'year', $year);
            update_field('event_button_text', $event_button_text, $event_id);

            if (isset($_POST['selected-crossovers'])) {
                $selected_term_ids = array_map('intval', explode(',', sanitize_text_field($_POST['selected-crossovers'])));
                $taxonomy = 'types-of-crossover';
                foreach ($selected_term_ids as $element) {
                    // echo ' element =============== <pre>';
                    // print_r($element);
                    // echo '</pre>';
                    wp_set_object_terms($event_id, (int) $element, $taxonomy, true);
                }
            }
            // die("stop");

            if (!empty($_POST['type-of-event'])) {
                $selected_term_id = intval($_POST['type-of-event']);
                if ($event_id && $selected_term_id) {
                    wp_set_post_terms($event_id, [$selected_term_id], 'type-of-event', true);
                }
            }

            if (isset($_POST['locationSelect']) && !empty($_POST['locationSelect'])) {
                $location = sanitize_text_field($_POST['locationSelect'][0]);
                update_post_meta($event_id, 'location', $location);  // Array access since it's '[]'    
            }

            // if ($featured_image_id) {
            //     set_post_thumbnail($event_id, $featured_image_id);
            // }

            wp_redirect(add_query_arg('event_status', 'success', remove_query_arg(['message'], $_SERVER['HTTP_REFERER'])));
            exit;
        } else {
            wp_redirect(add_query_arg('event_status', 'error', remove_query_arg(['message'], $_SERVER['HTTP_REFERER'])));
            exit;
        }
    }
}
add_action('wp', 'handle_event_submission');

function send_admin_notification_on_pending_event( $post_id ) { 
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;    
    if ( get_post_type( $post_id ) !== 'event' ) return;   
    $post_status = get_post_status( $post_id );
 
    if ( $post_status === 'pending' ) {      
        $admin_email = get_option( 'admin_email' );    
        $event_url = admin_url( 'post.php?post=' . $post_id . '&action=edit' );    
        $subject = 'New Event Submitted for Review';     
        $message = '                  
                    <div id="mail-content">
                        <div class="email-header">
                            <img src="https://22carrots.com/wp-content/uploads/2023/05/22CARROTS-LOGO.png" alt="22Carrot -logo" class="logo">
                            <p class="tagline">PREMIER PLATFORM FOR FOOD & DRINK CROSSOVERS, BRAND<br> COLLABORATIONS, EVENTS, EXPERIENCES, AND POP-UPS</p>
                        </div>
                        <div class="email-body">
                            <p>Hello Admin,</p>
                            <p>An event has been submitted and is awaiting review. Please review the event submission and take necessary actions.</p>
                            <br>
                            <p><a href="' . esc_url($event_url) . '" class="button">View Event Submission</a></p>
                        </div>
                        <div class="footer">Mail send by <a class="site_link" href="https://22carrots.com/">22Carrot</a></div>
                    </div>              
        ';

        $headers = array('Content-Type: text/html; charset=UTF-8');
        wp_mail( $admin_email, $subject, $message, $headers );
    }
}

add_action( 'save_post', 'send_admin_notification_on_pending_event' );
?>

<style>

.acf-form-container {
    max-width: 800px;
    margin: auto;
    padding: 20px;
    border: 1px solid #ddd;
    border-radius: 8px;
    background: #F7F8F6;
}

.acf-form-container .acf-field {
    margin-bottom: 20px;
}

.acf-form-container .acf-field label {
    font-weight: bold;
}

.acf-form-container .acf-field ul {
    display: flex;
    gap: 10px;
    margin-top: 10px;
    list-style: none;
}

.acf-form-container .acf-field input[type="text"],
.acf-form-container .acf-field textarea {
    width: 100%;
    padding: 8px;
    border: 1px solid #ccc;
    border-radius: 4px;
}

.acf-form-container .acf-field input[type="submit"] {
    background: #e05e00;
    color: #F7F8F6;
    border: none;
    padding: 10px 20px;
    border-radius: 4px;
    cursor: pointer;
}

.um-button:not(.um-alt) {
    color: #F7F8F6;
    background-color: var(--e-global-color-primary) !important;
}

.um .um-button.um-alt,
.um input[type=submit].um-button.um-alt {
    color: #2E3130 !important;
    background-color: transparent !important;
    box-shadow: none !important;
    border: 2px solid var(--e-global-color-primary) !important;
    color: var(--e-global-color-primary) !important;
}

.um-button.um-alt:hover {
    background-color: var(--e-global-color-primary) !important;
    color: #FDFDFD !important;
}

.form-header {
    color: var(--e-global-color-primary) !important;
    font-family: "Arial", Sans-serif !important;
    font-size: 25px;
    line-height: 1.4em;
    text-align: center;
}

.header-custom-link {
    height: 38px;
    display: flex;
    padding: 10px 0px !important;
}

.no-events-found-text {
    text-align: center;
}

.event-submit-btn {
    color: var(--e-global-color-primary);
    border-color: var(--e-global-color-primary);
}

@media (max-width:767px) {
    .elementor-element-22d2efa {
        padding-bottom: 50px !important;
    }
}

.gallery_images .elementor-widget-container a {
    height: 100%;
}

/*******Select2 Country Dropdown****/
select#event-city {
    height: 44px;
}

select#event-country,
select#event-city,
select#event_button_text,
select#custom-multiselect,
select#custom-multiselect,
select#season,
select#season_year,
select#year,
select#type-of-event {
    border: 1px solid #C6C6C6;
}

.select2-container,
input.select2-search__field,
li.select2-search .select2-search--inline {
    width: max-content !important;
}

.select2-container--default .select2-selection--single {
    width: auto !important;
    border: 1px solid #C6C6C6;
    border-radius: 3px;
    transition: all .3s;
    font-family: inherit;
    font-size: 1rem;
    line-height: 1.5;
    margin: 0;
    color: #000;
    height: 45px;
    padding: 10px;
}

.select2-container--default .select2-selection--single .select2-selection__rendered {
    color: #000;
}

input.select2-search__field {
    border: none !important;
    padding: 5px 10px 0px 12px !important;
    color: #000;
}

input.select2-search__field::placeholder {
    color: #000 !important;
    /* Set the placeholder color to black */
    opacity: 1 !important;
    /* Ensure the placeholder is fully visible */
}

span.select2-dropdown.select2-dropdown--below {
    margin-top: 32px !important;
}


/**Field Select Google API**/
/*         #locationSelect {
            display: none; 
            width: 100%;
            max-height: 120px;
            overflow-y: auto;
            border: 1px solid #ccc;
            border-radius: 5px;
            padding: 5px;
            font-size: 14px;
        }

        #locationSelect option {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: #f5f5f5;
            margin: 5px 0;
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 14px;
        } */
#locationSelect {
    display: flex;
    width: 100%;
    height: 100%;
    max-height: auto;
    flex-wrap: wrap;
    /* Allow options to wrap onto multiple lines */
}

#locationSelect option {
    max-width: fit-content;
    /* Option width adjusts to content size */
    white-space: nowrap;
    /* Prevent text wrapping within options */
    margin: 2px;
    /* Add spacing between options for better readability */
}

.acf-form-container label {
    padding-top: 10px;
    padding-bottom: 10px;
    font-size: 17px !important;
}

/* 31 Jan Add Event form style */

#acf-form-container,
#event-submission-overlay {
    font-family: "Poppins", Sans-serif;
}

#response-message {
    text-align: center;
}

.select2-container {
    display: none;
}

#event-submission-overlay {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.5);
    display: flex;
    justify-content: center;
    align-items: center;
    z-index: 9999;
    color: white;
}

#loader {
    font-size: 20px;
    padding: 20px;
    background-color: #E05E00;
    border-radius: 5px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.5);
    color: white;
}

#locationSelect {
    display: none !important;
}

.selected-crossovers {
    display: none;
}

#multiselect-container #selected-options-container {
    display: flex;
    flex-wrap: wrap;
    margin-bottom: 0px;
}

#multiselect-container {
    width: 100%;
    display: flex;
    flex-direction: column;
    padding: 0 5px;
    margin-bottom: 20px;
}

#multiselect-container .selected-option {
    background-color: #FECCB9;
    color: #E05E00;
    padding: 5px 15px;
    margin-right: 5px;
    margin-bottom: 5px;
    border-radius: 50px;
    display: inline-flex;
    align-items: center;
    font-size: 16px;
    line-height: normal;
    font-family: "Poppins", Sans-serif;
    font-weight: 400;
}

#multiselect-container .selected-option .remove-option {
    cursor: pointer;
    margin-left: 5px;
    font-weight: bold;
    font-family: "Poppins", Sans-serif;
}

#multiselect-container #custom-multiselect {
    background-color: transparent;
    border-radius: 5px 5px 5px 5px;
    width: 100%;
    max-width: 100%;
    background-color: transparent;
    color: #1f2124;
    vertical-align: middle;
    flex-grow: 1;
    padding: 7px 20px 7px 14px;
}

#multiselect-container #custom-multiselect option {
    font-family: "Poppins", Sans-serif;
    font-weight: 400;
}

#multiselect-container label {
    font-family: "Poppins", Sans-serif;
    font-size: 16px;
    font-weight: 400;
    line-height: 27.2px;
    padding-bottom: 5px;
    color: black;
}

input#custom_submit_event_button {
    background: #E05E00;
    color: white;
}

input#custom_submit_event_button:hover {
    background-color: #F5B21B;
}

/* Hide the default radio button */
#event-submission-form input[type="radio"] {
    appearance: none;
    -webkit-appearance: none;
    -moz-appearance: none;
    width: 16px;
    height: 16px;
    border: 2px solid #ce4c0563;
    border-radius: 50%;
    position: relative;
    outline: none;
    cursor: pointer;
    transition: 0.2s all ease-in-out;
}

/* Custom radio button checked state */
#event-submission-form input[type="radio"]:checked {
    background-color: #E05E00;
    border: 4px solid white;
    box-shadow: 0 0 0 2px #ce4c0563;
}

/* Optional: Add hover effect */
#event-submission-form input[type="radio"]:hover {
    box-shadow: 0 0 5px rgba(206, 76, 5, 0.6);
}

/* admin email css */
#mail-content .email-header {
    background-color: #E05E00;
    text-align: center;
    padding-top: 20px;
    padding-bottom: 10px;
    border-radius: 10px 10px 0px 0px
}

#mail-content .email-body {
    padding: 40px;
    font-size: 15px;
}

#mail-content .button {
    display: inline-block;
    padding: 10px 20px;
    background-color: #E05E00;
    color: #fff;
    text-decoration: none;
    border-radius: 10px;
    border: 1px solid #E05E00;
}

#mail-content .button:hover {
    background-color: white;
    color: #E05E00;
    border: 1px solid #E05E00;
}

#mail-content {
    border: 1px solid #D3D3D3;
    border-radius: 20px;
    font-family: Arial, sans-serif;
}

#mail-content img {
    width: 200px;
    height: auto;
}

#mail-content .tagline {
    color: white;
    font-family: "Playfair Display", Sans-serif;
    font-size: 14px;
    font-weight: 500;
    text-transform: uppercase;
    font-style: normal;
    line-height: 22px;
    letter-spacing: 0px;
    margin-block-start: 10px;
}

#mail-content .footer {
    text-align: center;
    color: #989898;
    font-size: 12px;
}

#mail-content a {
    text-decoration: none;
}

#mail-content .site_link {
    color: #E05E00;
}
</style>