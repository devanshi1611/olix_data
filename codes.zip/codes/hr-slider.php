<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        /* Reset default margins and paddings */
        /* @import url('https://fonts.cdnfonts.com/css/chillax');
        @import url('https://fonts.cdnfonts.com/css/gotham-9'); */

        body {
            padding: 0;
            margin: 0;
        }

        .scroll-container {
            height: 100vh;
            overflow: hidden;
        }

        .scroll-content {
            display: flex;
            height: 100%;
        }

        .content-box {
            display: flex;
            justify-content: center;
            /* Center horizontally */
            align-items: center;
            /* Center vertically */
            max-width: 100vw;
            height: 100%;
            position: relative;
            /* Make sure content can be positioned absolutely */
        }

        .content {
            position: absolute;
            /* Stack content on top of the image */
            text-align: center;
            /* Center text inside the content */
            z-index: 1000;
            /* Ensure it's above other elements */
        }

        .content-box img {
            height: 100vh;
            width: 560px;
            /* Adjust as necessary */
            object-fit: cover;
            object-position: center;
        }

        .content-box:nth-child(2) img {
            object-position: right;
        }

        .title {
            font-family: Gotham;
            font-size: 40px;
            font-weight: 350;
            line-height: 40px;
            text-align: center;

            color: white;
        }

        .upper-title {
            font-family: Chillax Variable;
            font-size: 30px;
            font-weight: 500;
            line-height: 21px;
            text-align: left;
            color: #AF986C;

        }
        .content div{
            text-align: center;
        }

        .date {
            font-family: Gotham;
            font-size: 12px;
            font-weight: 400;
            line-height: 19.2px;
            color: #FFFFFF;
            background: #AF986C;
            border-radius: 100px;
            width: fit-content;
            padding: 0px 18px;
        }
    </style>
</head>

<body>
    <div class="scroll-container">
        <div class="scroll-content">
            <div class="content-box">
                <img src="https://www.enfinmamaquette.com/corto/wp-content/uploads/2024/09/concert-banner.png"
                    alt="">
                <div class="content">
                    <div class="upper-title">
                        <h3>Live Band</h3>
                    </div>
                    <div class="title">
                        <h2>HOOK</h2>
                    </div>
                    <div class="date">
                        <h3>Dec 16, 2023</h3>
                    </div>
                </div>
            </div>
            <div class="content-box">
                <img src="https://www.enfinmamaquette.com/corto/wp-content/uploads/2024/09/2-girls-performing-with-mic.jpeg"
                    alt="">
                <div class="content">
                    <div class="upper-title">
                        <h3>Karaoke</h3>
                    </div>
                    <div class="title">
                        <h2>PARTY</h2>
                    </div>
                    <div class="date">
                        <h4>Jan 20, 2024</h4>
                    </div>
                </div>
            </div>
            <div class="content-box">
                <img src="https://www.enfinmamaquette.com/corto/wp-content/uploads/2024/09/girl-singing-with-band.jpeg"
                    alt="">
                <div class="content">
                    <div class="upper-title">
                        <h3>Live Band</h3>
                    </div>
                    <div class="title">
                        <h2>Bogotha</h2>
                    </div>
                    <div class="date">
                        <h4>Feb 02, 2024</h4>
                    </div>
                </div>
            </div>
            <div class="content-box">
                <img src="https://www.enfinmamaquette.com/corto/wp-content/uploads/2024/09/lady-performing-with-mic.jpeg"
                    alt="">
                <div class="content">
                    <div class="upper-title">
                        <h3>Karaoke</h3>
                    </div>
                    <div class="title">
                        <h2>PARTY</h2>
                    </div>
                    <div class="date">
                        <h4>Mar 22, 2024</h4>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const scrollContainer = document.querySelector('.scroll-container');

            scrollContainer.addEventListener('wheel', (e) => {
                e.preventDefault();
                scrollContainer.scrollLeft += e.deltaY;

                // Get the scroll percentage of the first 30% of the screen
                const scrollWidth = window.innerWidth * 0.3;
                const scrollPosition = scrollContainer.scrollLeft;
                const scrollPercentage = Math.min(scrollPosition / scrollWidth, 1); // Capped at 1 (100%)

                // Update styles based on scroll percentage
                subtitle.style.transform = `translateY(-${scrollPercentage * 50}px)`; // Move upwards
                title.style.transform = `translateY(${scrollPercentage * 50}px)`; // Move downwards
                textDiv.style.opacity = 1 - scrollPercentage; // Fade out based on scroll percentage
            });
        });
    </script>

</body>

</html>