<?php 

if(isset($_POST['submit'])) {

    require __DIR__ . "/vendor/autoload.php";
    $stripe_secret_key = "sk_test_51Oh3SISCQLeQl1ZSFA2cDB4rVGN98hxxpw6n3xT4ZMPjyx6qe67KopZ1qZenTPCS5z13L5007nFURhKgwdx4z09S0082tX1p0H";

    \Stripe\Stripe::setApiKey($stripe_secret_key);

    $product = $_POST['product'];
    $price = $_POST['price'];
    $quantity = $_POST['quantity'];

    $checkout_session = \Stripe\Checkout\Session::create([
        "mode" => "payment",
        "success_url" => "http://localhost/tutorial/payAPI/original_form/success.php",
        "cancel_url" => "http://localhost/tutorial/payAPI/original_form/fail.php",
        "locale" => "auto",
        "line_items" => [
            [
                "quantity" => $quantity,
                "price_data" => [
                    "currency" => "inr",
                    "unit_amount" => $price*100,
                    "product_data" => [
                        "name" => "$product"
                    ]
                ]
            ]      
        ]
    ]);
    
    http_response_code(303);

  
    header("Location: " . $checkout_session->url);
    exit();

} else {
    echo "ERROR!!";
}
