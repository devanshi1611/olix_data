<?php

if (isset($_POST['submit_refund'])) {

    require __DIR__ . "/vendor/autoload.php";

    $stripe_secret_key = "sk_test_51Oh3SISCQLeQl1ZSFA2cDB4rVGN98hxxpw6n3xT4ZMPjyx6qe67KopZ1qZenTPCS5z13L5007nFURhKgwdx4z09S0082tX1p0H";

    \Stripe\Stripe::setApiKey($stripe_secret_key);

    $payment_intent_id = $_POST['pay_id'];
    echo '<script>console.log("pay_id: ' . $payment_intent_id . '");</script>';

    try {
        $payment_intent = \Stripe\PaymentIntent::retrieve($payment_intent_id);

        try {
            $refund = \Stripe\Refund::create([
                'payment_intent' => $payment_intent_id
            ]);

            echo '<script>alert("The Refund is successfully done.");</script>';
            

        } catch (Exception $e) {
            echo 'Error: ' . $e->getMessage();
        }

    } catch (Exception $e) {
        echo 'Error: ' . $e->getMessage();
    }
}


