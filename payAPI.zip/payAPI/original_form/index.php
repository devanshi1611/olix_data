<html>

<head>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css"
        integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <style>
        .form_data {
            width: 600px;
            margin: 40px;
        }
    </style>
</head>

<body>
    <form action="pay.php" method="POST" class="form_data">
        <div class="row">
            <h3 class="col">Product Data</h3><br>
            <a href="http://localhost/tutorial/payAPI/original_form/refund.php" class="col" >Refund Request</a>
        </div>

        <div class="col-md-3">
            <label name="product" class="form-label">Product</label>
            <select name="product" class="form-select">
                <option value="Camera">Camera</option>
                <option value="Headphone">Headphone</option>
                <option value="Phone">Phone</option>
                <option value="Shoes">Shoes</option>
                <option value="Watch">Watch</option>
            </select>
        </div><br>

        <div class="col-md-3">
            <label class="form-label">Price</label>
            <input name="price" type="text" class="form-control">
        </div><br><br>

        <div class="col-md-3">
            <label class="form-label">Quantity</label>
            <input name="quantity" type="number" class="form-control">
        </div><br><br>

        <div class="col-3">
            <button name="submit" type="submit" class="btn btn-dark">Submit</button>
        </div>

    </form>
</body>

</html>