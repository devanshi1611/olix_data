<html>
    <head>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js" integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+" crossorigin="anonymous"></script>
        <style>
            .form_data{
                width: 600px;
                margin: 40px;
            }
        </style>
    </head>

    <body>
        <form action="refund_process.php" method="POST" class="form_data">

            <h3>Refund Request</h3><br>
           
            <div class="col-md-6">
                <label class="form-label">Payment ID</label>
                <input name="pay_id" type="text" class="form-control">
            </div><br><br>

            <div class="col-3">
                <button name="submit_refund" type="submit" class="btn btn-dark">Submit</button>      
            </div>

        </form>
    </body>
</html>

