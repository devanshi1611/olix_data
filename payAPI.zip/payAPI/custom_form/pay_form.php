<?php

require_once("connection.php");

if (isset($_POST['submit'])) {
    try {

        $product = $_POST['product'];
        $price = $_POST['price'];
        $quantity = $_POST['quantity'];
        $total_amount = $price * $quantity;
        $product_id = $_POST['product_id'];

        $insert_que1 = "INSERT INTO product_data  VALUES ('$product_id','$product','$price','$quantity','$total_amount')";
        $result1 = mysqli_query($conn, $insert_que1);

        if(!$result1){
            echo '<script>console.log("insertion faild");</script>';
        } else {
            echo '<script>console.log("inserted successfully");</script>';
        }

    } catch (Exception $e) {
        echo 'Error: ' . $e->getMessage();
    }

}

?>

<html>

<head>
    <!-- Bootstrap CSS -->
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css"
        integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">

    <!-- Bootstrap JS -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    <!-- jQuery cdn -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>

    <style>
        .form {
            width: 500px;
            margin: 30px 40px;
        }

        .image {
            height: 100px;
            background-image: url("pay_form_bg.jpg");
            opacity: 0.8;
        }

        .form_data {
            padding: 20px 30px;
            background-color: #FFEADD;
        }

        .form_data label {
            font-size: 16px;
        }

        .error-message {
            color: red;
            font-size: 12px;
        }

        label span {
            color: red;
        }

        .row label {
            display: flex;
            align-items: center;
            justify-content: flex-start;
        }

        button {
            padding: 20px;
        }
    </style>
</head>

<body>
    <form action="stripe_payment.php" method="POST" class="form" id="payment-form">

        <div class="image"></div>

        <!-- Display errors returned by createToken -->
        <div class="payment-status" style="color: red;"></div>

        <div class="form_data">

            <div class="col-md-8">
                <label class="form-label">Email ID<span> *</span></label>
                <input name="email" id="email" type="email" class="form-control" required>
                <small id="email-error-msg" class="error-message d-none">Please enter a valid email address.</small>
            </div><br>

            <div class="col-md-8">
                <label class="form-label">Card Number<span> *</span></label>
                <input name="card_number" id="card_number" type="text" class="form-control" maxlength="16"
                    placeholder="16 digit card number" required>
                <small id="card-error-msg" class="error-message d-none">Please enter a valid credit card number.</small>
            </div><br>

            <div class="col-md-8 row">
                <label class="form-label col">Expiry Month<span>*</span></label>
                <input type="text" name="exp_month" id="exp_month" class="form-control col" placeholder="MM"
                    maxlength="2" required>
            </div><br>

            <div class="col-md-8 row">
                <label class="form-label col">Expiry Year<span>*</span></label>
                <input type="text" name="exp_year" id="exp_year" class="form-control col" placeholder="YYYY"
                    maxlength="4" required>
            </div>

            <small id="expiry-error-msg" class="error-message d-none">Please enter a valid expiry date.
            </small><br>

            <div class="col-md-8 cvc_div row">
                <label class="form-label col">CVC<span> *</span></label>
                <input type="text" class="form-control col" id="cvc" name="cvc" placeholder="123" maxlength="3"
                    required>
                <small id="cvc-error-msg" class="error-message d-none">Please enter a valid CVC code (3 digits).</small>
            </div><br>

            <div class="col-md-8">
                <label class="form-label">Card Holder Name<span> *</span></label>
                <input name="name" id="name" type="name" class="form-control" required>
                <small id="name-error-msg" class="error-message d-none">Please enter a valid card holder name.</small>
            </div><br>

            <div class="col-md-8 row">
                <label class="form-label col">Country<span> *</span></label>

                <select class="form-select form-control form-select-md col" aria-label=".form-select-sm example"
                    name="country" id="country">
                    <option value="india">India</option>
                </select>
                <small id="country-error-msg" class="error-message d-none">Please select a country.</small>

            </div><br>

            <div class="col-md-8">
                <button name="submit" type="submit" id="payBtn" class="btn btn-dark">Pay
                    <?= $total_amount ?>
                </button>
            </div>

        </div>

    </form>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"
        integrity="sha384-PqyEXXeW/JdkCe45LsnY9lf8zz4WvMr/7ExyS9c/YR7nH5Hn7C7qHvX4N0DB4Tff"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js"
        integrity="sha384-LlT8htnE4sAXb/21ltIVB4cTbABQazg2H5J8AvIFoK7ScfNzJwP0z2Zyv1Sv0Kax"
        crossorigin="anonymous"></script>


    <script>

        // Email validation
        document.getElementById('email').addEventListener('input', function (e) {
            var target = e.target,
                email = target.value.trim(),
                isValid = /^[^\s@]+@[^\s@]+\.[^\s@]{2,3}$/.test(email); // Regular expression for email validation

            // Display error message if email is not valid
            if (!isValid) {
                document.getElementById('email-error-msg').classList.remove('d-none');
            } else {
                document.getElementById('email-error-msg').classList.add('d-none');
            }
        });

        // cred card number validation
        document.getElementById('card_number').addEventListener('input', function (e) {
            var target = e.target,
                position = target.selectionEnd,
                cardNumber = target.value.replace(/\D/g, ''), // Remove all non-digits
                isValidPattern = /^[0-9]{16}$/.test(cardNumber); // Check if pattern is matched

            // Set the cursor position after the last input
            target.selectionEnd = position;

            // Check if pattern is matched and length is valid
            if (isValidPattern) {
                document.getElementById('card-error-msg').classList.add('d-none');
            } else {
                document.getElementById('card-error-msg').classList.remove('d-none');
            }
        });

        // Expiry date validation
        document.getElementById('exp_year').addEventListener('input', function (e) {
            var target = e.target,
                inputYear = target.value.trim(),
                isValid = /^(20)\d{2}$/.test(inputYear); // Regular expression for YYYY format validation, allowing only from year 2000 onwards

            // Display error message if expiry year is not valid
            if (!isValid) {
                document.getElementById('expiry-error-msg').classList.remove('d-none');
            } else {
                var today = new Date();
                var currentMonth = today.getMonth() + 1; // Add 1 because getMonth() returns zero-based month
                var currentYear = today.getFullYear();
                var inputMonth = parseInt(document.getElementById('exp_month').value);
                var inputYear = parseInt(inputYear);

                // Check if the expiry date is in the future
                if (inputYear < currentYear || (inputYear === currentYear && inputMonth <= currentMonth)) {
                    document.getElementById('exp_month').value = "";
                    document.getElementById('exp_year').value = "";
                    document.getElementById('expiry-error-msg').innerText = "Expiry date must be in the future.";
                    document.getElementById('expiry-error-msg').classList.remove('d-none');
                } else {
                    document.getElementById('expiry-error-msg').classList.add('d-none');
                }
            }
        });

        // CVC code validation
        document.getElementById('cvc').addEventListener('input', function (e) {
            var target = e.target,
                cvc = target.value.trim(),
                isValid = /^\d{3}$/.test(cvc); // Regular expression for CVC validation

            // Display error message if CVC is not valid
            if (!isValid) {
                document.getElementById('cvc-error-msg').classList.remove('d-none');
            } else {
                document.getElementById('cvc-error-msg').classList.add('d-none');
            }
        });

        // Card holder name validation
        document.getElementById('name').addEventListener('input', function (e) {
            var target = e.target,
                name = target.value.trim(),
                isValid = /^[a-zA-Z\s]+$/.test(name); // Regular expression for card holder name validation

            // Display error message if card holder name is not valid
            if (!isValid) {
                document.getElementById('name-error-msg').classList.remove('d-none');
            } else {
                document.getElementById('name-error-msg').classList.add('d-none');
            }
        });

    </script>

    <!-- Stripe JavaScript library -->
    <script src="https://js.stripe.com/v2/"></script>
    <script src="jquery-3.7.1.min.js"></script>
    <script src="js/jquery.min.js"></script>

    <script>

        // Set your publishable key
        Stripe.setPublishableKey('pk_test_51Oh3SISCQLeQl1ZS0FDekMx82r0ujDeoFUOrbHHJRkAN10z8wMeMkzlGkHCqW4l5NwuDWkb6Zk3zUrKXE0UC3VJq00i1ENopsm');

        // Callback to handle the response from stripe
        function stripeResponseHandler(status, response) {
            if (response.error) {

                // Enable the submit button
                $('#payBtn').removeAttr("disabled");

                // Display the errors on the form
                $(".payment-status").html('<p>' + response.error.message + '</p>');
            } else {
                var form = $("#payment-form");
                // Get token id
                var token = response.id;
                // Insert the token into the form
                form.append("<input type='hidden' name='stripeToken' value='" + token + "' />");
                // Submit form to the server
                form.submit();
            }
        }

        $(document).ready(function () {

            console.log("card number :\n4000003560000008");

            // On form submit
            $("#payment-form").submit(function () {
                // Disable the submit button to prevent repeated clicks
                $('#payBtn').attr("disabled", "disabled");

                // Create single-use token to charge the user
                Stripe.createToken({
                    number: $('#card_number').val(),
                    exp_month: $('#exp_month').val(),
                    exp_year: $('#exp_year').val(),
                    cvc: $('#cvc').val()
                }, stripeResponseHandler);

                // Submit from callback
                return false;

            });
        });


    </script>

</body>

</html>