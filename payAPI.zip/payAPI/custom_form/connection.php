<?php

$server = "localhost";
$username = "root";
$password = "";
$database = "stripe_payment";

$conn = mysqli_connect($server, $username, $password, $database);

if(!$conn){
    die("Database Connection Failed!!".mysqli_connect_error());
} else {
    echo '<script>console.log("connected successfully");</script>';
}

